import { TOOL_INFO, ToolId } from '../game/tools';
import { Snapshot } from '../game/engine';
import { Joystick } from './Joystick';
import { cn } from '../utils/cn';

const PERS: Record<string, { e: string; t: string }> = {
  calm: { e: '😌', t: 'Calm' },
  impatient: { e: '😤', t: 'Impatient' },
  dramatic: { e: '🎭', t: 'Dramatic' },
  jolly: { e: '😄', t: 'Jolly' },
  fussy: { e: '🧐', t: 'Fussy' },
  sleepy: { e: '😴', t: 'Sleepy' },
};
const REG: Record<string, string> = { front: 'Frn', top: 'Top', left: 'L', right: 'R', back: 'Bck', neck: 'Nck' };

const btn =
  'pointer-events-auto select-none active:scale-95 transition-transform touch-none flex items-center justify-center font-bold shadow-lg';

interface Props {
  snap: Snapshot;
  onMove: (x: number, y: number) => void;
  onTool: (t: ToolId) => void;
  onPutDown: () => void;
  onInteract: () => void;
  onFinish: () => void;
  onWalk: () => void;
  onGuard: (n: number) => void;
  onPause: () => void;
  onPaper: () => void;
}

export function Hud({ snap, onMove, onTool, onPutDown, onInteract, onFinish, onWalk, onGuard, onPause, onPaper }: Props) {
  const c = snap.customer;
  const cut = snap.mode === 'cut';
  return (
    <div className="pointer-events-none absolute inset-0 text-white" style={{ paddingTop: 'env(safe-area-inset-top)' }}>
      {/* top-left stats */}
      <div className="absolute left-2 top-2 flex flex-col gap-1.5">
        <div className="rounded-xl bg-black/55 px-2.5 py-1.5 backdrop-blur-sm text-[11px] leading-tight sm:text-xs">
          <div className="flex items-center gap-2 font-bold">
            <span className="rounded bg-amber-500 px-1.5 text-black">DAY {snap.day}</span>
            <span className="text-green-300 text-sm">₹{snap.money}</span>
          </div>
          <div className="mt-0.5 text-white/80">
            Today ₹{snap.dayEarn} · {snap.dayServed}/{snap.dayGoal} done
          </div>
          <div className="mt-0.5 flex items-center gap-2 text-white/80">
            <span className="text-amber-300">{'★'.repeat(Math.round(snap.rep))}{'☆'.repeat(5 - Math.round(snap.rep))}</span>
            <span>😊 {snap.sat}%</span>
            <span>👥 {snap.queue}</span>
          </div>
        </div>
        {snap.guide && (
          <div className="w-[128px] rounded-xl bg-black/55 px-2 py-1 backdrop-blur-sm">
            <div className="mb-0.5 text-[8px] font-bold uppercase tracking-wide text-amber-200">Hair guide · match the ticks</div>
            <div className="flex items-end justify-between">
              {snap.guide.map((g) => {
                const d = Math.abs(g.cur - g.tgt);
                return (
                  <div key={g.region} className="flex flex-col items-center gap-0.5">
                    <div className="relative h-9 w-3.5 overflow-hidden rounded bg-white/15">
                      <div
                        className={cn('absolute inset-x-0 bottom-0 rounded', d < 0.09 ? 'bg-green-400' : d < 0.2 ? 'bg-amber-400' : 'bg-rose-500')}
                        style={{ height: `${Math.min(100, g.cur * 100)}%` }}
                      />
                      <div className="absolute inset-x-0 h-[3px] bg-white" style={{ bottom: `calc(${Math.min(100, g.tgt * 100)}% - 1px)` }} />
                    </div>
                    <span className="text-[8px] text-white/80">{REG[g.region]}</span>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* top-center customer card */}
      <div className="absolute left-1/2 top-2 flex w-[min(52vw,330px)] -translate-x-1/2 flex-col items-center gap-1">
        {c && (
          <div className="w-full rounded-xl bg-black/55 px-2.5 py-1.5 backdrop-blur-sm">
            <div className="flex items-center justify-between text-[11px] font-bold sm:text-xs">
              <span>
                {PERS[c.personality]?.e} {c.name} <span className="font-normal text-white/60">· {PERS[c.personality]?.t}</span>
              </span>
              <span className="truncate pl-1 text-[10px] font-normal text-amber-200">{c.styleName}</span>
            </div>
            {c.state === 'seated' && (
              <div className="mt-1 h-1.5 overflow-hidden rounded bg-white/15" title="Patience">
                <div
                  className={cn('h-full rounded transition-all', c.patience > 0.5 ? 'bg-green-400' : c.patience > 0.2 ? 'bg-amber-400' : 'bg-rose-500')}
                  style={{ width: `${c.patience * 100}%` }}
                />
              </div>
            )}
          </div>
        )}
        {snap.say && (
          <div key={snap.say.id} className="animate-[pop_.25s_ease-out] relative max-w-full rounded-2xl border-2 border-amber-900/40 bg-white px-3 py-1.5 text-center text-[12px] font-semibold text-neutral-800 shadow-xl sm:text-sm">
            “{snap.say.text}”
          </div>
        )}
        {snap.hint && !snap.say && (
          <div className="rounded-lg bg-black/45 px-2 py-1 text-center text-[10px] text-white/90 backdrop-blur-sm sm:text-xs">{snap.hint}</div>
        )}
      </div>

      {/* top-right buttons */}
      <div className="absolute right-2 top-2 flex gap-2">
        {c && (
          <button className={cn(btn, 'h-11 w-11 rounded-full bg-amber-100 text-xl text-black')} onClick={onPaper} aria-label="Inspect drawing">
            📄
          </button>
        )}
        <button className={cn(btn, 'h-11 w-11 rounded-full bg-black/60 text-lg')} onClick={onPause} aria-label="Pause">
          ⏸
        </button>
      </div>

      {/* crosshair in walk mode */}
      {!cut && <div className="absolute left-1/2 top-1/2 h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-white/70 ring-1 ring-black/40" />}

      {/* joystick */}
      <div className="absolute bottom-3 left-3" style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}>
        <Joystick onMove={onMove} />
        {cut && <div className="mt-1 text-center text-[9px] text-white/70">orbit view</div>}
      </div>

      {/* hotbar */}
      <div className="absolute left-1/2 flex -translate-x-1/2 items-end gap-1 bottom-2 portrait:bottom-[150px]">
        {snap.tool === 'clipper' && (
          <div className="pointer-events-auto mr-1 flex flex-col items-center rounded-xl bg-black/60 px-1.5 py-1 backdrop-blur-sm">
            <span className="text-[8px] font-bold uppercase text-amber-200">Guard</span>
            <div className="flex gap-1">
              {['Skin', 'Short', 'Med', 'Long'].map((l, i) => (
                <button
                  key={l}
                  onClick={() => onGuard(i)}
                  className={cn('h-8 min-w-8 rounded-md px-1 text-[9px] font-bold', snap.guard === i ? 'bg-amber-400 text-black' : 'bg-white/15 text-white')}
                >
                  {l}
                </button>
              ))}
            </div>
          </div>
        )}
        <div className="flex gap-1 rounded-2xl bg-black/55 p-1 backdrop-blur-sm">
          {TOOL_INFO.map((t, i) => (
            <button
              key={t.id}
              onClick={() => onTool(t.id)}
              className={cn(
                btn,
                'flex-col rounded-xl border-2 text-[8px] leading-none',
                'h-[min(12vw,50px)] w-[min(9.6vw,44px)]',
                snap.tool === t.id ? 'border-amber-300 bg-amber-500/80 text-black' : 'border-white/15 bg-white/10 text-white'
              )}
              aria-label={t.name}
            >
              <span className="text-[min(5vw,20px)] leading-none">{t.icon}</span>
              <span className="mt-0.5 hidden sm:block">{t.name}</span>
              <span className="mt-0.5 text-[7px] opacity-60 sm:hidden">{i + 1}</span>
            </button>
          ))}
        </div>
      </div>

      {/* right action cluster */}
      <div className="absolute bottom-3 right-3 flex flex-col items-end gap-2" style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}>
        {cut ? (
          <>
            {snap.stroking && <div className="rounded-full bg-green-500/80 px-2 py-0.5 text-[10px] font-bold">✂ cutting…</div>}
            <div className="flex gap-2">
              {snap.tool && (
                <button className={cn(btn, 'h-11 rounded-xl bg-white/20 px-3 text-xs')} onClick={onPutDown}>
                  Put down
                </button>
              )}
              <button className={cn(btn, 'h-11 rounded-xl bg-white/20 px-3 text-xs')} onClick={onWalk}>
                🚶 Walk
              </button>
            </div>
            <button
              className={cn(btn, 'h-14 min-w-[104px] rounded-2xl bg-green-500 px-3 text-sm text-black', !c?.canFinish && 'opacity-40')}
              onClick={onFinish}
            >
              ✔ Finish cut
            </button>
          </>
        ) : (
          <>
            {snap.tool && (
              <button className={cn(btn, 'h-10 rounded-xl bg-white/20 px-3 text-xs')} onClick={onPutDown}>
                ✋ Put down {TOOL_INFO.find((t) => t.id === snap.tool)?.name}
              </button>
            )}
            <button
              className={cn(
                btn,
                'h-16 min-w-[104px] max-w-[170px] rounded-2xl px-3 text-center text-[13px] leading-tight',
                snap.prompt ? 'bg-amber-400 text-black' : 'bg-white/15 text-white/60'
              )}
              onClick={onInteract}
            >
              {snap.prompt || 'Interact'}
            </button>
          </>
        )}
      </div>
    </div>
  );
}
