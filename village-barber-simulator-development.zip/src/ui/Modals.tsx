import { ReactNode } from 'react';
import { DaySummary, ResultInfo, Settings, Snapshot } from '../game/engine';
import { cn } from '../utils/cn';

const Shell = ({ children, wide = false }: { children: ReactNode; wide?: boolean }) => (
  <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/65 p-3 backdrop-blur-[2px]" style={{ touchAction: 'pan-y' }}>
    <div
      className={cn(
        'max-h-full w-full overflow-y-auto rounded-3xl border-4 border-amber-900 bg-gradient-to-b from-amber-50 to-amber-100 p-4 text-neutral-800 shadow-2xl animate-[pop_.25s_ease-out]',
        wide ? 'max-w-3xl' : 'max-w-md'
      )}
    >
      {children}
    </div>
  </div>
);

const Btn = ({ children, onClick, tone = 'amber', className }: { children: ReactNode; onClick: () => void; tone?: 'amber' | 'green' | 'red' | 'gray'; className?: string }) => (
  <button
    onClick={onClick}
    className={cn(
      'rounded-2xl px-4 py-3 text-base font-extrabold shadow-md active:scale-95 transition-transform',
      tone === 'amber' && 'bg-amber-400 text-black',
      tone === 'green' && 'bg-green-500 text-black',
      tone === 'red' && 'bg-rose-500 text-white',
      tone === 'gray' && 'bg-neutral-300 text-neutral-800',
      className
    )}
  >
    {children}
  </button>
);

export function DrawingModal({ snap, reason, onClose, onAccept }: { snap: Snapshot; reason: string; onClose: () => void; onAccept: () => void }) {
  const c = snap.customer;
  if (!c) return null;
  const waiting = c.state === 'waitPaper';
  return (
    <Shell wide>
      <div className="flex flex-col gap-3 landscape:flex-row">
        <div className="flex-1">
          <div className="text-xs font-bold uppercase tracking-wide text-amber-800">
            {reason === 'change' ? '⚠ He changed his mind!' : `${c.name} shows you a drawing`}
          </div>
          <div className="mt-1 text-lg font-extrabold leading-tight">
            {reason === 'change' ? 'New hairstyle request' : 'Requested hairstyle'}
          </div>
          {snap.say && <div className="mt-2 rounded-xl bg-white p-2 text-sm font-semibold shadow-inner">“{snap.say.text}”</div>}
          <div className="mt-2 text-xs text-neutral-600">
            Study the picture: look at the <b>top</b> length, the <b>sides &amp; back</b> (fade?) and the <b>direction</b> of the hair. Some drawings are messy – use your judgement!
          </div>
          <div className="mt-3 flex gap-2">
            {waiting ? (
              <Btn tone="green" onClick={onAccept} className="flex-1">
                👍 OK, take a seat!
              </Btn>
            ) : (
              <Btn tone="amber" onClick={onClose} className="flex-1">
                Close
              </Btn>
            )}
          </div>
        </div>
        <div className="mx-auto w-full max-w-[300px] shrink-0 landscape:max-w-[260px]">
          <img src={c.drawing} alt="Requested hairstyle drawing" className="w-full rotate-[-1.5deg] rounded-md border border-amber-900/30 shadow-xl" draggable={false} />
        </div>
      </div>
    </Shell>
  );
}

const GRADE_STYLE: Record<string, { e: string; c: string }> = {
  perfect: { e: '🤩', c: 'text-green-600' },
  good: { e: '😊', c: 'text-lime-600' },
  ok: { e: '😐', c: 'text-amber-600' },
  funny: { e: '😂', c: 'text-orange-600' },
  terrible: { e: '😱', c: 'text-rose-600' },
};

export function ResultModal({ r, onCollect }: { r: ResultInfo; onCollect: () => void }) {
  const g = GRADE_STYLE[r.grade];
  return (
    <Shell>
      <div className="text-center">
        <div className="text-5xl">{g.e}</div>
        <div className={cn('text-2xl font-black', g.c)}>{r.label}</div>
        <div className="text-sm text-neutral-600">
          {r.name} wanted <b>{r.styleName}</b>
        </div>
        <div className="mx-auto my-2 flex h-24 w-24 items-center justify-center rounded-full border-8 border-amber-500 bg-white text-3xl font-black">
          {r.score}
        </div>
        {r.quote && <div className="mb-2 rounded-xl bg-white px-3 py-1.5 text-sm italic">“{r.quote}”</div>}
      </div>
      <div className="space-y-1">
        {r.lines.map((l) => (
          <div key={l.label} className="flex items-center gap-2 text-xs">
            <span className="w-28 text-neutral-600">{l.label}</span>
            <div className="h-2.5 flex-1 overflow-hidden rounded bg-neutral-300">
              <div className={cn('h-full', l.value > 75 ? 'bg-green-500' : l.value > 45 ? 'bg-amber-500' : 'bg-rose-500')} style={{ width: `${l.value}%` }} />
            </div>
            <span className="w-8 text-right font-bold">{l.value}</span>
          </div>
        ))}
      </div>
      {r.notes.length > 0 && <div className="mt-2 flex flex-wrap gap-1">{r.notes.map((n) => <span key={n} className="rounded-full bg-amber-200 px-2 py-0.5 text-[11px] font-semibold">{n}</span>)}</div>}
      <div className="mt-3 rounded-xl bg-green-100 p-2 text-center text-sm">
        Fee <b>₹{r.pay}</b> {r.tip > 0 && <>+ tip <b>₹{r.tip}</b></>}
      </div>
      <Btn tone="green" onClick={onCollect} className="mt-3 w-full text-lg">
        💵 Collect ₹{r.total}
      </Btn>
    </Shell>
  );
}

export function DayEndModal({ s, onNext }: { s: DaySummary; onNext: () => void }) {
  return (
    <Shell>
      <div className="text-center">
        <div className="text-4xl">🌇</div>
        <div className="text-2xl font-black">Day {s.day} complete!</div>
        <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
          <div className="rounded-xl bg-white p-2">
            <div className="text-xs text-neutral-500">Earned today</div>
            <div className="text-xl font-black text-green-600">₹{s.earned}</div>
          </div>
          <div className="rounded-xl bg-white p-2">
            <div className="text-xs text-neutral-500">Customers</div>
            <div className="text-xl font-black">{s.served}</div>
          </div>
          <div className="rounded-xl bg-white p-2">
            <div className="text-xs text-neutral-500">Average score</div>
            <div className="text-xl font-black">{s.avg}</div>
          </div>
          <div className="rounded-xl bg-white p-2">
            <div className="text-xs text-neutral-500">Shop reputation</div>
            <div className="text-lg font-black text-amber-500">{'★'.repeat(Math.round(s.rep))}{'☆'.repeat(5 - Math.round(s.rep))}</div>
          </div>
        </div>
        <div className="mt-2 text-xs text-neutral-600">Better reputation = more customers and bigger fees.</div>
        <Btn tone="amber" onClick={onNext} className="mt-3 w-full text-lg">
          ☀ Start Day {s.day + 1}
        </Btn>
      </div>
    </Shell>
  );
}

export function PauseModal({
  onResume,
  onSettings,
  onHelp,
  onRestart,
  onFullscreen,
}: {
  onResume: () => void;
  onSettings: () => void;
  onHelp: () => void;
  onRestart: () => void;
  onFullscreen: () => void;
}) {
  return (
    <Shell>
      <div className="mb-3 text-center text-2xl font-black">⏸ Paused</div>
      <div className="flex flex-col gap-2">
        <Btn tone="green" onClick={onResume}>▶ Resume</Btn>
        <Btn onClick={onSettings}>⚙ Settings</Btn>
        <Btn tone="gray" onClick={onHelp}>❓ How to play</Btn>
        <Btn tone="gray" onClick={onFullscreen}>⛶ Fullscreen / landscape</Btn>
        <Btn tone="red" onClick={onRestart}>↻ Restart (erase progress)</Btn>
      </div>
      <div className="mt-2 text-center text-[11px] text-neutral-500">Progress is saved automatically.</div>
    </Shell>
  );
}

const Row = ({ label, children }: { label: string; children: ReactNode }) => (
  <label className="flex items-center justify-between gap-3 py-1.5 text-sm font-semibold">
    <span>{label}</span>
    {children}
  </label>
);

export function SettingsModal({ s, onChange, onClose }: { s: Settings; onChange: (s: Settings) => void; onClose: () => void }) {
  const slider = (key: 'master' | 'sfx' | 'amb', min = 0, max = 1) => (
    <input type="range" min={min} max={max} step={0.05} value={s[key]} onChange={(e) => onChange({ ...s, [key]: parseFloat(e.target.value) })} className="w-40 accent-amber-600" />
  );
  const toggle = (key: 'voice' | 'mirror' | 'shadows' | 'guide') => (
    <button onClick={() => onChange({ ...s, [key]: !s[key] })} className={cn('w-16 rounded-full px-3 py-1 text-xs font-extrabold', s[key] ? 'bg-green-500 text-black' : 'bg-neutral-400 text-white')}>
      {s[key] ? 'ON' : 'OFF'}
    </button>
  );
  return (
    <Shell>
      <div className="mb-2 text-center text-xl font-black">⚙ Settings</div>
      <Row label="Master volume">{slider('master')}</Row>
      <Row label="Effects volume">{slider('sfx')}</Row>
      <Row label="Village ambience">{slider('amb')}</Row>
      <Row label="Customer voices">{toggle('voice')}</Row>
      <Row label="Look sensitivity">
        <input type="range" min={0.4} max={2.2} step={0.1} value={s.sens} onChange={(e) => onChange({ ...s, sens: parseFloat(e.target.value) })} className="w-40 accent-amber-600" />
      </Row>
      <Row label="Hair guide bars">{toggle('guide')}</Row>
      <Row label="Mirror reflection">{toggle('mirror')}</Row>
      <Row label="Shadows">{toggle('shadows')}</Row>
      <Row label="Graphics quality">
        <input type="range" min={0.5} max={1} step={0.05} value={s.quality} onChange={(e) => onChange({ ...s, quality: parseFloat(e.target.value) })} className="w-40 accent-amber-600" />
      </Row>
      <div className="text-[11px] text-neutral-500">Lower quality + no mirror/shadows = smoother on older phones.</div>
      <Btn tone="amber" onClick={onClose} className="mt-3 w-full">Done</Btn>
    </Shell>
  );
}

export function HelpModal({ onClose }: { onClose: () => void }) {
  return (
    <Shell wide>
      <div className="mb-2 text-center text-xl font-black">How to play</div>
      <ol className="list-decimal space-y-1.5 pl-5 text-sm">
        <li><b>Left joystick</b> walks. <b>Drag the right side</b> of the screen to look around.</li>
        <li>A customer walks in and shows a <b>hand-drawn hairstyle</b> 📄. Study it, then accept.</li>
        <li>Walk to the <b>table on the right wall</b> and tap a tool (or use the bottom bar). Tap again / “Put down” to drop it.</li>
        <li>Near the chair press <b>✂ Start haircut</b>. Now <b>touch &amp; drag on the head</b> to use the tool – nothing is cut until you touch! Lift your finger to stop instantly.</li>
        <li>Drag on empty space or use the left stick to <b>orbit</b> and inspect every angle.</li>
        <li>🔌 <b>Clipper</b> cuts down to the guard length (pick the guard!) · ✂️ <b>Scissors</b> trim gradually · 🔪 <b>Razor</b> shaves to skin (neckline!) · 💈 <b>Comb</b> sweeps hair left/right/up.</li>
        <li>💦 Spray wets hair · 🖌️ Brush &amp; 🧣 towel clean the cape · 🧴 Talcum is the finishing touch.</li>
        <li>The <b>Hair guide</b> bars show current length vs the target tick. Avoid the face – customers hate that!</li>
        <li>Press <b>✔ Finish cut</b>. Customers check the mirror, react (sometimes dramatically!) and pay. Great cuts = tips &amp; reputation.</li>
      </ol>
      <div className="mt-2 text-[11px] text-neutral-500">Desktop: WASD move · drag mouse look · E interact · 1-8 tools · Q put down</div>
      <Btn tone="amber" onClick={onClose} className="mt-3 w-full">Got it</Btn>
    </Shell>
  );
}

export function TitleScreen({ onPlay, onHelp, hasSave, day }: { onPlay: () => void; onHelp: () => void; hasSave: boolean; day: number }) {
  return (
    <div className="absolute inset-0 z-40 flex flex-col items-center justify-center overflow-y-auto bg-gradient-to-b from-sky-300/85 via-amber-200/80 to-amber-700/90 p-4 text-center backdrop-blur-[3px]">
      <div className="mb-2 flex items-center gap-3">
        <div className="h-24 w-6 rounded-full border-2 border-neutral-300 bg-[repeating-linear-gradient(45deg,#c0392b_0_10px,#fff_10px_20px,#2b5fb0_20px_30px)] shadow-lg" />
        <div>
          <div className="text-4xl font-black leading-none text-red-800 drop-shadow sm:text-6xl" style={{ fontFamily: 'Georgia, serif' }}>VILLAGE BARBER</div>
          <div className="mt-1 text-lg font-extrabold tracking-wider text-amber-950 sm:text-2xl">Funny Haircut Simulator</div>
          <div className="text-sm font-bold text-amber-900">ശ്രീ മുരുകൻ സലൂൺ · Kerala</div>
        </div>
        <div className="h-24 w-6 rounded-full border-2 border-neutral-300 bg-[repeating-linear-gradient(45deg,#c0392b_0_10px,#fff_10px_20px,#2b5fb0_20px_30px)] shadow-lg" />
      </div>
      <div className="mb-4 max-w-md text-sm font-semibold text-amber-950">
        Copy the drawing… or don’t. Every customer is different, every haircut is a surprise! ✂️😂
      </div>
      <div className="flex w-full max-w-xs flex-col gap-2">
        <Btn tone="green" onClick={onPlay} className="text-xl">
          ▶ {hasSave ? `Continue – Day ${day}` : 'Play'}
        </Btn>
        <Btn tone="gray" onClick={onHelp}>❓ How to play</Btn>
      </div>
      <div className="mt-3 text-[11px] font-semibold text-amber-950/80">Best played in landscape · headphones recommended 🎧</div>
    </div>
  );
}
