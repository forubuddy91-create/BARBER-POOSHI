import { useEffect, useRef, useState } from 'react';

export function Joystick({ onMove, size = 124 }: { onMove: (x: number, y: number) => void; size?: number }) {
  const base = useRef<HTMLDivElement>(null);
  const id = useRef<number | null>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const R = size * 0.36;

  const handle = (e: React.PointerEvent) => {
    const r = base.current!.getBoundingClientRect();
    let dx = e.clientX - (r.left + r.width / 2);
    let dy = e.clientY - (r.top + r.height / 2);
    const d = Math.hypot(dx, dy);
    if (d > R) {
      dx *= R / d;
      dy *= R / d;
    }
    setKnob({ x: dx, y: dy });
    onMove(dx / R, -dy / R);
  };
  const end = () => {
    id.current = null;
    setKnob({ x: 0, y: 0 });
    onMove(0, 0);
  };
  useEffect(() => () => onMove(0, 0), [onMove]);

  return (
    <div
      ref={base}
      className="pointer-events-auto relative rounded-full border-2 border-white/30 bg-black/30 backdrop-blur-sm"
      style={{ width: size, height: size, touchAction: 'none' }}
      onPointerDown={(e) => {
        e.preventDefault();
        (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
        id.current = e.pointerId;
        handle(e);
      }}
      onPointerMove={(e) => {
        if (id.current === e.pointerId) handle(e);
      }}
      onPointerUp={end}
      onPointerCancel={end}
    >
      <div className="absolute inset-0 flex items-center justify-center text-white/25 text-[10px] font-bold select-none">
        <span className="absolute top-1">▲</span>
        <span className="absolute bottom-1">▼</span>
        <span className="absolute left-2">◀</span>
        <span className="absolute right-2">▶</span>
      </div>
      <div
        className="absolute rounded-full bg-amber-300/80 border-2 border-amber-100 shadow-lg"
        style={{
          width: size * 0.4,
          height: size * 0.4,
          left: size / 2 - (size * 0.4) / 2 + knob.x,
          top: size / 2 - (size * 0.4) / 2 + knob.y,
        }}
      />
    </div>
  );
}
