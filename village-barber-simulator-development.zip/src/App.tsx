import { useCallback, useEffect, useRef, useState } from 'react';
import { Game, Snapshot, GameEvent, ResultInfo, DaySummary, Settings, DEFAULT_SETTINGS } from './game/engine';
import { ToolId } from './game/tools';
import { Hud } from './ui/Hud';
import { DayEndModal, DrawingModal, HelpModal, PauseModal, ResultModal, SettingsModal, TitleScreen } from './ui/Modals';

export default function App() {
  const hostRef = useRef<HTMLDivElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [snap, setSnap] = useState<Snapshot | null>(null);
  const [error, setError] = useState('');
  const [title, setTitle] = useState(true);
  const [drawing, setDrawing] = useState<string | null>(null);
  const [result, setResult] = useState<ResultInfo | null>(null);
  const [dayEnd, setDayEnd] = useState<DaySummary | null>(null);
  const [pause, setPause] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [help, setHelp] = useState(false);
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [toast, setToast] = useState<{ t: string; k: number } | null>(null);
  const [cash, setCash] = useState<{ a: number; k: number } | null>(null);

  useEffect(() => {
    const host = hostRef.current!;
    const canvas = document.createElement('canvas');
    canvas.className = 'absolute inset-0 block h-full w-full';
    host.appendChild(canvas);
    let game: Game | null = null;
    let toastTimer = 0;
    let cashTimer = 0;
    try {
      const onEvent = (e: GameEvent) => {
        if (e.type === 'drawing') setDrawing(e.reason);
        else if (e.type === 'result') setResult(e.result);
        else if (e.type === 'dayEnd') setDayEnd(e.summary);
        else if (e.type === 'cash') {
          setCash({ a: e.amount, k: Date.now() });
          window.clearTimeout(cashTimer);
          cashTimer = window.setTimeout(() => setCash(null), 1900);
        } else if (e.type === 'toast') {
          setToast({ t: e.text, k: Date.now() });
          window.clearTimeout(toastTimer);
          toastTimer = window.setTimeout(() => setToast(null), 2600);
        }
      };
      game = new Game(canvas, setSnap, onEvent);
      gameRef.current = game;
      (window as unknown as { __game?: Game }).__game = game;
      setSettings(game.settings);
      game.emit();
    } catch (err) {
      console.error(err);
      setError('Could not start 3D graphics on this device/browser. Please try Chrome with hardware acceleration enabled.');
    }
    return () => {
      window.clearTimeout(toastTimer);
      window.clearTimeout(cashTimer);
      game?.dispose();
      gameRef.current = null;
      canvas.remove();
    };
  }, []);

  const anyModal = title || drawing !== null || result !== null || dayEnd !== null || pause || settingsOpen || help;
  useEffect(() => {
    gameRef.current?.setModal(anyModal);
  }, [anyModal]);
  useEffect(() => {
    gameRef.current?.setPaused(pause || settingsOpen);
  }, [pause, settingsOpen]);

  const g = () => gameRef.current;
  const onMove = useCallback((x: number, y: number) => gameRef.current?.setMove(x, y), []);

  const fullscreen = async () => {
    try {
      await document.documentElement.requestFullscreen();
      const o = screen.orientation as ScreenOrientation & { lock?: (o: string) => Promise<void> };
      await o.lock?.('landscape');
    } catch {
      /* not supported */
    }
  };

  return (
    <div className="relative h-full w-full overflow-hidden bg-[#1b1208]" style={{ touchAction: 'none' }}>
      <div ref={hostRef} className="absolute inset-0" />
      {error && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black p-6 text-center text-white">{error}</div>
      )}
      {snap && !title && (
        <Hud
          snap={snap}
          onMove={onMove}
          onTool={(t: ToolId) => g()?.selectTool(t)}
          onPutDown={() => g()?.putDown()}
          onInteract={() => g()?.interact()}
          onFinish={() => g()?.finish()}
          onWalk={() => g()?.exitCut()}
          onGuard={(n) => g()?.setGuard(n)}
          onPause={() => setPause(true)}
          onPaper={() => setDrawing('view')}
        />
      )}

      {toast && (
        <div key={toast.k} className="pointer-events-none absolute left-1/2 top-24 z-20 -translate-x-1/2 animate-[pop_.2s_ease-out] rounded-full bg-rose-600/95 px-4 py-2 text-center text-xs font-bold text-white shadow-xl sm:text-sm">
          {toast.t}
        </div>
      )}
      {cash && (
        <div
          key={cash.k}
          className="pointer-events-none absolute left-1/2 top-1/2 z-20 text-4xl font-black text-green-300 drop-shadow-[0_2px_2px_rgba(0,0,0,0.9)]"
          style={{ animation: 'cashfloat 1.8s ease-out forwards' }}
        >
          💵 +₹{cash.a}
        </div>
      )}

      {title && snap && (
        <TitleScreen
          hasSave={snap.totalServed > 0 || snap.day > 1}
          day={snap.day}
          onHelp={() => setHelp(true)}
          onPlay={() => {
            g()?.begin();
            setTitle(false);
          }}
        />
      )}
      {drawing !== null && snap && (
        <DrawingModal
          snap={snap}
          reason={drawing}
          onClose={() => setDrawing(null)}
          onAccept={() => {
            setDrawing(null);
            g()?.acceptCustomer();
          }}
        />
      )}
      {result && (
        <ResultModal
          r={result}
          onCollect={() => {
            setResult(null);
            g()?.collect();
          }}
        />
      )}
      {dayEnd && (
        <DayEndModal
          s={dayEnd}
          onNext={() => {
            setDayEnd(null);
            g()?.nextDay();
          }}
        />
      )}
      {pause && !settingsOpen && !help && (
        <PauseModal
          onResume={() => setPause(false)}
          onSettings={() => setSettingsOpen(true)}
          onHelp={() => setHelp(true)}
          onFullscreen={fullscreen}
          onRestart={() => {
            if (window.confirm('Erase all progress and restart?')) {
              g()?.restart();
              setPause(false);
            }
          }}
        />
      )}
      {settingsOpen && (
        <SettingsModal
          s={settings}
          onChange={(s) => {
            setSettings(s);
            g()?.applySettings(s);
          }}
          onClose={() => setSettingsOpen(false)}
        />
      )}
      {help && <HelpModal onClose={() => setHelp(false)} />}
    </div>
  );
}
