export type Region = 'front' | 'top' | 'left' | 'right' | 'back' | 'neck';
export const REGIONS: Region[] = ['front', 'top', 'left', 'right', 'back', 'neck'];
export type Sweep = 'none' | 'left' | 'right' | 'up';

export interface HairStyle {
  id: number;
  name: string;
  top: number;
  front: number;
  sideHigh: number;
  sideLow: number;
  backHigh: number;
  backLow: number;
  mid: number; // height where fade finishes (0..1)
  sweep: Sweep;
  curly?: boolean;
  spiky?: boolean;
  price: number;
}

export const STYLES: HairStyle[] = [
  { id: 0, name: 'Simple Crew Cut', top: 0.25, front: 0.25, sideHigh: 0.15, sideLow: 0.08, backHigh: 0.15, backLow: 0.08, mid: 0.5, sweep: 'up', price: 40 },
  { id: 1, name: 'Side-Part Haircut', top: 0.5, front: 0.5, sideHigh: 0.25, sideLow: 0.14, backHigh: 0.25, backLow: 0.12, mid: 0.5, sweep: 'left', price: 55 },
  { id: 2, name: 'Low Fade', top: 0.4, front: 0.4, sideHigh: 0.3, sideLow: 0.02, backHigh: 0.3, backLow: 0.02, mid: 0.3, sweep: 'none', price: 65 },
  { id: 3, name: 'High Fade', top: 0.5, front: 0.45, sideHigh: 0.4, sideLow: 0.0, backHigh: 0.4, backLow: 0.0, mid: 0.7, sweep: 'none', price: 70 },
  { id: 4, name: 'Mushroom Haircut', top: 0.65, front: 0.65, sideHigh: 0.55, sideLow: 0.1, backHigh: 0.5, backLow: 0.1, mid: 0.4, sweep: 'none', price: 50 },
  { id: 5, name: 'Short Spiky Hair', top: 0.35, front: 0.35, sideHigh: 0.12, sideLow: 0.05, backHigh: 0.12, backLow: 0.05, mid: 0.5, sweep: 'up', spiky: true, price: 50 },
  { id: 6, name: 'Side-Swept Style', top: 0.6, front: 0.65, sideHigh: 0.3, sideLow: 0.1, backHigh: 0.3, backLow: 0.1, mid: 0.5, sweep: 'right', price: 60 },
  { id: 7, name: 'Undercut', top: 0.75, front: 0.7, sideHigh: 0.06, sideLow: 0.03, backHigh: 0.06, backLow: 0.03, mid: 0.8, sweep: 'left', price: 75 },
  { id: 8, name: 'Curly Short Cut', top: 0.45, front: 0.4, sideHigh: 0.3, sideLow: 0.15, backHigh: 0.3, backLow: 0.15, mid: 0.5, sweep: 'none', curly: true, price: 55 },
  { id: 9, name: 'Classic Schoolboy', top: 0.3, front: 0.3, sideHigh: 0.2, sideLow: 0.1, backHigh: 0.2, backLow: 0.1, mid: 0.5, sweep: 'left', price: 35 },
  { id: 10, name: 'Short Back & Sides', top: 0.45, front: 0.45, sideHigh: 0.12, sideLow: 0.03, backHigh: 0.12, backLow: 0.03, mid: 0.5, sweep: 'none', price: 50 },
  { id: 11, name: 'Textured Crop', top: 0.35, front: 0.45, sideHigh: 0.15, sideLow: 0.05, backHigh: 0.15, backLow: 0.05, mid: 0.5, sweep: 'none', price: 60 },
  { id: 12, name: 'Longer Top, Short Sides', top: 0.8, front: 0.7, sideHigh: 0.15, sideLow: 0.04, backHigh: 0.15, backLow: 0.04, mid: 0.75, sweep: 'none', price: 70 },
  { id: 13, name: 'Village Traditional', top: 0.4, front: 0.4, sideHigh: 0.22, sideLow: 0.12, backHigh: 0.22, backLow: 0.1, mid: 0.5, sweep: 'right', price: 30 },
];

const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const sstep = (a: number, b: number, x: number) => {
  const t = Math.min(1, Math.max(0, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
};
export const clamp = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x));

/** target hair length (0..1) of a tuft on the given region at height h (0..1). */
export function targetLength(s: HairStyle, region: Region, h: number): number {
  switch (region) {
    case 'top':
      return s.top;
    case 'front':
      return s.front;
    case 'left':
    case 'right':
      return lerp(s.sideLow, s.sideHigh, sstep(s.mid - 0.3, s.mid + 0.3, h));
    case 'back':
      return lerp(s.backLow, s.backHigh, sstep(s.mid - 0.3, s.mid + 0.3, h));
    case 'neck':
      return s.backLow * 0.5;
  }
}

export function lengthWord(l: number) {
  if (l < 0.07) return 'skin / bald';
  if (l < 0.18) return 'very short';
  if (l < 0.33) return 'short';
  if (l < 0.5) return 'medium';
  if (l < 0.68) return 'long';
  return 'very long';
}

export function describeStyle(s: HairStyle): string[] {
  const out: string[] = [];
  out.push(`Top: ${lengthWord(s.top)}`);
  out.push(`Front: ${lengthWord(s.front)}`);
  if (s.sideHigh - s.sideLow > 0.18) out.push(`Sides/back: fade (${lengthWord(s.sideLow)} → ${lengthWord(s.sideHigh)})`);
  else out.push(`Sides/back: ${lengthWord((s.sideHigh + s.sideLow) / 2)}`);
  if (s.sweep === 'left') out.push('Comb hair to LEFT');
  if (s.sweep === 'right') out.push('Comb hair to RIGHT');
  if (s.sweep === 'up') out.push('Hair standing up');
  return out;
}

// ---------------------------------------------------------------- drawing

function mulberry(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

interface DrawOpts {
  messy: boolean;
  seed: number;
  poster?: boolean;
}

export function renderDrawing(style: HairStyle, opts: DrawOpts): HTMLCanvasElement {
  const W = 480;
  const H = 600;
  const cv = document.createElement('canvas');
  cv.width = W;
  cv.height = H;
  const ctx = cv.getContext('2d')!;
  const rnd = mulberry(opts.seed * 7919 + style.id * 31 + 5);
  const wob = opts.messy ? 3.4 : 1.1;
  const ink = opts.poster ? '#1a1410' : '#2a2a35';
  const R = (a: number, b: number) => a + (b - a) * rnd();

  // paper
  ctx.fillStyle = opts.poster ? '#ffd35a' : '#f3ead0';
  ctx.fillRect(0, 0, W, H);
  if (!opts.poster) {
    ctx.strokeStyle = 'rgba(80,120,200,0.35)';
    ctx.lineWidth = 1;
    for (let y = 40; y < H; y += 28) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(W, y);
      ctx.stroke();
    }
    ctx.strokeStyle = 'rgba(220,60,60,0.5)';
    ctx.beginPath();
    ctx.moveTo(48, 0);
    ctx.lineTo(48, H);
    ctx.stroke();
    // stains
    for (let i = 0; i < 4; i++) {
      const g = ctx.createRadialGradient(R(0, W), R(0, H), 2, R(0, W), R(0, H), 60);
      ctx.fillStyle = `rgba(150,110,50,${R(0.04, 0.1)})`;
      ctx.beginPath();
      ctx.arc(R(30, W - 30), R(30, H - 30), R(15, 50), 0, 7);
      ctx.fill();
      void g;
    }
    // crease
    ctx.strokeStyle = 'rgba(0,0,0,0.08)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, H / 2);
    ctx.lineTo(W, H / 2 + 3);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(W / 2, 0);
    ctx.lineTo(W / 2 - 4, H);
    ctx.stroke();
  }

  const stroke = (pts: [number, number][], w = 2.2, close = false, alpha = 1) => {
    for (let pass = 0; pass < 2; pass++) {
      ctx.beginPath();
      ctx.strokeStyle = ink;
      ctx.globalAlpha = (pass === 0 ? 0.9 : 0.45) * alpha;
      ctx.lineWidth = w * (pass === 0 ? 1 : 0.7);
      ctx.lineJoin = 'round';
      ctx.lineCap = 'round';
      pts.forEach(([x, y], i) => {
        const px = x + (rnd() - 0.5) * wob * 2;
        const py = y + (rnd() - 0.5) * wob * 2;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      });
      if (close) ctx.closePath();
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  };

  const hatch = (path: [number, number][], spacing: number, angle = 0.9, alpha = 0.55) => {
    ctx.save();
    ctx.beginPath();
    path.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
    ctx.closePath();
    ctx.clip();
    ctx.strokeStyle = ink;
    ctx.globalAlpha = alpha;
    ctx.lineWidth = 1.3;
    const dx = Math.cos(angle);
    const dy = Math.sin(angle);
    for (let t = -500; t < 500; t += spacing) {
      ctx.beginPath();
      const cx = 240 + -dy * t;
      const cy = 300 + dx * t;
      ctx.moveTo(cx - dx * 700, cy - dy * 700 + (rnd() - 0.5) * wob);
      ctx.lineTo(cx + dx * 700, cy + dy * 700 + (rnd() - 0.5) * wob);
      ctx.stroke();
    }
    ctx.restore();
  };

  const ellipsePts = (cx: number, cy: number, rx: number, ry: number, n = 28): [number, number][] => {
    const p: [number, number][] = [];
    for (let i = 0; i <= n; i++) {
      const a = (i / n) * Math.PI * 2;
      p.push([cx + Math.cos(a) * rx, cy + Math.sin(a) * ry]);
    }
    return p;
  };

  const lenW = (l: number) => 0.05 + 0.75 * l;

  const front = (cx: number, cy: number, r: number) => {
    const rx = r * 0.8;
    const ry = r;
    const sideOut = r * (0.04 + 0.4 * style.sideHigh);
    const topH = r * (0.06 + 0.8 * style.top);
    // face
    stroke(ellipsePts(cx, cy, rx, ry), 2.4);
    stroke([[cx - rx * 0.97, cy - 4], [cx - rx - 10, cy - 12], [cx - rx - 12, cy + 14], [cx - rx * 0.95, cy + 16]], 1.8);
    stroke([[cx + rx * 0.97, cy - 4], [cx + rx + 10, cy - 12], [cx + rx + 12, cy + 14], [cx + rx * 0.95, cy + 16]], 1.8);
    stroke([[cx - r * 0.45, cy + ry * 0.9], [cx - r * 0.35, cy + ry * 1.3]], 2);
    stroke([[cx + r * 0.45, cy + ry * 0.9], [cx + r * 0.35, cy + ry * 1.3]], 2);
    // eyes, nose, mouth
    const ey = cy - r * 0.02;
    stroke(ellipsePts(cx - r * 0.3, ey, 6, 4, 8), 1.8);
    stroke(ellipsePts(cx + r * 0.3, ey, 6, 4, 8), 1.8);
    stroke([[cx - r * 0.42, ey - 14], [cx - r * 0.2, ey - 16]], 2);
    stroke([[cx + r * 0.2, ey - 16], [cx + r * 0.42, ey - 14]], 2);
    stroke([[cx, ey + 4], [cx - 4, cy + r * 0.28], [cx + 5, cy + r * 0.3]], 1.8);
    stroke(
      [[cx - r * 0.25, cy + r * 0.5], [cx - r * 0.1, cy + r * 0.58], [cx + r * 0.1, cy + r * 0.58], [cx + r * 0.25, cy + r * 0.5]],
      1.8
    );
    // hair outline
    const poly: [number, number][] = [];
    const N = 34;
    for (let i = 0; i <= N; i++) {
      const a = Math.PI + 0.28 - ((Math.PI + 0.56) * i) / N;
      let k = 1;
      if (style.spiky) k = i % 2 ? 1.0 : 1.0 + 0.55 * Math.max(0, Math.sin(a));
      let rxx = rx + sideOut;
      let ryy = ry + topH * k;
      if (style.curly) {
        const bump = 1 + 0.09 * Math.sin(i * 2.2);
        rxx *= bump;
        ryy *= bump;
      }
      poly.push([cx + Math.cos(a) * rxx, cy - Math.sin(a) * ryy]);
    }
    const hlY = cy - ry * (0.58 - 0.5 * style.front);
    const slope = style.sweep === 'left' ? 1 : style.sweep === 'right' ? -1 : 0;
    const hair: [number, number][] = [...poly];
    hair.push([cx + rx * 0.95, cy + 4]);
    for (let i = 0; i <= 8; i++) {
      const x = cx + rx * 0.9 - (rx * 1.8 * i) / 8;
      const y = hlY - slope * ((x - cx) / rx) * r * 0.16 + (style.front > 0.5 ? Math.sin(i * 1.7) * 4 : 0);
      hair.push([x, y]);
    }
    hair.push([cx - rx * 0.95, cy + 4]);
    hatch(hair, 6 + (1 - style.top) * 5, style.sweep === 'left' ? 1.9 : 1.2, opts.messy ? 0.3 : 0.5);
    stroke(hair, 2.6, true);
    // curls
    if (style.curly) {
      for (let i = 0; i < 12; i++) {
        const a = Math.PI + 0.3 - (i / 11) * (Math.PI + 0.6);
        const px = cx + Math.cos(a) * (rx + sideOut * 0.4);
        const py = cy - Math.sin(a) * (ry + topH * 0.4);
        stroke(ellipsePts(px, py, 7, 6, 8), 1.4);
      }
    }
    // part line
    if (style.sweep === 'left' || style.sweep === 'right') {
      const px = cx + (style.sweep === 'left' ? 0.35 : -0.35) * rx;
      stroke([[px, hlY - slope * (-0.35 * slope) * 0], [px - slope * -4, cy - ry - topH * 0.9]], 3.2);
      const dir = style.sweep === 'left' ? -1 : 1;
      for (let i = 0; i < 4; i++) {
        const sx = px + dir * (10 + i * 22);
        stroke([[px + dir * i * 4, cy - ry - topH * 0.5 + i * 6], [sx, hlY + i * 3 - 6]], 1.6);
      }
    }
    // fade stipple on sides
    if (style.sideHigh - style.sideLow > 0.12) {
      for (let i = 0; i < 90; i++) {
        const side = rnd() < 0.5 ? -1 : 1;
        const t = rnd();
        const yy = cy + 6 - t * r * (0.2 + 1.3 * style.mid) * 0.9;
        const dens = 1 - t;
        if (rnd() > dens + 0.15) continue;
        const half = Math.sqrt(Math.max(0, 1 - ((yy - cy) / ry) ** 2)) * rx;
        const xx = cx + side * (half - rnd() * (4 + 14 * style.sideHigh));
        ctx.fillStyle = ink;
        ctx.globalAlpha = 0.6;
        ctx.beginPath();
        ctx.arc(xx + (rnd() - 0.5) * wob, yy, 1.3, 0, 7);
        ctx.fill();
        ctx.globalAlpha = 1;
      }
    }
    // undercut/short sides marker
    if (style.sideHigh < 0.08) {
      stroke([[cx - rx - 12, cy - ry * 0.3], [cx - rx * 0.6, cy - ry * 0.7]], 1.4, false, 0.7);
    }
  };

  const side = (cx: number, cy: number, r: number) => {
    // profile facing right
    const head: [number, number][] = [];
    for (let i = 0; i <= 30; i++) {
      const a = (i / 30) * Math.PI * 2;
      head.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r * 1.02]);
    }
    stroke(head, 2.4);
    // nose + face
    stroke([[cx + r * 0.98, cy - r * 0.05], [cx + r * 1.2, cy + r * 0.28], [cx + r * 0.95, cy + r * 0.34]], 2);
    stroke([[cx + r * 0.7, cy + r * 0.6], [cx + r * 0.85, cy + r * 0.62]], 2);
    stroke(ellipsePts(cx + r * 0.58, cy - r * 0.04, 5, 4, 8), 1.6);
    stroke(ellipsePts(cx - r * 0.1, cy + r * 0.12, 9, 15, 10), 1.8); // ear
    stroke([[cx - r * 0.3, cy + r * 1.0], [cx - r * 0.35, cy + r * 1.45]], 2);
    stroke([[cx + r * 0.2, cy + r * 1.0], [cx + r * 0.25, cy + r * 1.45]], 2);
    // hair band
    const ctrl: [number, number][] = [
      [0.1, style.front],
      [0.4, style.top],
      [0.62, style.top],
      [0.85, (style.backHigh + style.top) / 2 > 0 ? style.backHigh : 0],
      [1.0, style.backHigh],
      [1.2, style.backLow],
      [1.32, style.backLow],
    ];
    const lenAt = (f: number) => {
      for (let i = 0; i < ctrl.length - 1; i++) {
        if (f >= ctrl[i][0] && f <= ctrl[i + 1][0]) {
          const t = (f - ctrl[i][0]) / (ctrl[i + 1][0] - ctrl[i][0]);
          return lerp(ctrl[i][1], ctrl[i + 1][1], t);
        }
      }
      return ctrl[ctrl.length - 1][1];
    };
    const outer: [number, number][] = [];
    const inner: [number, number][] = [];
    const M = 30;
    for (let i = 0; i <= M; i++) {
      const f = 0.1 + (1.22 * i) / M;
      const a = f * Math.PI;
      let rr = r * 1.02 + r * lenW(lenAt(f)) * (f > 0.7 ? 0.55 : 1);
      if (style.spiky && i % 2 && f < 0.8) rr += r * 0.2;
      if (style.curly) rr *= 1 + 0.07 * Math.sin(i * 2.1);
      outer.push([cx + Math.cos(a) * rr, cy - Math.sin(a) * rr]);
      inner.push([cx + Math.cos(a) * r * 0.97, cy - Math.sin(a) * r * 0.99]);
    }
    const path = [...outer, ...inner.reverse()];
    hatch(path, 5 + (1 - style.top) * 4, 1.0 + (style.sweep === 'right' ? 0.5 : 0), opts.messy ? 0.3 : 0.5);
    stroke(path, 2.4, true);
    // temple / side area hatch with fade
    const sideArea: [number, number][] = [];
    for (let i = 0; i <= 14; i++) {
      const a = (0.42 + (0.82 * i) / 14) * Math.PI;
      sideArea.push([cx + Math.cos(a) * r * 0.92, cy - Math.sin(a) * r * 0.92]);
    }
    sideArea.push([cx - r * 0.1, cy - r * 0.15]);
    const sp = 12 - 8 * style.sideHigh;
    hatch(sideArea, sp, 0.7, 0.4);
    if (style.sideHigh - style.sideLow > 0.12) {
      for (let i = 0; i < 40; i++) {
        const a = (0.95 + rnd() * 0.3) * Math.PI;
        const rr = r * (0.55 + rnd() * 0.4);
        ctx.fillStyle = ink;
        ctx.globalAlpha = 0.5;
        ctx.beginPath();
        ctx.arc(cx + Math.cos(a) * rr, cy - Math.sin(a) * rr * 0.98 + r * 0.2, 1.2, 0, 7);
        ctx.fill();
        ctx.globalAlpha = 1;
      }
    }
  };

  ctx.font = '26px "Segoe Print","Bradley Hand","Comic Sans MS","Chalkboard SE",cursive';
  ctx.fillStyle = ink;
  const hello = ['Ithu mathi!', 'Like this anna!', 'Please this one', 'This one only!', 'I want like this'];
  if (!opts.poster) {
    ctx.save();
    ctx.translate(70, 60);
    ctx.rotate(-0.04);
    ctx.fillText(opts.messy ? hello[Math.floor(rnd() * hello.length)] + '??' : hello[Math.floor(rnd() * hello.length)], 0, 0);
    ctx.restore();
  }

  if (opts.poster) {
    ctx.fillStyle = '#c0392b';
    ctx.fillRect(0, 0, W, 70);
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 34px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(style.name.toUpperCase(), W / 2, 47);
    ctx.textAlign = 'left';
    front(150, 300, 100);
    side(350, 300, 92);
    ctx.fillStyle = '#c0392b';
    ctx.font = 'bold 30px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('LATEST STYLE  ₹' + style.price, W / 2, 520);
    ctx.textAlign = 'left';
    return cv;
  }

  if (!opts.messy) {
    front(150, 230, 78);
    side(340, 245, 72);
    ctx.font = '19px "Segoe Print","Bradley Hand","Comic Sans MS",cursive';
    ctx.fillText('FRONT', 105, 372);
    ctx.fillText('SIDE', 310, 372);
    ctx.font = '30px "Segoe Print","Bradley Hand","Comic Sans MS",cursive';
    ctx.save();
    ctx.translate(70, 440);
    ctx.rotate(-0.03);
    ctx.fillText(style.name, 0, 0);
    ctx.restore();
    ctx.strokeStyle = ink;
    stroke([[70, 450], [60 + ctx.measureText(style.name).width + 10, 454]], 2);
    ctx.font = '21px "Segoe Print","Bradley Hand","Comic Sans MS",cursive';
    describeStyle(style).forEach((t, i) => ctx.fillText('• ' + t.toLowerCase(), 70, 490 + i * 28));
  } else {
    // confusing drawing
    const variant = Math.floor(rnd() * 3);
    if (variant !== 1) front(R(130, 170), R(220, 250), R(70, 85));
    if (variant !== 0) side(R(320, 350), R(235, 270), R(62, 78));
    // scribbles
    for (let i = 0; i < 5; i++) {
      const pts: [number, number][] = [];
      let x = R(60, 400);
      let y = R(90, 400);
      for (let k = 0; k < 8; k++) {
        x += R(-40, 40);
        y += R(-30, 30);
        pts.push([x, y]);
      }
      stroke(pts, 1.3, false, 0.5);
    }
    // eraser smudge
    const g = ctx.createRadialGradient(R(150, 300), R(160, 300), 5, R(150, 300), R(160, 300), 70);
    g.addColorStop(0, 'rgba(120,120,120,0.35)');
    g.addColorStop(1, 'rgba(120,120,120,0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 100, W, 300);
    ctx.fillStyle = ink;
    ctx.font = '28px "Segoe Print","Bradley Hand","Comic Sans MS",cursive';
    const notes = ['like.. this? or that?', 'sides... idk', 'short(ish)', 'you know na??', 'something like hero', 'not too much ok'];
    ctx.fillText(notes[Math.floor(rnd() * notes.length)], 70, 430);
    ctx.fillText('?? ' + style.name.split(' ')[0].slice(0, 4) + '...', 80, 480);
    stroke([[60, 520], [200, 560], [300, 515], [420, 560]], 2, false, 0.7);
    stroke([[200, 440], [360, 400]], 3, false, 0.8);
    stroke([[200, 400], [360, 440]], 3, false, 0.8);
    ctx.font = '20px "Segoe Print","Bradley Hand","Comic Sans MS",cursive';
    describeStyle(style)
      .slice(0, 1 + Math.floor(rnd() * 2))
      .forEach((t, i) => ctx.fillText('(' + t.toLowerCase() + '?)', 260, 500 + i * 26));
  }
  return cv;
}
