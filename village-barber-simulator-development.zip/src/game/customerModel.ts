import * as THREE from 'three';
import { HairSystem, HEAD_R } from './hair';
import { HairStyle, STYLES } from './hairstyles';

export type Personality = 'calm' | 'impatient' | 'dramatic' | 'jolly' | 'fussy' | 'sleepy';
export type Expr = 'neutral' | 'happy' | 'angry' | 'shock' | 'sad' | 'laugh' | 'sleepy' | 'smug';

export interface CustomerData {
  name: string;
  skin: string;
  hair: string;
  shirt: string;
  pants: string;
  shorts: boolean;
  stripes: boolean;
  glasses: boolean;
  tilak: boolean;
  personality: Personality;
  patience: number; // seconds
  style: HairStyle;
  startTop: number;
  startSide: number;
  messy: boolean;
  willChange: boolean;
  pitch: number;
  curly: boolean;
}

const NAMES = [
  'Arun', 'Anu', 'Vishnu', 'Midhun', 'Akhil', 'Adithya', 'Sreejith', 'Rahul', 'Nandu', 'Kannan', 'Appu', 'Kuttan',
  'Abhijith', 'Jishnu', 'Hari', 'Gokul', 'Sanju', 'Vyshakh', 'Bibin', 'Anand', 'Jibin', 'Ashwin', 'Amal', 'Abhi',
  'Muthu', 'Karthik', 'Surya', 'Ravi', 'Unni', 'Achu', 'Manu', 'Sachin', 'Vineeth', 'Shibu', 'Pappu', 'Shyam',
];
const SKINS = ['#8d5a3b', '#a56b46', '#b87b51', '#c68a5e', '#7a4a30', '#6b4029', '#d09a6b', '#946040'];
const HAIRS = ['#120d0b', '#1a120d', '#241810', '#2f1e12', '#3a2616', '#120d0b', '#1c1410', '#4a2f18'];
const SHIRTS = ['#e74c3c', '#2980b9', '#27ae60', '#f1c40f', '#8e44ad', '#e67e22', '#16a085', '#ecf0f1', '#d35400', '#34495e', '#ff6b9d', '#00a8a8'];
const PANTS = ['#2c3e50', '#6d5a3a', '#3b3b3b', '#1f4e79', '#7f6a4d', '#4a4a6a', '#8c7b5a', '#2e4a35'];
const PERS: Personality[] = ['calm', 'impatient', 'dramatic', 'jolly', 'fussy', 'sleepy', 'calm', 'jolly', 'dramatic', 'impatient'];

const pick = <T,>(a: T[]): T => a[Math.floor(Math.random() * a.length)];

export function randomCustomer(lastStyle = -1): CustomerData {
  let style = pick(STYLES);
  while (style.id === lastStyle) style = pick(STYLES);
  const personality = pick(PERS);
  const patBase = personality === 'impatient' ? 80 : personality === 'calm' ? 190 : personality === 'sleepy' ? 240 : personality === 'fussy' ? 130 : 150;
  const school = Math.random() < 0.25;
  const golden = Math.random() < 0.04;
  return {
    name: pick(NAMES),
    skin: pick(SKINS),
    hair: golden ? '#9a6b2a' : pick(HAIRS),
    shirt: school ? '#f4f4f4' : pick(SHIRTS),
    pants: school ? '#3a4f7a' : pick(PANTS),
    shorts: school || Math.random() < 0.45,
    stripes: !school && Math.random() < 0.3,
    glasses: Math.random() < 0.13,
    tilak: Math.random() < 0.22,
    personality,
    patience: patBase * (0.85 + Math.random() * 0.4),
    style,
    startTop: 0.78 + Math.random() * 0.22,
    startSide: 0.55 + Math.random() * 0.4,
    messy: Math.random() < 0.28,
    willChange: Math.random() < 0.3,
    pitch: 1.35 + Math.random() * 0.55,
    curly: style.curly === true || Math.random() < 0.08,
  };
}

// ------------------------------------------------------------ shared geometry
const GEO = {
  sphere: new THREE.SphereGeometry(1, 20, 14),
  cyl: new THREE.CylinderGeometry(1, 1, 1, 14, 1),
  box: new THREE.BoxGeometry(1, 1, 1),
  arc: new THREE.TorusGeometry(1, 0.1, 6, 16, Math.PI),
  ring: new THREE.TorusGeometry(1, 0.08, 6, 20),
};

interface ExprDef {
  brow: number;
  rot: number;
  eye: number;
  curve: number;
  open: number;
}
const EXPR: Record<Expr, ExprDef> = {
  neutral: { brow: 0, rot: 0, eye: 1, curve: 0.15, open: 0 },
  happy: { brow: 0.006, rot: -0.1, eye: 0.85, curve: 1, open: 0.35 },
  angry: { brow: -0.008, rot: 0.55, eye: 0.8, curve: -0.9, open: 0.1 },
  shock: { brow: 0.016, rot: -0.15, eye: 1.45, curve: -0.2, open: 1 },
  sad: { brow: 0.004, rot: -0.55, eye: 0.9, curve: -0.8, open: 0 },
  laugh: { brow: 0.01, rot: -0.2, eye: 0.25, curve: 1, open: 1 },
  sleepy: { brow: -0.004, rot: 0, eye: 0.3, curve: 0, open: 0.1 },
  smug: { brow: 0.004, rot: 0.2, eye: 0.7, curve: 0.7, open: 0 },
};

let stripeTex: Map<string, THREE.CanvasTexture> = new Map();
function stripeTexture(color: string) {
  let t = stripeTex.get(color);
  if (t) return t;
  const c = document.createElement('canvas');
  c.width = 16;
  c.height = 32;
  const g = c.getContext('2d')!;
  g.fillStyle = color;
  g.fillRect(0, 0, 16, 32);
  g.fillStyle = 'rgba(255,255,255,0.55)';
  g.fillRect(0, 4, 16, 5);
  g.fillRect(0, 20, 16, 5);
  t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  stripeTex.set(color, t);
  return t;
}

export class CustomerModel {
  root = new THREE.Group();
  headGroup = new THREE.Group();
  hair: HairSystem;
  data: CustomerData;
  pose = 0; // 0 standing, 1 seated
  walking = false;
  talk = 0;
  look = { yaw: 0, pitch: 0 };
  calmHead = false;
  cape: THREE.Group;
  flecks: THREE.InstancedMesh;
  private fleckPos: THREE.Matrix4[] = [];
  private fleckShown = -1;
  private legL = new THREE.Group();
  private legR = new THREE.Group();
  private shinL = new THREE.Group();
  private shinR = new THREE.Group();
  private armL = new THREE.Group();
  private armR = new THREE.Group();
  private foreL = new THREE.Group();
  private foreR = new THREE.Group();
  private torso: THREE.Mesh;
  private browL: THREE.Mesh;
  private browR: THREE.Mesh;
  private eyeL: THREE.Group;
  private eyeR: THREE.Group;
  private pupilL: THREE.Mesh;
  private pupilR: THREE.Mesh;
  private mouthArc: THREE.Mesh;
  private mouthOpen: THREE.Mesh;
  private ex: ExprDef = { ...EXPR.neutral };
  private target: ExprDef = { ...EXPR.neutral };
  private blinkT = 2 + Math.random() * 3;
  private t = Math.random() * 10;
  private mats: THREE.Material[] = [];

  constructor(data: CustomerData) {
    this.data = data;
    const mat = (color: string | number, rough = 0.85) => {
      const m = new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: 0 });
      this.mats.push(m);
      return m;
    };
    const skin = mat(data.skin, 0.7);
    const shirtM = mat(0xffffff);
    if (data.stripes) shirtM.map = stripeTexture(data.shirt);
    else shirtM.color.set(data.shirt);
    const pantsM = mat(data.pants);
    const shoeM = mat(0x2a2018);
    const mk = (g: THREE.BufferGeometry, m: THREE.Material, sx: number, sy: number, sz: number, x = 0, y = 0, z = 0) => {
      const me = new THREE.Mesh(g, m);
      me.scale.set(sx, sy, sz);
      me.position.set(x, y, z);
      me.castShadow = true;
      return me;
    };

    // legs
    const makeLeg = (leg: THREE.Group, shin: THREE.Group, x: number) => {
      leg.position.set(x, 0.62, 0);
      leg.add(mk(GEO.cyl, pantsM, 0.065, 0.3, 0.065, 0, -0.15, 0));
      shin.position.set(0, -0.3, 0);
      shin.add(mk(GEO.cyl, data.shorts ? skin : pantsM, 0.052, 0.3, 0.052, 0, -0.15, 0));
      shin.add(mk(GEO.box, shoeM, 0.06, 0.035, 0.12, 0, -0.31, 0.025));
      leg.add(shin);
      this.root.add(leg);
    };
    makeLeg(this.legL, this.shinL, 0.07);
    makeLeg(this.legR, this.shinR, -0.07);

    // torso
    this.torso = mk(GEO.cyl, shirtM, 0.16, 0.46, 0.1, 0, 0.85, 0);
    this.root.add(this.torso);
    this.root.add(mk(GEO.cyl, skin, 0.045, 0.1, 0.045, 0, 1.1, 0));

    // arms
    const makeArm = (arm: THREE.Group, fore: THREE.Group, x: number) => {
      arm.position.set(x, 1.04, 0);
      arm.add(mk(GEO.cyl, shirtM, 0.045, 0.16, 0.045, 0, -0.08, 0));
      fore.position.set(0, -0.16, 0);
      fore.add(mk(GEO.cyl, skin, 0.036, 0.16, 0.036, 0, -0.08, 0));
      fore.add(mk(GEO.sphere, skin, 0.04, 0.04, 0.04, 0, -0.18, 0));
      arm.add(fore);
      this.root.add(arm);
    };
    makeArm(this.armL, this.foreL, 0.2);
    makeArm(this.armR, this.foreR, -0.2);

    // head
    this.headGroup.position.set(0, 1.22, 0);
    this.headGroup.add(mk(GEO.sphere, skin, HEAD_R, HEAD_R, HEAD_R));
    // ears
    this.headGroup.add(mk(GEO.sphere, skin, 0.022, 0.034, 0.02, 0.117, 0, -0.005));
    this.headGroup.add(mk(GEO.sphere, skin, 0.022, 0.034, 0.02, -0.117, 0, -0.005));
    // eyes
    const white = mat(0xffffff, 0.3);
    const dark = mat(0x0b0806, 0.2);
    const makeEye = (x: number) => {
      const g = new THREE.Group();
      g.position.set(x, 0.018, 0.1);
      const w = mk(GEO.sphere, white, 0.025, 0.029, 0.014);
      g.add(w);
      const p = mk(GEO.sphere, dark, 0.013, 0.015, 0.008, 0, 0, 0.011);
      g.add(p);
      this.headGroup.add(g);
      return { g, p };
    };
    const eL = makeEye(0.042);
    const eR = makeEye(-0.042);
    this.eyeL = eL.g;
    this.eyeR = eR.g;
    this.pupilL = eL.p;
    this.pupilR = eR.p;
    // brows
    const browM = mat(data.hair === '#9a6b2a' ? '#6a4a1a' : '#0f0a08');
    this.browL = mk(GEO.box, browM, 0.036, 0.008, 0.008, 0.042, 0.055, 0.1);
    this.browR = mk(GEO.box, browM, 0.036, 0.008, 0.008, -0.042, 0.055, 0.1);
    this.headGroup.add(this.browL, this.browR);
    // nose
    this.headGroup.add(mk(GEO.sphere, mat(new THREE.Color(data.skin).multiplyScalar(0.88).getHex()), 0.014, 0.014, 0.014, 0, -0.012, 0.118));
    // mouth
    const mouthM = mat(0x3a0f0c);
    this.mouthArc = mk(GEO.arc, mouthM, 0.026, 0.026, 0.02, 0, -0.04, 0.106);
    this.mouthOpen = mk(GEO.sphere, mat(0x5a0f14), 0.02, 0.02, 0.008, 0, -0.052, 0.108);
    this.headGroup.add(this.mouthArc, this.mouthOpen);
    if (data.glasses) {
      const gm = mat(0x111111, 0.3);
      const rl = mk(GEO.ring, gm, 0.034, 0.034, 0.03, 0.042, 0.018, 0.108);
      const rr = mk(GEO.ring, gm, 0.034, 0.034, 0.03, -0.042, 0.018, 0.108);
      const br = mk(GEO.box, gm, 0.016, 0.004, 0.004, 0, 0.026, 0.112);
      this.headGroup.add(rl, rr, br);
    }
    if (data.tilak) {
      this.headGroup.add(mk(GEO.sphere, mat(0xd8281c, 0.5), 0.009, 0.014, 0.004, 0, 0.082, 0.1));
    }
    this.root.add(this.headGroup);

    // hair
    this.hair = new HairSystem(data.hair, data.skin, data.curly, data.startTop, data.startSide);
    this.headGroup.add(this.hair.mesh);

    // cape
    this.cape = new THREE.Group();
    const capeColors = ['#f2efe6', '#2f6fb0', '#c43c3c', '#e8a33a', '#3a8f5a'];
    const capeM = new THREE.MeshStandardMaterial({ color: pick(capeColors), roughness: 0.9, side: THREE.DoubleSide });
    this.mats.push(capeM);
    const capeMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.5, 0.8, 24, 1, true), capeM);
    capeMesh.position.y = 0.75;
    capeMesh.castShadow = true;
    this.cape.add(capeMesh);
    const collar = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.08, 0.04, 14), capeM);
    collar.position.y = 1.15;
    this.cape.add(collar);
    this.cape.visible = false;
    this.root.add(this.cape);
    // flecks (cut hair on cape)
    const fm = new THREE.MeshBasicMaterial({ color: data.hair });
    this.mats.push(fm);
    const FN = 170;
    this.flecks = new THREE.InstancedMesh(GEO.box, fm, FN);
    this.flecks.frustumCulled = false;
    for (let i = 0; i < FN; i++) {
      const tt = Math.random();
      const y = 1.15 - 0.8 * tt;
      const r = 0.15 + 0.35 * tt + 0.004;
      const th = Math.random() * Math.PI * 2;
      const m = new THREE.Matrix4();
      const q = new THREE.Quaternion().setFromEuler(new THREE.Euler(Math.random() * 3, Math.random() * 3, Math.random() * 3));
      m.compose(new THREE.Vector3(Math.cos(th) * r, y, Math.sin(th) * r), q, new THREE.Vector3(0.016, 0.003, 0.005));
      this.fleckPos.push(m);
    }
    this.setLoose(0);
    this.cape.add(this.flecks);

    this.root.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) o.castShadow = true;
    });
    this.hair.mesh.castShadow = false;
    this.flecks.castShadow = false;
    this.setExpression('neutral', true);
  }

  setLoose(v: number) {
    const total = this.fleckPos.length;
    const shown = Math.floor(Math.min(1, v) * total);
    if (shown === this.fleckShown) return;
    this.fleckShown = shown;
    const hidden = new THREE.Matrix4().makeScale(0, 0, 0);
    for (let i = 0; i < total; i++) this.flecks.setMatrixAt(i, i < shown ? this.fleckPos[i] : hidden);
    this.flecks.instanceMatrix.needsUpdate = true;
  }

  setExpression(e: Expr, instant = false) {
    this.target = { ...EXPR[e] };
    if (instant) this.ex = { ...EXPR[e] };
  }

  /** animate. walkSpeed: >0 animates leg swing */
  update(dt: number, time: number) {
    this.t += dt;
    const k = 1 - Math.exp(-12 * dt);
    const ex = this.ex;
    const tg = this.target;
    ex.brow += (tg.brow - ex.brow) * k;
    ex.rot += (tg.rot - ex.rot) * k;
    ex.eye += (tg.eye - ex.eye) * k;
    ex.curve += (tg.curve - ex.curve) * k;
    ex.open += (tg.open - ex.open) * k;

    // blinking
    this.blinkT -= dt;
    let blink = 1;
    if (this.blinkT < 0) {
      blink = 0.08;
      if (this.blinkT < -0.12) this.blinkT = 2 + Math.random() * 3.5;
    }
    let talkOpen = 0;
    if (this.talk > 0) {
      this.talk -= dt;
      talkOpen = (0.5 + 0.5 * Math.sin(time * 18)) * 0.7;
    }
    const eyeY = Math.max(0.05, ex.eye * blink);
    this.eyeL.scale.set(1, eyeY, 1);
    this.eyeR.scale.set(1, eyeY, 1);
    this.browL.position.y = 0.055 + ex.brow;
    this.browR.position.y = 0.055 + ex.brow;
    this.browL.rotation.z = ex.rot;
    this.browR.rotation.z = -ex.rot;
    // mouth
    const curve = ex.curve;
    const sgn = curve >= 0 ? -1 : 1;
    this.mouthArc.scale.y = sgn * Math.max(0.1, Math.abs(curve)) * 0.026;
    this.mouthArc.position.y = -0.04 + (curve >= 0 ? 0.012 * curve : -0.012 * -curve);
    const open = Math.min(1, ex.open + talkOpen);
    this.mouthOpen.scale.y = Math.max(0.001, open * 0.026);
    this.mouthOpen.scale.x = 0.016 + 0.01 * (ex.open > 0.8 ? 1 : 0.4) + (curve > 0.5 ? 0.008 : 0);
    this.mouthOpen.position.y = -0.052 + (curve > 0 ? 0.004 : 0) - open * 0.004;
    this.mouthOpen.visible = open > 0.06;
    // pupils follow look
    const px = this.look.yaw * 0.01;
    this.pupilL.position.x = px;
    this.pupilR.position.x = px;

    // head orientation
    const sway = this.calmHead ? 0.004 : 0.03;
    this.headGroup.rotation.y += (this.look.yaw - this.headGroup.rotation.y) * k + Math.sin(this.t * 0.7) * sway * dt;
    this.headGroup.rotation.x += (this.look.pitch - this.headGroup.rotation.x) * k;
    this.headGroup.rotation.z = Math.sin(this.t * 0.9) * sway;

    // limbs
    const p = this.pose;
    const sw = this.walking ? Math.sin(time * 9 + this.t * 0) : 0;
    const amp = this.walking ? 0.6 : 0;
    this.legL.rotation.x = THREE.MathUtils.lerp(sw * amp, -1.5, p);
    this.legR.rotation.x = THREE.MathUtils.lerp(-sw * amp, -1.5, p);
    this.shinL.rotation.x = THREE.MathUtils.lerp(Math.max(0, -sw) * amp, 1.45, p);
    this.shinR.rotation.x = THREE.MathUtils.lerp(Math.max(0, sw) * amp, 1.45, p);
    this.armL.rotation.x = THREE.MathUtils.lerp(-sw * amp * 0.8, -0.9, p);
    this.armR.rotation.x = THREE.MathUtils.lerp(sw * amp * 0.8, -0.9, p);
    this.foreL.rotation.x = THREE.MathUtils.lerp(0, -0.8, p);
    this.foreR.rotation.x = THREE.MathUtils.lerp(0, -0.8, p);
    this.armL.rotation.z = -0.08;
    this.armR.rotation.z = 0.08;
    this.torso.position.y = 0.85 + (this.walking ? Math.abs(Math.sin(time * 9)) * 0.012 : 0);
    this.cape.visible = p > 0.9;
  }

  dispose() {
    this.hair.dispose();
    this.mats.forEach((m) => m.dispose());
    this.flecks.dispose();
  }
}
