import * as THREE from 'three';

export type ToolId = 'clipper' | 'scissors' | 'razor' | 'comb' | 'duster' | 'powder' | 'spray' | 'towel';

export const TOOL_INFO: { id: ToolId; name: string; icon: string; hint: string }[] = [
  { id: 'clipper', name: 'Clipper', icon: '🔌', hint: 'Hold & drag on hair to buzz it down to the guard length.' },
  { id: 'scissors', name: 'Scissors', icon: '✂️', hint: 'Drag on hair to trim it gradually.' },
  { id: 'razor', name: 'Razor', icon: '🔪', hint: 'Shaves to skin – neckline & edges only!' },
  { id: 'comb', name: 'Comb', icon: '💈', hint: 'Drag to comb hair sideways or up.' },
  { id: 'duster', name: 'Neck Brush', icon: '🖌️', hint: 'Sweep loose hair off the cape.' },
  { id: 'powder', name: 'Talcum', icon: '🧴', hint: 'Finishing touch – puff on the neck.' },
  { id: 'spray', name: 'Spray', icon: '💦', hint: 'Wet the hair before cutting.' },
  { id: 'towel', name: 'Towel', icon: '🧣', hint: 'Wipe away hair & sweat.' },
];

export interface ToolRig {
  group: THREE.Group;
  grip: number; // z position where hand grips
  restY: number; // lift above table when lying
  radius: number; // effective working radius on the head
  animate: (active: boolean, t: number) => void;
  setGuard?: (level: number) => void;
}

const M = {
  steel: new THREE.MeshStandardMaterial({ color: 0xc9ced4, metalness: 0.85, roughness: 0.25 }),
  dark: new THREE.MeshStandardMaterial({ color: 0x1b1b1f, roughness: 0.5 }),
  red: new THREE.MeshStandardMaterial({ color: 0xb8322a, roughness: 0.45 }),
  wood: new THREE.MeshStandardMaterial({ color: 0x7a4a24, roughness: 0.7 }),
  blue: new THREE.MeshStandardMaterial({ color: 0x2b6cb0, roughness: 0.4 }),
  white: new THREE.MeshStandardMaterial({ color: 0xf4f1ea, roughness: 0.6 }),
  pink: new THREE.MeshStandardMaterial({ color: 0xf2d6cc, roughness: 1 }),
  glass: new THREE.MeshStandardMaterial({ color: 0x9fd3f0, roughness: 0.15, transparent: true, opacity: 0.75 }),
  skin: new THREE.MeshStandardMaterial({ color: 0xa8714a, roughness: 0.6 }),
  sleeve: new THREE.MeshStandardMaterial({ color: 0xf1ece0, roughness: 0.85 }),
};

let towelTex: THREE.CanvasTexture | null = null;
function towelTexture() {
  if (towelTex) return towelTex;
  const c = document.createElement('canvas');
  c.width = c.height = 64;
  const g = c.getContext('2d')!;
  g.fillStyle = '#f2f2f2';
  g.fillRect(0, 0, 64, 64);
  g.fillStyle = '#d63a3a';
  for (let i = 0; i < 64; i += 16) {
    g.fillRect(i, 0, 8, 64);
    g.fillRect(0, i, 64, 8);
  }
  g.fillStyle = 'rgba(160,30,30,0.55)';
  for (let i = 0; i < 64; i += 16) g.fillRect(i, i, 8, 8);
  towelTex = new THREE.CanvasTexture(c);
  towelTex.colorSpace = THREE.SRGBColorSpace;
  towelTex.wrapS = towelTex.wrapT = THREE.RepeatWrapping;
  towelTex.repeat.set(2, 2);
  return towelTex;
}

const box = (w: number, h: number, d: number, m: THREE.Material, x = 0, y = 0, z = 0) => {
  const me = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
  me.position.set(x, y, z);
  me.castShadow = true;
  return me;
};
/** cylinder whose axis is along z */
const cylZ = (r1: number, r2: number, len: number, m: THREE.Material, z = 0, y = 0, x = 0) => {
  const me = new THREE.Mesh(new THREE.CylinderGeometry(r1, r2, len, 14), m);
  me.rotation.x = Math.PI / 2;
  me.position.set(x, y, z);
  me.castShadow = true;
  return me;
};

export function makeTool(id: ToolId): ToolRig {
  const g = new THREE.Group();
  switch (id) {
    case 'clipper': {
      g.add(box(0.046, 0.04, 0.13, M.red, 0, 0, 0.085));
      g.add(box(0.048, 0.012, 0.05, M.dark, 0, 0.02, 0.1));
      g.add(box(0.044, 0.006, 0.026, M.steel, 0, -0.012, 0.006));
      g.add(box(0.012, 0.006, 0.02, M.white, 0, 0.022, 0.15));
      const guard = box(0.046, 0.016, 0.026, M.dark, 0, -0.018, -0.004);
      g.add(guard);
      g.add(cylZ(0.004, 0.004, 0.25, M.dark, 0.3, 0, 0));
      const gm = [0.0, 0.5, 1, 1.5];
      return {
        group: g,
        grip: 0.1,
        restY: 0.022,
        radius: 0.03,
        animate: (active, t) => {
          g.position.x = active ? Math.sin(t * 90) * 0.0008 : 0;
          g.position.y = active ? Math.cos(t * 83) * 0.0008 : 0;
        },
        setGuard: (lv) => {
          const l = Math.min(3, Math.max(0, lv));
          const s = 0.2 + gm[l] * 0.9;
          guard.scale.set(1, 0.4 + s, 0.9 + l * 0.25);
          guard.position.y = -0.012 - 0.003 * (0.4 + s);
          guard.material = [M.dark, M.blue, M.red, M.wood][l];
        },
      };
    }
    case 'scissors': {
      const mkBlade = (sign: number) => {
        const p = new THREE.Group();
        p.position.set(0, 0, 0.06);
        p.add(box(0.003, 0.01, 0.062, M.steel, 0, 0, -0.031));
        p.add(box(0.004, 0.009, 0.05, M.steel, sign * 0.004, 0, 0.025));
        const ring = new THREE.Mesh(new THREE.TorusGeometry(0.013, 0.003, 6, 14), M.dark);
        ring.rotation.y = Math.PI / 2;
        ring.position.set(sign * 0.012, 0, 0.065);
        ring.castShadow = true;
        p.add(ring);
        g.add(p);
        return p;
      };
      const a = mkBlade(1);
      const b = mkBlade(-1);
      g.add(cylZ(0.004, 0.004, 0.006, M.dark, 0.06, 0, 0));
      return {
        group: g,
        grip: 0.1,
        restY: 0.02,
        radius: 0.022,
        animate: (active, t) => {
          const open = active ? 0.15 + 0.15 * Math.sin(t * 24) : 0.12;
          a.rotation.y = -open;
          b.rotation.y = open;
        },
      };
    }
    case 'razor': {
      g.add(box(0.003, 0.016, 0.07, M.steel, 0, 0, 0.035));
      g.add(box(0.006, 0.006, 0.07, M.dark, 0, 0.008, 0.045));
      g.add(box(0.014, 0.012, 0.09, M.wood, 0, 0, 0.1));
      g.add(box(0.016, 0.014, 0.012, M.steel, 0, 0, 0.07));
      return { group: g, grip: 0.1, restY: 0.01, radius: 0.014, animate: () => {} };
    }
    case 'comb': {
      g.add(box(0.075, 0.006, 0.012, M.dark, 0, 0, 0.034));
      for (let i = 0; i < 16; i++) g.add(box(0.0025, 0.005, 0.03, M.dark, -0.0375 + i * 0.005, 0, 0.015));
      return { group: g, grip: 0.036, restY: 0.004, radius: 0.034, animate: () => {} };
    }
    case 'duster': {
      g.add(cylZ(0.036, 0.034, 0.05, M.pink, 0.025));
      g.add(cylZ(0.04, 0.04, 0.018, M.wood, 0.06));
      g.add(cylZ(0.012, 0.012, 0.1, M.wood, 0.12));
      return {
        group: g,
        grip: 0.12,
        restY: 0.04,
        radius: 0.05,
        animate: (active, t) => {
          g.rotation.z = active ? Math.sin(t * 14) * 0.12 : 0;
        },
      };
    }
    case 'powder': {
      g.add(cylZ(0.03, 0.03, 0.012, M.white, 0.006));
      for (let i = 0; i < 5; i++) {
        const a = (i / 5) * Math.PI * 2;
        g.add(cylZ(0.002, 0.002, 0.004, M.dark, 0.001, Math.sin(a) * 0.014, Math.cos(a) * 0.014));
      }
      g.add(cylZ(0.029, 0.029, 0.08, M.blue, 0.054));
      g.add(cylZ(0.0295, 0.0295, 0.03, M.white, 0.055));
      return {
        group: g,
        grip: 0.06,
        restY: 0.03,
        radius: 0.05,
        animate: (active, t) => {
          g.rotation.x = active ? Math.sin(t * 12) * 0.08 : 0;
        },
      };
    }
    case 'spray': {
      g.add(box(0.05, 0.1, 0.05, M.glass, 0, -0.05, 0.075));
      g.add(box(0.03, 0.03, 0.06, M.white, 0, 0.012, 0.06));
      g.add(cylZ(0.006, 0.006, 0.03, M.white, 0.01, 0.012));
      const trig = box(0.008, 0.026, 0.01, M.dark, 0, -0.012, 0.045);
      g.add(trig);
      g.add(box(0.044, 0.07, 0.044, M.blue, 0, -0.06, 0.075));
      return {
        group: g,
        grip: 0.075,
        restY: 0.1,
        radius: 0.06,
        animate: (active, t) => {
          trig.rotation.x = active ? 0.3 + Math.sin(t * 16) * 0.2 : 0;
        },
      };
    }
    case 'towel': {
      const m = new THREE.MeshStandardMaterial({ map: towelTexture(), roughness: 1 });
      g.add(box(0.15, 0.014, 0.1, m, 0, 0, 0.04));
      g.add(box(0.14, 0.012, 0.09, m, 0, 0.012, 0.04));
      return {
        group: g,
        grip: 0.04,
        restY: 0.014,
        radius: 0.06,
        animate: (active, t) => {
          g.rotation.y = active ? Math.sin(t * 10) * 0.35 : 0;
        },
      };
    }
  }
}

/** barber's right hand + forearm. Fist grips at local (0, 0.03, 0), forearm extends towards +z. */
export function makeHand(): THREE.Group {
  const h = new THREE.Group();
  const palm = new THREE.Mesh(new THREE.BoxGeometry(0.055, 0.04, 0.07), M.skin);
  palm.position.set(0, 0.03, 0);
  const fingers = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.014, 0.05, 8), M.skin);
  fingers.rotation.z = Math.PI / 2;
  fingers.position.set(0, 0.012, -0.012);
  const thumb = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.011, 0.045, 8), M.skin);
  thumb.rotation.x = Math.PI / 2.4;
  thumb.position.set(0.03, 0.035, -0.03);
  const fore = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.034, 0.5, 12), M.skin);
  fore.rotation.x = Math.PI / 2;
  fore.position.set(0, 0.04, 0.3);
  const sleeve = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.045, 0.3, 12), M.sleeve);
  sleeve.rotation.x = Math.PI / 2;
  sleeve.position.set(0, 0.04, 0.5);
  h.add(palm, fingers, thumb, fore, sleeve);
  return h;
}
