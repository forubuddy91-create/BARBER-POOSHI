import * as THREE from 'three';
import { AudioEngine, LoopKind, VoiceKind } from './audio';
import { buildWorld, World, CHAIR_POS, SEAT_Y, WAIT_SPOT, MIRROR_SPOT, TABLE_SLOT_X } from './world';
import { makeTool, makeHand, ToolId, TOOL_INFO, ToolRig } from './tools';
import { CustomerModel, CustomerData, randomCustomer, Expr } from './customerModel';
import { HairStyle, STYLES, renderDrawing, REGIONS, Region } from './hairstyles';
import { CutTool, SURF, Evaluation } from './hair';

// ------------------------------------------------------------------ public types
export interface Settings {
  master: number;
  sfx: number;
  amb: number;
  voice: boolean;
  sens: number;
  mirror: boolean;
  shadows: boolean;
  guide: boolean;
  quality: number; // render scale 0.5..1
}
export const DEFAULT_SETTINGS: Settings = { master: 0.8, sfx: 1, amb: 0.7, voice: true, sens: 1, mirror: true, shadows: true, guide: true, quality: 0.85 };

export interface SaveData {
  money: number;
  day: number;
  dayEarn: number;
  dayServed: number;
  dayScores: number[];
  rep: number;
  totalServed: number;
  best: number;
  sat: number[];
  settings: Settings;
}
const SAVE_KEY = 'village-barber-save-v1';
const DAY_GOAL = 6;

export type Grade = 'perfect' | 'good' | 'ok' | 'funny' | 'terrible';
export interface ResultInfo {
  name: string;
  styleName: string;
  score: number;
  grade: Grade;
  label: string;
  pay: number;
  tip: number;
  total: number;
  quote: string;
  lines: { label: string; value: number }[];
  notes: string[];
}
export interface DaySummary {
  day: number;
  earned: number;
  served: number;
  avg: number;
  rep: number;
}
export interface Snapshot {
  mode: 'walk' | 'cut';
  started: boolean;
  money: number;
  day: number;
  dayEarn: number;
  dayServed: number;
  dayGoal: number;
  rep: number;
  sat: number;
  totalServed: number;
  best: number;
  queue: number;
  tool: ToolId | null;
  guard: number;
  prompt: string;
  hint: string;
  stroking: boolean;
  nearChair: boolean;
  customer: null | {
    name: string;
    personality: string;
    patience: number;
    state: string;
    styleName: string;
    drawing: string;
    canFinish: boolean;
    mood: string;
  };
  say: null | { text: string; id: number };
  guide: { region: Region; cur: number; tgt: number }[] | null;
}
export type GameEvent =
  | { type: 'drawing'; reason: string }
  | { type: 'result'; result: ResultInfo }
  | { type: 'dayEnd'; summary: DaySummary }
  | { type: 'cash'; amount: number }
  | { type: 'toast'; text: string };

// ------------------------------------------------------------------ internal
type CState = 'queue' | 'enter' | 'waitPaper' | 'toChair' | 'sitting' | 'seated' | 'standing' | 'toMirror' | 'mirror' | 'toPay' | 'paying' | 'leaving';

interface Cust {
  data: CustomerData;
  model: CustomerModel;
  state: CState;
  path: THREE.Vector3[];
  speed: number;
  t: number;
  style: HairStyle;
  drawing: string;
  patience: number;
  cutTime: number;
  loose: number;
  powder: number;
  accidents: number;
  razorNeck: boolean;
  changed: boolean;
  changeAt: number;
  fixAsked: boolean;
  chatT: number;
  watchT: number;
  shocked: boolean;
  impatient: boolean;
  override: { expr: Expr; t: number } | null;
  tickleCd: number;
  flinchCd: number;
  coldDone: boolean;
  sneezeDone: boolean;
  start: THREE.Vector3;
  eval: Evaluation | null;
  grade: Grade;
  reacted: boolean;
  resultShown: boolean;
  doorDone: boolean;
  total: number;
  exitSide: number;
}

const GUARDS = [0.04, 0.2, 0.38, 0.58];
const pick = <T,>(a: T[]): T => a[Math.floor(Math.random() * a.length)];
const rnd = (a: number, b: number) => a + Math.random() * (b - a);
const clamp = (x: number, a: number, b: number) => Math.min(b, Math.max(a, x));
const lerpAngle = (a: number, b: number, t: number) => {
  let d = (b - a) % (Math.PI * 2);
  if (d > Math.PI) d -= Math.PI * 2;
  if (d < -Math.PI) d += Math.PI * 2;
  return a + d * t;
};
const REGION_NAME: Record<Region, string> = { front: 'fringe', top: 'top', left: 'left side', right: 'right side', back: 'back', neck: 'neckline' };

const LINES = {
  greet: ['Chetta, one haircut please! See this paper!', 'Anna, I want this style. Look at my drawing!', 'Hello Chetta! Make me look like a film hero!', 'Chetta, mummy said short only... but see this!', 'Bro, cut exactly like this ok?'],
  chat: ["Chetta, don't cut my ear!", 'Is it looking good?', 'Amma is waiting outside.', 'Hurry, the cricket match is starting!', "Cut like Dhoni's hair, ok?", 'Ayyo, that tickles!', 'My friend got this same cut yesterday.', 'Chetta, you are very slow today.', 'Is that the clipper or a mosquito?'],
  chatImp: ['Chetta, late aavunnu!', 'How much longer?!', 'Tuition time is coming!'],
  chatSleepy: ['*yawn* Wake me when it is done...', 'Zzz... huh? Continue, continue.'],
  chatDrama: ['Please be careful, my whole life is in this hair!', 'I can feel the hair falling. So sad!'],
  perfect: ['Adipoli! Super cut Chetta!', 'Wow! I look like a film hero!', 'Mass! Thank you Chetta!'],
  good: ['Nannayittund! Nice cut.', 'Good good. I like it.', 'Super Chetta, almost perfect!'],
  ok: ['Hmm... okay, it will do.', 'Not bad, not great also.', 'Fine, fine. Mummy will not shout much.'],
  funny: ['Ayyo! Is this a haircut or a coconut?!', 'Hahaha! I look like a scarecrow!', 'Chetta, are you sure you are a barber?', 'My friends will laugh at me!'],
  terrible: ['AYYOOO! My hair!! What did you do?!', 'I am ruined! Amma will kill you!', 'I want my old hair back!!', 'Is this a joke Chetta?!'],
  change: ['Wait wait! I changed my mind!', 'Chetta, my friend just showed me a better style!', 'Sorry Chetta, I want this one instead!'],
  shock: ['Ayyo! Where is my hair?!', 'Nooo! Too much, too much!', 'Chetta! I said trim, not shave!'],
  accident: ['Ayyo! My eyebrow!', 'Chetta! That was my face!', 'Careful careful!'],
  angry: ['Enough! Finish it quickly!', 'I am getting late, Chetta!'],
  tickle: ['Hehehe! That tickles!', 'Ha ha! Stop, stop!'],
};

export class Game {
  canvas: HTMLCanvasElement;
  renderer: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera: THREE.PerspectiveCamera;
  world: World;
  audio = new AudioEngine();
  onSnap: (s: Snapshot) => void;
  onEvent: (e: GameEvent) => void;
  settings: Settings = { ...DEFAULT_SETTINGS };
  save: SaveData;

  started = false;
  paused = false;
  modal = false;
  disposed = false;
  mode: 'walk' | 'cut' = 'walk';
  time = 0;
  raf = 0;
  lastT = 0;
  snapT = 0;
  promptT = 0;

  // player
  pos = new THREE.Vector3(-1.0, 0, -0.2);
  yaw = Math.PI - 0.55;
  pitch = -0.05;
  move = { x: 0, y: 0 };
  keys = new Set<string>();
  bob = 0;
  orbit = { yaw: 0, pitch: 0.55, dist: 0.7 };
  camPos = new THREE.Vector3();
  camQuat = new THREE.Quaternion();

  // tools
  tool: ToolId | null = null;
  guard = 1;
  tableRigs = new Map<ToolId, ToolRig>();
  handRigs = new Map<ToolId, ToolRig>();
  hitBoxes: THREE.Mesh[] = [];
  holder = new THREE.Group();
  bareR: THREE.Group;
  bareL: THREE.Group;
  prompt = '';
  promptAction: { kind: 'pick' | 'cut' | 'paper' | 'none'; tool?: ToolId } = { kind: 'none' };

  // pointers
  pointers = new Map<number, { x: number; y: number; sx: number; sy: number; t0: number; kind: 'look' | 'stroke'; moved: number }>();
  strokeId = -1;
  strokeNdc = new THREE.Vector2();
  stroking = false;
  contact = false;
  prevLocal: THREE.Vector3 | null = null;
  toolPoint = new THREE.Vector3();
  snipT = 0;
  puffT = 0;
  raycaster = new THREE.Raycaster();

  // customers
  current: Cust | null = null;
  queue: Cust[] = [];
  leavers: Cust[] = [];
  spawnT = 2;
  lastStyle = -1;
  sayMsg: { text: string; id: number } | null = null;
  sayT = 0;
  sayId = 0;
  dayEndT = -1;
  dayLocked = false;

  // particles
  PN = 260;
  pMesh: THREE.InstancedMesh;
  pData: { p: THREE.Vector3; v: THREE.Vector3; life: number; max: number; size: number; grav: number; settle: boolean }[] = [];
  pIdx = 0;

  private tmpV = new THREE.Vector3();
  private tmpV2 = new THREE.Vector3();
  private tmpM = new THREE.Matrix4();
  private tmpQ = new THREE.Quaternion();
  private tmpS = new THREE.Vector3();
  private tmpC = new THREE.Color();
  private ro: ResizeObserver;

  constructor(canvas: HTMLCanvasElement, onSnap: (s: Snapshot) => void, onEvent: (e: GameEvent) => void) {
    this.canvas = canvas;
    this.onSnap = onSnap;
    this.onEvent = onEvent;
    this.save = this.loadSave();
    this.settings = { ...DEFAULT_SETTINGS, ...this.save.settings };

    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.camera = new THREE.PerspectiveCamera(72, 1, 0.03, 300);
    this.scene.add(this.camera);
    this.world = buildWorld(this.scene, this.renderer);

    // table tools
    TOOL_INFO.forEach((ti, i) => {
      const rig = makeTool(ti.id);
      const slot = this.world.tableSlots[i];
      rig.group.position.set(slot.x, slot.y + rig.restY, slot.z);
      rig.group.rotation.y = Math.PI / 2 + (Math.random() - 0.5) * 0.12;
      this.scene.add(rig.group);
      this.tableRigs.set(ti.id, rig);
      const hit = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.16, 0.22), new THREE.MeshBasicMaterial({ visible: false }));
      hit.position.set(TABLE_SLOT_X + 0.12, slot.y + 0.06, slot.z);
      hit.userData.toolId = ti.id;
      this.scene.add(hit);
      this.hitBoxes.push(hit);
      if (ti.id === 'clipper') rig.setGuard?.(this.guard);
      // hand rig
      const hr = makeTool(ti.id);
      hr.group.visible = false;
      this.holder.add(hr.group);
      hr.setGuard?.(this.guard);
      this.handRigs.set(ti.id, hr);
    });
    const hand = makeHand();
    this.holder.add(hand);
    this.handMesh = hand;
    this.holder.visible = false;
    this.camera.add(this.holder);
    this.bareR = makeHand();
    this.bareR.position.set(0.2, -0.27, -0.42);
    this.bareR.rotation.set(0.35, 0.1, 0);
    this.bareL = makeHand();
    this.bareL.scale.x = -1;
    this.bareL.position.set(-0.2, -0.27, -0.42);
    this.bareL.rotation.set(0.35, -0.1, 0);
    this.camera.add(this.bareR, this.bareL);

    // particles
    const pm = new THREE.MeshBasicMaterial({ color: 0xffffff });
    this.pMesh = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), pm, this.PN);
    this.pMesh.frustumCulled = false;
    for (let i = 0; i < this.PN; i++) {
      this.pData.push({ p: new THREE.Vector3(), v: new THREE.Vector3(), life: 0, max: 1, size: 0.01, grav: 3, settle: false });
      this.pMesh.setMatrixAt(i, new THREE.Matrix4().makeScale(0, 0, 0));
      this.pMesh.setColorAt(i, new THREE.Color(1, 1, 1));
    }
    this.scene.add(this.pMesh);

    this.applySettings(this.settings);
    this.resize();
    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(canvas);
    this.bindInput();
    this.updateCamera(1, true);
    this.lastT = performance.now();
    this.raf = requestAnimationFrame(this.loop);
  }

  handMesh: THREE.Group;

  // ------------------------------------------------------------------ save
  private defaultSave(): SaveData {
    return { money: 0, day: 1, dayEarn: 0, dayServed: 0, dayScores: [], rep: 3, totalServed: 0, best: 0, sat: [], settings: { ...DEFAULT_SETTINGS } };
  }
  private loadSave(): SaveData {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (raw) return { ...this.defaultSave(), ...JSON.parse(raw) };
    } catch {
      /* ignore */
    }
    return this.defaultSave();
  }
  hasSave() {
    return this.save.totalServed > 0 || this.save.day > 1;
  }
  persist() {
    this.save.settings = this.settings;
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify(this.save));
    } catch {
      /* ignore */
    }
  }
  restart() {
    this.clearCustomers();
    this.save = this.defaultSave();
    this.save.settings = this.settings;
    this.persist();
    this.dayLocked = false;
    this.dayEndT = -1;
    this.spawnT = 2;
    this.setMode('walk');
    this.putDown();
    this.pos.set(-1.0, 0, -0.2);
    this.yaw = Math.PI - 0.55;
    this.pitch = -0.05;
    this.emit();
  }
  private clearCustomers() {
    const all = [...this.queue, ...this.leavers, ...(this.current ? [this.current] : [])];
    all.forEach((c) => this.removeCust(c));
    this.queue = [];
    this.leavers = [];
    this.current = null;
    this.audio.stopLoop();
  }
  private removeCust(c: Cust) {
    this.scene.remove(c.model.root);
    c.model.dispose();
  }

  // ------------------------------------------------------------------ settings
  applySettings(s: Settings) {
    this.settings = s;
    this.audio.setVolumes(s.master, s.sfx, s.amb, s.voice);
    this.world.setMirror(s.mirror);
    this.world.sun.castShadow = s.shadows;
    this.resize();
    this.persist();
  }

  resize() {
    const w = this.canvas.clientWidth || window.innerWidth;
    const h = this.canvas.clientHeight || window.innerHeight;
    const pr = Math.min(window.devicePixelRatio || 1, 2) * this.settings.quality;
    this.renderer.setPixelRatio(pr);
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.fov = w / h < 1 ? 78 : 68;
    this.camera.updateProjectionMatrix();
  }

  startAudio() {
    this.audio.init();
    this.audio.setVolumes(this.settings.master, this.settings.sfx, this.settings.amb, this.settings.voice);
  }
  begin() {
    this.started = true;
    this.spawnT = 1.5;
    this.startAudio();
    this.emit();
  }
  setPaused(b: boolean) {
    this.paused = b;
    if (b) this.audio.stopLoop();
    this.audio.suspend(b);
    this.emit();
  }
  setModal(b: boolean) {
    this.modal = b;
    if (b) {
      this.endStroke();
    }
  }

  // ------------------------------------------------------------------ input
  private bindInput() {
    const c = this.canvas;
    c.addEventListener('pointerdown', this.onDown);
    c.addEventListener('pointermove', this.onMove);
    c.addEventListener('pointerup', this.onUp);
    c.addEventListener('pointercancel', this.onUp);
    c.addEventListener('wheel', this.onWheel, { passive: true });
    c.addEventListener('contextmenu', (e) => e.preventDefault());
    window.addEventListener('keydown', this.onKey);
    window.addEventListener('keyup', this.onKeyUp);
  }
  private ndc(e: PointerEvent, out: THREE.Vector2) {
    const r = this.canvas.getBoundingClientRect();
    out.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
  }
  private onDown = (e: PointerEvent) => {
    if (!this.started || this.paused || this.modal) return;
    this.canvas.setPointerCapture(e.pointerId);
    const p = { x: e.clientX, y: e.clientY, sx: e.clientX, sy: e.clientY, t0: performance.now(), kind: 'look' as 'look' | 'stroke', moved: 0 };
    if (this.mode === 'cut' && this.current?.state === 'seated' && this.strokeId < 0) {
      this.ndc(e, this.strokeNdc);
      if (this.headDistance(this.strokeNdc) < 0.2) {
        if (!this.tool) {
          this.onEvent({ type: 'toast', text: 'Pick a tool first (bottom bar)!' });
        } else {
          p.kind = 'stroke';
          this.strokeId = e.pointerId;
          this.stroking = true;
        }
      }
    }
    this.pointers.set(e.pointerId, p);
  };
  private onMove = (e: PointerEvent) => {
    const p = this.pointers.get(e.pointerId);
    if (!p) return;
    const dx = e.clientX - p.x;
    const dy = e.clientY - p.y;
    p.x = e.clientX;
    p.y = e.clientY;
    p.moved += Math.abs(dx) + Math.abs(dy);
    if (p.kind === 'stroke') {
      this.ndc(e, this.strokeNdc);
    } else if (this.mode === 'walk') {
      const k = 0.0042 * this.settings.sens * (this.camera.fov / 70);
      this.yaw -= dx * k;
      this.pitch = clamp(this.pitch - dy * k, -1.35, 1.35);
    } else {
      const k = 0.0065 * this.settings.sens;
      this.orbit.yaw -= dx * k;
      this.orbit.pitch = clamp(this.orbit.pitch + dy * k, -0.35, 1.35);
    }
  };
  private onUp = (e: PointerEvent) => {
    const p = this.pointers.get(e.pointerId);
    if (!p) return;
    this.pointers.delete(e.pointerId);
    if (p.kind === 'stroke') {
      this.endStroke();
    } else if (this.mode === 'walk' && p.moved < 12 && performance.now() - p.t0 < 400) {
      this.ndc(e, this.tmpNdc);
      this.tap(this.tmpNdc);
    }
  };
  private tmpNdc = new THREE.Vector2();
  private onWheel = (e: WheelEvent) => {
    if (this.mode === 'cut') this.orbit.dist = clamp(this.orbit.dist + e.deltaY * 0.0006, 0.45, 1.0);
  };
  private onKey = (e: KeyboardEvent) => {
    this.keys.add(e.code);
    if (!this.started || this.paused || this.modal) return;
    if (e.code === 'KeyE' || e.code === 'Space') this.interact();
    if (e.code === 'KeyQ') this.putDown();
    const n = parseInt(e.key, 10);
    if (n >= 1 && n <= 8) this.selectTool(TOOL_INFO[n - 1].id);
    if (e.code === 'Escape') this.setMode('walk');
  };
  private onKeyUp = (e: KeyboardEvent) => this.keys.delete(e.code);

  setMove(x: number, y: number) {
    this.move.x = x;
    this.move.y = y;
  }

  private endStroke() {
    this.strokeId = -1;
    this.stroking = false;
    this.contact = false;
    this.prevLocal = null;
    this.audio.stopLoop();
  }

  /** closest distance between camera ray (ndc) and the head centre */
  private headDistance(ndc: THREE.Vector2): number {
    if (!this.current) return 9;
    this.raycaster.setFromCamera(ndc, this.camera);
    const c = this.headCenter(this.tmpV2);
    const cp = this.raycaster.ray.closestPointToPoint(c, this.tmpV);
    return cp.distanceTo(c);
  }
  private headCenter(out: THREE.Vector3) {
    if (!this.current) return out.set(0, 1.3, 0);
    this.current.model.headGroup.getWorldPosition(out);
    return out;
  }

  private tap(ndc: THREE.Vector2) {
    this.raycaster.setFromCamera(ndc, this.camera);
    // table tools
    const hits = this.raycaster.intersectObjects(this.hitBoxes, false);
    if (hits.length && hits[0].distance < 3.4) {
      const id = hits[0].object.userData.toolId as ToolId;
      if (id !== this.tool) {
        this.selectTool(id);
        return;
      }
    }
    // customer head / body
    if (this.current && this.current.state === 'seated') {
      if (this.headDistance(ndc) < 0.3 && this.nearChair()) {
        this.enterCut();
        return;
      }
    }
    if (this.current && this.current.state === 'waitPaper') {
      this.onEvent({ type: 'drawing', reason: 'view' });
    }
  }

  // ------------------------------------------------------------------ tools & modes
  selectTool(id: ToolId) {
    if (this.paused) return;
    if (this.tool === id) {
      this.putDown();
      return;
    }
    if (this.tool) this.tableRigs.get(this.tool)!.group.visible = true;
    this.tool = id;
    this.tableRigs.get(id)!.group.visible = false;
    this.handRigs.forEach((r, k) => (r.group.visible = k === id));
    const rig = this.handRigs.get(id)!;
    this.handMesh.position.set(0, 0, rig.grip);
    this.audio.pick();
    this.endStroke();
    this.emit();
  }
  putDown() {
    if (this.tool) {
      this.tableRigs.get(this.tool)!.group.visible = true;
      this.audio.drop();
    }
    this.tool = null;
    this.handRigs.forEach((r) => (r.group.visible = false));
    this.endStroke();
    this.emit();
  }
  setGuard(n: number) {
    this.guard = clamp(n, 0, 3);
    this.handRigs.get('clipper')?.setGuard?.(this.guard);
    this.tableRigs.get('clipper')?.setGuard?.(this.guard);
    this.audio.click();
    this.emit();
  }
  nearChair() {
    return Math.hypot(this.pos.x - CHAIR_POS.x, this.pos.z - CHAIR_POS.z) < 2.6;
  }
  setMode(m: 'walk' | 'cut') {
    if (m === this.mode) return;
    if (m === 'cut') {
      if (!this.current || this.current.state !== 'seated') return;
      const h = this.headCenter(this.tmpV);
      this.orbit.yaw = Math.atan2(this.camera.position.x - h.x, this.camera.position.z - h.z);
      this.orbit.yaw = clamp(this.orbit.yaw, -2.8, 2.8);
      this.orbit.pitch = 0.6;
      const asp = this.camera.aspect;
      this.orbit.dist = 0.62 + (asp < 1 ? 0.28 * (1 - asp) : 0);
      this.mode = 'cut';
      if (this.current) this.current.model.calmHead = true;
    } else {
      // look at the head when leaving cut mode
      const h = this.headCenter(this.tmpV);
      const cam = this.camera.position;
      const d = Math.hypot(h.x - cam.x, h.z - cam.z);
      this.pos.x = cam.x;
      this.pos.z = cam.z;
      this.yaw = Math.atan2(-(h.x - cam.x), -(h.z - cam.z));
      this.pitch = -0.35;
      void d;
      this.mode = 'walk';
      this.world.collide(this.pos, 0.3);
    }
    this.endStroke();
    this.emit();
  }
  enterCut() {
    if (!this.current || this.current.state !== 'seated') return;
    if (!this.nearChair()) {
      this.onEvent({ type: 'toast', text: 'Walk closer to the chair first.' });
      return;
    }
    this.setMode('cut');
    this.audio.click();
  }
  exitCut() {
    this.setMode('walk');
  }

  interact() {
    if (this.paused || !this.started) return;
    this.audio.init();
    const a = this.promptAction;
    if (a.kind === 'pick' && a.tool) this.selectTool(a.tool);
    else if (a.kind === 'cut') this.enterCut();
    else if (a.kind === 'paper') this.onEvent({ type: 'drawing', reason: 'view' });
    else if (this.current && this.current.state === 'seated' && this.nearChair()) this.enterCut();
  }

  private computePrompt() {
    this.promptAction = { kind: 'none' };
    this.prompt = '';
    if (this.mode !== 'walk') return;
    this.raycaster.setFromCamera(new THREE.Vector2(0, 0), this.camera);
    const hits = this.raycaster.intersectObjects(this.hitBoxes, false);
    if (hits.length && hits[0].distance < 3.2) {
      const id = hits[0].object.userData.toolId as ToolId;
      if (id !== this.tool) {
        const info = TOOL_INFO.find((t) => t.id === id)!;
        this.promptAction = { kind: 'pick', tool: id };
        this.prompt = `Pick up ${info.name}`;
        return;
      }
    }
    const c = this.current;
    if (c && c.state === 'seated' && this.nearChair()) {
      this.promptAction = { kind: 'cut' };
      this.prompt = 'Start haircut ✂';
    } else if (c && c.state === 'waitPaper') {
      this.promptAction = { kind: 'paper' };
      this.prompt = 'Look at drawing 📄';
    }
  }

  // ------------------------------------------------------------------ customers
  private spawnCustomer() {
    const data = randomCustomer(this.lastStyle);
    this.lastStyle = data.style.id;
    const model = new CustomerModel(data);
    const side = Math.random() < 0.5 ? -1 : 1;
    model.root.position.set(side * 10, 0, rnd(5.2, 5.7));
    this.scene.add(model.root);
    const c: Cust = {
      data,
      model,
      state: 'queue',
      path: [],
      speed: rnd(1.25, 1.6),
      t: 0,
      style: data.style,
      drawing: this.makeDrawing(data.style, data.messy),
      patience: 1,
      cutTime: 0,
      loose: 0,
      powder: 0,
      accidents: 0,
      razorNeck: false,
      changed: false,
      changeAt: rnd(12, 30),
      fixAsked: false,
      chatT: rnd(10, 20),
      watchT: 0,
      shocked: false,
      impatient: false,
      override: null,
      tickleCd: 0,
      flinchCd: 0,
      coldDone: false,
      sneezeDone: false,
      start: new THREE.Vector3(),
      eval: null,
      grade: 'ok',
      reacted: false,
      resultShown: false,
      doorDone: false,
      total: 0,
      exitSide: side,
    };
    this.queue.push(c);
    this.audio.horn();
  }

  private makeDrawing(style: HairStyle, messy: boolean) {
    const cv = renderDrawing(style, { messy, seed: Math.floor(Math.random() * 9999) });
    return cv.toDataURL('image/png');
  }

  private queueSlot(i: number) {
    return new THREE.Vector3(1.15 + i * 0.7, 0, 4.15);
  }

  private say(c: Cust, text: string, voice?: VoiceKind, tts = true) {
    this.sayId++;
    this.sayMsg = { text, id: this.sayId };
    this.sayT = 4.2;
    c.model.talk = Math.min(3, 0.5 + text.length * 0.05);
    if (voice) this.audio.voice(voice, c.data.pitch);
    if (tts) this.audio.say(text, c.data.pitch);
  }

  private follow(c: Cust, dt: number): boolean {
    const m = c.model;
    if (!c.path.length) {
      m.walking = false;
      return true;
    }
    const tgt = c.path[0];
    const dx = tgt.x - m.root.position.x;
    const dz = tgt.z - m.root.position.z;
    const d = Math.hypot(dx, dz);
    const step = c.speed * dt;
    if (d <= step) {
      m.root.position.x = tgt.x;
      m.root.position.z = tgt.z;
      c.path.shift();
    } else {
      m.root.position.x += (dx / d) * step;
      m.root.position.z += (dz / d) * step;
      m.root.rotation.y = lerpAngle(m.root.rotation.y, Math.atan2(dx, dz), 1 - Math.exp(-10 * dt));
    }
    m.walking = true;
    if (!c.path.length) {
      m.walking = false;
      return true;
    }
    return false;
  }

  private faceTo(c: Cust, x: number, z: number, dt: number, rate = 8) {
    const m = c.model.root;
    const a = Math.atan2(x - m.position.x, z - m.position.z);
    m.rotation.y = lerpAngle(m.rotation.y, a, 1 - Math.exp(-rate * dt));
  }

  acceptCustomer() {
    const c = this.current;
    if (!c || c.state !== 'waitPaper') return;
    c.state = 'toChair';
    c.path = [new THREE.Vector3(0.95, 0, -0.9), new THREE.Vector3(0.95, 0, -1.6)];
    c.model.setExpression('happy');
    this.say(c, pick(['Okay Chetta, start!', 'Thank you Chetta!', 'Make it nice ok?']), 'happy');
    this.emit();
  }

  private promote() {
    const c = this.queue.shift()!;
    c.state = 'enter';
    c.path = [new THREE.Vector3(0, 0, 4.1), new THREE.Vector3(0, 0, 2.4), WAIT_SPOT.clone()];
    this.current = c;
    c.model.setExpression('neutral');
  }

  private expressionFor(c: Cust): Expr {
    if (c.override && c.override.t > 0) return c.override.expr;
    if (c.patience <= 0.001) return 'angry';
    if (c.data.personality === 'sleepy') return 'sleepy';
    if (c.patience < 0.3) return 'angry';
    if (c.data.personality === 'jolly') return 'happy';
    if (c.data.personality === 'fussy') return 'smug';
    return 'neutral';
  }

  private updateCust(c: Cust, dt: number) {
    const m = c.model;
    m.update(dt, this.time);
    if (c.override) c.override.t -= dt;
    c.tickleCd -= dt;
    c.flinchCd -= dt;
    switch (c.state) {
      case 'queue': {
        const idx = this.queue.indexOf(c);
        if (idx < 0) break;
        const slot = this.queueSlot(idx);
        if (!c.path.length) {
          const p = m.root.position;
          if (Math.hypot(p.x - slot.x, p.z - slot.z) > 0.06) {
            if (Math.abs(p.z - 5.0) > 0.3 && p.z > 4.8) c.path = [new THREE.Vector3(slot.x, 0, 4.9), slot];
            else c.path = [slot];
          }
        }
        const arrived = this.follow(c, dt);
        if (arrived) {
          this.faceTo(c, 0, 3.4, dt);
          m.walking = false;
        }
        break;
      }
      case 'enter': {
        const p = m.root.position;
        if (!c.doorDone && p.z < 3.9) {
          c.doorDone = true;
          this.audio.doorCreak();
          this.world.doorKick();
        }
        if (this.follow(c, dt)) {
          c.state = 'waitPaper';
          c.t = 0;
          this.say(c, pick(LINES.greet), 'happy');
          this.onEvent({ type: 'drawing', reason: 'arrive' });
          this.emit();
        }
        break;
      }
      case 'waitPaper': {
        this.faceTo(c, this.camera.position.x, this.camera.position.z, dt);
        m.look.yaw = 0;
        break;
      }
      case 'toChair': {
        if (this.follow(c, dt)) {
          c.state = 'sitting';
          c.t = 0;
          c.start.copy(m.root.position);
        }
        break;
      }
      case 'sitting': {
        c.t += dt / 0.9;
        const s = clamp(c.t, 0, 1);
        const e = s * s * (3 - 2 * s);
        m.root.position.set(
          THREE.MathUtils.lerp(c.start.x, CHAIR_POS.x, e),
          THREE.MathUtils.lerp(0, SEAT_Y, e) + Math.sin(s * Math.PI) * 0.08,
          THREE.MathUtils.lerp(c.start.z, CHAIR_POS.z, e)
        );
        m.root.rotation.y = lerpAngle(m.root.rotation.y, Math.PI, 1 - Math.exp(-8 * dt));
        m.pose = e;
        if (s >= 1) {
          c.state = 'seated';
          m.calmHead = true;
          m.pose = 1;
          this.audio.drop();
          this.say(c, pick(['Start cheyyu Chetta!', 'Okay, I am ready!', 'Please cut nicely...']));
          this.emit();
        }
        break;
      }
      case 'seated': {
        m.root.rotation.y = Math.PI;
        if (!this.modal) {
          c.patience = Math.max(0, c.patience - dt / c.data.patience);
          if (this.stroking) c.cutTime += dt;
          c.chatT -= dt;
          c.watchT -= dt;
        }
        m.setLoose(c.loose);
        m.setExpression(this.expressionFor(c));
        // impatience
        if (c.patience <= 0 && !c.impatient) {
          c.impatient = true;
          c.override = { expr: 'angry', t: 3 };
          this.say(c, pick(LINES.angry), 'angry');
        }
        // change of mind
        if (c.data.willChange && !c.changed && c.cutTime > c.changeAt && !this.modal) {
          c.changed = true;
          let ns = pick(STYLES);
          while (ns.id === c.style.id) ns = pick(STYLES);
          c.style = ns;
          c.drawing = this.makeDrawing(ns, Math.random() < 0.3);
          c.override = { expr: 'smug', t: 2.5 };
          this.say(c, pick(LINES.change), 'hmm');
          this.onEvent({ type: 'drawing', reason: 'change' });
        }
        // chatter
        if (c.chatT <= 0 && !this.modal) {
          c.chatT = rnd(14, 26);
          const p = c.data.personality;
          const pool = p === 'impatient' ? [...LINES.chatImp, ...LINES.chat] : p === 'sleepy' ? [...LINES.chatSleepy, ...LINES.chat] : p === 'dramatic' ? [...LINES.chatDrama, ...LINES.chat] : LINES.chat;
          this.say(c, pick(pool), p === 'jolly' ? 'laugh' : undefined, Math.random() < 0.6);
        }
        // hair watcher
        if (c.watchT <= 0) {
          c.watchT = 0.8;
          const avg = m.hair.averages();
          const tg = m.hair.targets(c.style);
          if (!c.shocked && avg.top < 0.05 && tg.top > 0.25) {
            c.shocked = true;
            c.override = { expr: 'shock', t: 3 };
            this.say(c, pick(LINES.shock), 'shock');
          }
        }
        break;
      }
      case 'standing': {
        c.t += dt / 0.8;
        const s = clamp(c.t, 0, 1);
        const e = s * s * (3 - 2 * s);
        m.root.position.set(
          THREE.MathUtils.lerp(CHAIR_POS.x, 0.95, e),
          THREE.MathUtils.lerp(SEAT_Y, 0, e) + Math.sin(s * Math.PI) * 0.08,
          CHAIR_POS.z
        );
        m.pose = 1 - e;
        m.setLoose(c.loose);
        m.cape.visible = s < 0.15;
        if (s >= 1) {
          c.state = 'toMirror';
          m.calmHead = false;
          c.path = [new THREE.Vector3(0.95, 0, -2.4), MIRROR_SPOT.clone()];
          m.setExpression('neutral');
        }
        break;
      }
      case 'toMirror': {
        if (this.follow(c, dt)) {
          c.state = 'mirror';
          c.t = 0;
        }
        break;
      }
      case 'mirror': {
        c.t += dt;
        this.faceTo(c, MIRROR_SPOT.x, -3, dt, 6);
        if (c.t > 1.2 && !c.reacted) {
          c.reacted = true;
          this.react(c);
        }
        if (c.t > 2.2) m.look.yaw = Math.sin((c.t - 2.2) * 2.6) * 0.6;
        else m.look.yaw = 0;
        m.look.pitch = c.t > 2.2 ? Math.sin((c.t - 2.2) * 1.7) * 0.12 : -0.05;
        if ((c.grade === 'perfect' || c.grade === 'good') && c.t > 1.6) m.root.position.y = Math.abs(Math.sin(c.t * 7)) * 0.04;
        if (c.t > 6.3) {
          m.root.position.y = 0;
          m.look.yaw = 0;
          m.look.pitch = 0;
          c.state = 'toPay';
          c.path = [new THREE.Vector3(0.95, 0, -2.4), new THREE.Vector3(0.95, 0, -1.0), WAIT_SPOT.clone()];
        }
        break;
      }
      case 'toPay': {
        if (this.follow(c, dt)) {
          c.state = 'paying';
          c.t = 0;
          this.showResult(c);
        }
        break;
      }
      case 'paying': {
        this.faceTo(c, this.camera.position.x, this.camera.position.z, dt);
        break;
      }
      case 'leaving': {
        if (!c.doorDone && m.root.position.z > 3.0 && m.root.position.z < 3.6) {
          c.doorDone = true;
          this.audio.doorCreak();
          this.world.doorKick();
        }
        if (this.follow(c, dt)) {
          c.state = 'queue'; // marker for removal
          c.t = -1;
        }
        break;
      }
    }
  }

  // ------------------------------------------------------------------ result & reaction
  private gradeOf(score: number): Grade {
    if (score >= 90) return 'perfect';
    if (score >= 75) return 'good';
    if (score >= 55) return 'ok';
    if (score >= 30) return 'funny';
    return 'terrible';
  }

  finish() {
    const c = this.current;
    if (!c || c.state !== 'seated') return;
    const ev = c.model.hair.evaluate(c.style, { powder: c.powder, loose: c.loose, accidents: c.accidents, razorNeck: c.razorNeck });
    if (!c.fixAsked && ev.score >= 45 && ev.score < 82 && Math.random() < 0.45) {
      c.fixAsked = true;
      c.override = { expr: 'smug', t: 3 };
      const dir = ev.worstDir === 'long' ? 'long' : 'short';
      this.say(c, `Chetta, the ${REGION_NAME[ev.worst]} is still a bit too ${dir}. Please fix it!`, 'hmm');
      this.onEvent({ type: 'toast', text: `Customer wants a fix: ${REGION_NAME[ev.worst]} looks too ${dir}` });
      this.emit();
      return;
    }
    c.eval = ev;
    c.grade = this.gradeOf(ev.score);
    c.state = 'standing';
    c.t = 0;
    c.override = null;
    this.endStroke();
    this.setMode('walk');
    this.audio.stopLoop();
    c.model.setExpression('neutral');
    this.emit();
  }

  private react(c: Cust) {
    const p = c.data.personality;
    let expr: Expr = 'neutral';
    let voice: VoiceKind = 'hmm';
    switch (c.grade) {
      case 'perfect':
        expr = p === 'jolly' ? 'laugh' : 'happy';
        voice = 'happy';
        break;
      case 'good':
        expr = 'happy';
        voice = 'happy';
        break;
      case 'ok':
        expr = p === 'fussy' ? 'smug' : 'neutral';
        voice = 'hmm';
        break;
      case 'funny':
        expr = p === 'dramatic' ? 'shock' : p === 'fussy' || p === 'impatient' ? 'angry' : 'laugh';
        voice = expr === 'laugh' ? 'laugh' : expr === 'angry' ? 'angry' : 'boing';
        break;
      case 'terrible':
        expr = p === 'jolly' ? 'laugh' : p === 'calm' || p === 'sleepy' ? 'sad' : 'shock';
        voice = expr === 'laugh' ? 'laugh' : expr === 'sad' ? 'sad' : 'shock';
        break;
    }
    c.model.setExpression(expr);
    c.model.talk = 2.5;
    this.audio.stinger(c.grade === 'perfect' || c.grade === 'good' || c.grade === 'ok');
    this.audio.voice(voice, c.data.pitch);
    const line = pick(LINES[c.grade]);
    setTimeout(() => {
      if (!this.disposed) this.say(c, line, undefined, true);
    }, 500);
  }

  private showResult(c: Cust) {
    if (c.resultShown || !c.eval) return;
    c.resultShown = true;
    const ev = c.eval;
    const score = ev.score;
    const rep = this.save.rep;
    let pay = Math.round(c.style.price * (0.25 + 0.75 * (score / 100)) * (1 + (rep - 3) * 0.04));
    if (c.impatient) pay = Math.round(pay * 0.8);
    if (c.grade === 'terrible') pay = Math.round(pay * 0.4);
    let tip = 0;
    if (score >= 90) tip = 10 + Math.floor(Math.random() * 20);
    else if (score >= 75) tip = 5 + Math.floor(Math.random() * 10);
    if (c.data.personality === 'jolly' && score >= 60) tip += 5;
    c.total = pay + tip;
    const labels: Record<Grade, string> = { perfect: 'Perfect haircut!', good: 'Good haircut', ok: 'Acceptable haircut', funny: 'Funny mistake!', terrible: 'Terrible haircut!' };
    const notes: string[] = [];
    if (ev.patchy > 0.04) notes.push('Bald patches spotted!');
    if (c.accidents > 0) notes.push(`Careless clipping near face ×${c.accidents}`);
    if (c.powder > 0.5) notes.push('Talcum finish +');
    if (c.loose < 0.25) notes.push('Clean cape +');
    else if (c.loose > 0.6) notes.push('Hair all over the cape!');
    if (c.impatient) notes.push('Customer got impatient (−20%)');
    if (c.razorNeck) notes.push('Neat neckline +');
    const r: ResultInfo = {
      name: c.data.name,
      styleName: c.style.name,
      score,
      grade: c.grade,
      label: labels[c.grade],
      pay,
      tip,
      total: c.total,
      quote: this.sayMsg?.text ?? '',
      lines: [
        { label: 'Length match', value: Math.round(ev.lenScore * 100) },
        { label: 'Side symmetry', value: Math.round(ev.symScore * 100) },
        { label: 'Top shape', value: Math.round(ev.topScore * 100) },
        { label: 'Back shape', value: Math.round(ev.backScore * 100) },
        { label: 'Overall look', value: Math.round(ev.resScore * 100) },
      ],
      notes,
    };
    this.onEvent({ type: 'result', result: r });
    this.emit();
  }

  collect() {
    const c = this.current;
    if (!c || c.state !== 'paying') return;
    const ev = c.eval!;
    const s = this.save;
    s.money += c.total;
    s.dayEarn += c.total;
    s.dayServed += 1;
    s.totalServed += 1;
    s.dayScores.push(ev.score);
    s.best = Math.max(s.best, ev.score);
    s.rep = clamp(s.rep + ((ev.score - 55) / 100) * 0.7, 0, 5);
    s.sat.push(ev.score);
    if (s.sat.length > 10) s.sat.shift();
    this.persist();
    this.audio.cash();
    this.onEvent({ type: 'cash', amount: c.total });
    c.model.setExpression(c.grade === 'terrible' || c.grade === 'funny' ? 'angry' : 'happy');
    c.state = 'leaving';
    c.doorDone = false;
    c.exitSide = Math.random() < 0.5 ? -1 : 1;
    c.path = [new THREE.Vector3(0.3, 0, 0.8), new THREE.Vector3(0, 0, 2.4), new THREE.Vector3(0, 0, 4.0), new THREE.Vector3(c.exitSide * 4, 0, 5.3), new THREE.Vector3(c.exitSide * 12, 0, 5.4)];
    this.leavers.push(c);
    this.current = null;
    this.spawnT = Math.max(this.spawnT, 2);
    if (s.dayServed >= DAY_GOAL) {
      this.dayLocked = true;
      this.dayEndT = 3.0;
    }
    this.emit();
  }

  nextDay() {
    const s = this.save;
    s.day += 1;
    s.dayEarn = 0;
    s.dayServed = 0;
    s.dayScores = [];
    this.dayLocked = false;
    this.dayEndT = -1;
    this.spawnT = 2;
    this.persist();
    this.emit();
  }

  // ------------------------------------------------------------------ cutting
  private toolToCut(t: ToolId): CutTool | null {
    if (t === 'clipper' || t === 'scissors' || t === 'razor' || t === 'comb' || t === 'spray') return t;
    return null;
  }

  private spawnP(pos: THREE.Vector3, vel: THREE.Vector3, color: THREE.ColorRepresentation, size: number, life: number, grav: number, settle = false) {
    const d = this.pData[this.pIdx];
    d.p.copy(pos);
    d.v.copy(vel);
    d.life = life;
    d.max = life;
    d.size = size;
    d.grav = grav;
    d.settle = settle;
    this.tmpC.set(color);
    this.pMesh.setColorAt(this.pIdx, this.tmpC);
    if (this.pMesh.instanceColor) this.pMesh.instanceColor.needsUpdate = true;
    this.pIdx = (this.pIdx + 1) % this.PN;
  }

  private updateParticles(dt: number) {
    let any = false;
    for (let i = 0; i < this.PN; i++) {
      const d = this.pData[i];
      if (d.life <= 0) continue;
      any = true;
      d.life -= dt;
      if (d.life <= 0) {
        this.tmpM.makeScale(0, 0, 0);
        this.pMesh.setMatrixAt(i, this.tmpM);
        continue;
      }
      d.v.y -= d.grav * dt;
      d.p.addScaledVector(d.v, dt);
      if (d.p.y < 0.02 && d.settle) {
        d.p.y = 0.02;
        d.v.set(0, 0, 0);
      }
      const s = d.size * Math.min(1, d.life / 0.4);
      this.tmpQ.setFromEuler(new THREE.Euler(d.life * 5, d.life * 3, 0));
      this.tmpS.set(s * 1.8, s * 0.5, s);
      this.tmpM.compose(d.p, this.tmpQ, this.tmpS);
      this.pMesh.setMatrixAt(i, this.tmpM);
    }
    if (any) this.pMesh.instanceMatrix.needsUpdate = true;
  }

  private strokeUpdate(dt: number) {
    const c = this.current;
    if (!c || c.state !== 'seated' || !this.tool || !this.stroking || this.strokeId < 0) {
      if (this.contact) this.audio.stopLoop();
      this.contact = false;
      this.prevLocal = null;
      return;
    }
    const tool = this.tool;
    const rig = this.handRigs.get(tool)!;
    this.raycaster.setFromCamera(this.strokeNdc, this.camera);
    const ray = this.raycaster.ray;
    const C = this.headCenter(this.tmpV2);
    const cp = ray.closestPointToPoint(C, new THREE.Vector3());
    const dist = cp.distanceTo(C);
    const dirOut = cp.clone().sub(C);
    if (dirOut.lengthSq() < 1e-8) dirOut.set(0, 0, 1);
    dirOut.normalize();
    let P: THREE.Vector3;
    const contact = dist < SURF + 0.03;
    if (contact) {
      // first intersection of ray with sphere of radius SURF (front side)
      const sph = new THREE.Sphere(C, SURF);
      const hit = ray.intersectSphere(sph, new THREE.Vector3());
      P = hit ?? C.clone().addScaledVector(dirOut, SURF);
    } else {
      P = C.clone().addScaledVector(dirOut, SURF + 0.04);
    }
    this.toolPoint.copy(P);
    if (!contact) {
      if (this.contact) this.audio.stopLoop();
      this.contact = false;
      this.prevLocal = null;
      return;
    }
    this.contact = true;
    const head = c.model.headGroup;
    head.updateWorldMatrix(true, false);
    const local = head.worldToLocal(P.clone());
    const nl = local.clone().normalize();
    const faceZone = nl.z > 0.5 && nl.y < 0.42;
    const neckZone = nl.y < 0.05 && nl.z < -0.1;
    const dx = this.prevLocal ? local.x - this.prevLocal.x : 0;
    const dz = this.prevLocal ? local.z - this.prevLocal.z : 0;
    this.prevLocal = local.clone();

    // sounds
    const loopMap: Partial<Record<ToolId, LoopKind>> = { clipper: 'clipper', razor: 'razor', comb: 'comb', duster: 'duster', towel: 'towel', spray: 'spray', powder: 'powder' };
    const lk = loopMap[tool];
    if (lk) this.audio.startLoop(lk);
    if (tool === 'scissors') {
      this.snipT -= dt;
      if (this.snipT <= 0) {
        this.snipT = 0.26;
        this.audio.snip();
      }
    }

    const cutTool = this.toolToCut(tool);
    if (cutTool) {
      // accident near face
      if (faceZone && (tool === 'clipper' || tool === 'razor' || tool === 'scissors') && c.flinchCd <= 0) {
        c.flinchCd = 2.5;
        c.accidents++;
        c.override = { expr: 'shock', t: 1.6 };
        this.say(c, pick(LINES.accident), 'shock');
      } else if (!faceZone) {
        const res = c.model.hair.apply(cutTool, local, rig.radius, dt, GUARDS[this.guard], dx, dz);
        if (res.removed > 0) {
          c.loose = Math.min(1, c.loose + res.removed * 0.0022);
          const n = Math.min(4, Math.ceil(res.removed * 60));
          for (let i = 0; i < n; i++) {
            if (Math.random() < 0.5) {
              this.spawnP(P, this.tmpV.set(rnd(-0.12, 0.12), rnd(0.05, 0.2), rnd(-0.12, 0.12)), c.data.hair, 0.007, rnd(0.6, 1.4), 2.8, true);
            }
          }
          if (tool === 'razor' && neckZone && res.removed > 0.01) c.razorNeck = true;
        }
        if (tool === 'spray') {
          this.puffT -= dt;
          if (this.puffT <= 0) {
            this.puffT = 0.03;
            const camDir = ray.direction;
            this.spawnP(
              P.clone().addScaledVector(camDir, -0.06),
              this.tmpV.copy(camDir).multiplyScalar(0.5).add(new THREE.Vector3(rnd(-0.1, 0.1), rnd(-0.05, 0.1), rnd(-0.1, 0.1))),
              0xbfe4ff,
              0.01,
              0.5,
              1.2
            );
          }
          if (!c.coldDone && res.touched > 5) {
            c.coldDone = true;
            c.override = { expr: 'shock', t: 1.2 };
            this.say(c, pick(['Aaah! Cold water!', 'Ayyo cold!']), 'shock');
          }
        }
      }
    } else if (tool === 'duster' || tool === 'towel') {
      const rate = tool === 'duster' ? 0.9 : 0.55;
      const before = c.loose;
      c.loose = Math.max(0, c.loose - rate * dt);
      if (before > 0.02 && Math.random() < 0.5) {
        this.spawnP(P, this.tmpV.set(rnd(-0.2, 0.2), rnd(0.1, 0.3), rnd(-0.2, 0.2)), c.data.hair, 0.007, rnd(0.6, 1.2), 2.5, true);
      }
    } else if (tool === 'powder') {
      c.powder = Math.min(1, c.powder + dt * 0.35);
      this.puffT -= dt;
      if (this.puffT <= 0) {
        this.puffT = 0.025;
        this.spawnP(P, this.tmpV.set(rnd(-0.08, 0.08), rnd(0.02, 0.1), rnd(-0.08, 0.08)), 0xffffff, rnd(0.02, 0.045), rnd(0.6, 1.1), -0.05);
      }
      if (c.powder > 0.8 && !c.sneezeDone) {
        c.sneezeDone = true;
        c.override = { expr: 'shock', t: 1.8 };
        this.audio.voice('sneeze', c.data.pitch);
        this.say(c, 'Aaa... aaachoo!', undefined, false);
      }
    }
    // ticklish
    if ((neckZone || nl.y < 0.1) && c.tickleCd <= 0 && (tool === 'clipper' || tool === 'duster' || tool === 'powder' || tool === 'razor') && Math.random() < dt * 0.35) {
      c.tickleCd = 9;
      c.override = { expr: 'laugh', t: 1.8 };
      this.say(c, pick(LINES.tickle), 'laugh');
    }
  }

  // ------------------------------------------------------------------ camera
  private updateCamera(dt: number, instant = false) {
    const desiredPos = this.tmpV;
    const q = this.tmpQ;
    if (this.mode === 'walk') {
      desiredPos.set(this.pos.x, 1.55 + Math.sin(this.bob) * 0.012, this.pos.z);
      q.setFromEuler(new THREE.Euler(this.pitch, this.yaw, 0, 'YXZ'));
    } else {
      const h = this.headCenter(new THREE.Vector3());
      const o = this.orbit;
      const cp = Math.cos(o.pitch);
      desiredPos.set(h.x + Math.sin(o.yaw) * cp * o.dist, h.y + Math.sin(o.pitch) * o.dist + 0.02, h.z + Math.cos(o.yaw) * cp * o.dist);
      desiredPos.x = clamp(desiredPos.x, -2.3, 2.3);
      desiredPos.z = clamp(desiredPos.z, -2.8, 2.8);
      desiredPos.y = clamp(desiredPos.y, 0.6, 2.4);
      const m = new THREE.Matrix4().lookAt(desiredPos, h, new THREE.Vector3(0, 1, 0));
      q.setFromRotationMatrix(m);
    }
    const rate = this.mode === 'walk' ? 26 : 9;
    const k = instant ? 1 : 1 - Math.exp(-rate * dt);
    this.camera.position.lerp(desiredPos, this.mode === 'walk' ? Math.max(k, 0.5) : k);
    this.camera.quaternion.slerp(q, k);
    this.camera.updateMatrixWorld(true);
  }

  private updateHolder(dt: number) {
    const showTool = this.tool !== null;
    this.holder.visible = showTool;
    this.bareR.visible = !showTool && this.mode === 'walk';
    this.bareL.visible = this.mode === 'walk';
    this.bareR.position.y = -0.27 + Math.sin(this.bob) * 0.006;
    this.bareL.position.y = -0.27 + Math.sin(this.bob + 1) * 0.006;
    if (!showTool) return;
    const rig = this.handRigs.get(this.tool!)!;
    const target = new THREE.Vector3();
    const rot = new THREE.Euler();
    if (this.mode === 'walk') {
      target.set(0.2, -0.2 + Math.sin(this.bob) * 0.006, -0.45);
      rot.set(0.5, 0.3, 0);
    } else {
      const world = new THREE.Vector3();
      if (this.stroking) world.copy(this.toolPoint);
      else {
        const h = this.headCenter(new THREE.Vector3());
        const right = new THREE.Vector3(1, 0, 0).applyQuaternion(this.camera.quaternion);
        const up = new THREE.Vector3(0, 1, 0).applyQuaternion(this.camera.quaternion);
        world.copy(h).addScaledVector(right, 0.17).addScaledVector(up, 0.07);
      }
      target.copy(this.camera.worldToLocal(world));
      rot.set(0.55, 0.32, 0);
    }
    const k = 1 - Math.exp(-(this.mode === 'cut' ? 20 : 12) * dt);
    this.holder.position.lerp(target, k);
    this.holder.rotation.x += (rot.x - this.holder.rotation.x) * k;
    this.holder.rotation.y += (rot.y - this.holder.rotation.y) * k;
    this.holder.rotation.z += (rot.z - this.holder.rotation.z) * k;
    rig.animate(this.stroking && this.contact, this.time);
  }

  // ------------------------------------------------------------------ hint + snapshot
  private hint(): string {
    const c = this.current;
    if (this.dayLocked) return 'Shop closed for the day!';
    if (!this.started) return '';
    if (!c) {
      if (this.queue.length) return 'A customer is coming…';
      return this.tool ? 'Waiting for the next customer…' : 'Tip: walk to the table on the right and tap a tool.';
    }
    switch (c.state) {
      case 'enter':
        return `${c.data.name} is walking in…`;
      case 'waitPaper':
        return 'Look at the drawing, then accept.';
      case 'toChair':
      case 'sitting':
        return `${c.data.name} is sitting down…`;
      case 'seated':
        if (this.mode === 'cut') return this.tool ? 'Touch & drag on the head to use the tool. Drag elsewhere to look around.' : 'Pick a tool from the bottom bar.';
        if (!this.tool) return 'Pick a tool: tap one on the table or use the bottom bar.';
        return this.nearChair() ? 'Press “Start haircut” to begin.' : 'Walk to the chair.';
      case 'standing':
      case 'toMirror':
      case 'mirror':
        return `${c.data.name} is checking the mirror…`;
      default:
        return '';
    }
  }

  emit() {
    const c = this.current;
    const s = this.save;
    let guide: Snapshot['guide'] = null;
    if (this.settings.guide && c && c.state === 'seated') {
      const avg = c.model.hair.averages();
      const tg = c.model.hair.targets(c.style);
      guide = REGIONS.map((r) => ({ region: r, cur: avg[r], tgt: tg[r] }));
    }
    const sat = s.sat.length ? Math.round(s.sat.reduce((a, b) => a + b, 0) / s.sat.length) : 0;
    const snap: Snapshot = {
      mode: this.mode,
      started: this.started,
      money: s.money,
      day: s.day,
      dayEarn: s.dayEarn,
      dayServed: s.dayServed,
      dayGoal: DAY_GOAL,
      rep: s.rep,
      sat,
      totalServed: s.totalServed,
      best: s.best,
      queue: this.queue.length,
      tool: this.tool,
      guard: this.guard,
      prompt: this.prompt,
      hint: this.hint(),
      stroking: this.stroking && this.contact,
      nearChair: this.nearChair(),
      customer: c
        ? {
            name: c.data.name,
            personality: c.data.personality,
            patience: c.patience,
            state: c.state,
            styleName: c.style.name,
            drawing: c.drawing,
            canFinish: c.state === 'seated',
            mood: c.data.personality,
          }
        : null,
      say: this.sayT > 0 ? this.sayMsg : null,
      guide,
    };
    this.onSnap(snap);
  }

  // ------------------------------------------------------------------ main loop
  private loop = (now: number) => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    let dt = (now - this.lastT) / 1000;
    this.lastT = now;
    dt = Math.min(dt, 0.05);
    if (!this.paused) this.update(dt);
    this.renderer.render(this.scene, this.camera);
  };

  private update(dt: number) {
    this.time += dt;
    this.world.update(dt, this.time);

    // movement
    let mx = this.move.x;
    let my = this.move.y;
    if (this.keys.has('KeyW') || this.keys.has('ArrowUp')) my += 1;
    if (this.keys.has('KeyS') || this.keys.has('ArrowDown')) my -= 1;
    if (this.keys.has('KeyD')) mx += 1;
    if (this.keys.has('KeyA')) mx -= 1;
    if (this.keys.has('ArrowLeft')) this.yaw += dt * 1.8;
    if (this.keys.has('ArrowRight')) this.yaw -= dt * 1.8;
    if (this.started && !this.modal) {
      if (this.mode === 'walk') {
        const len = Math.hypot(mx, my);
        if (len > 0.05) {
          const l = Math.min(1, len);
          const nx = mx / len;
          const ny = my / len;
          const fx = -Math.sin(this.yaw);
          const fz = -Math.cos(this.yaw);
          const rx = Math.cos(this.yaw);
          const rz = -Math.sin(this.yaw);
          const sp = 1.9 * l;
          this.pos.x += (fx * ny + rx * nx) * sp * dt;
          this.pos.z += (fz * ny + rz * nx) * sp * dt;
          this.world.collide(this.pos, 0.3);
          this.bob += dt * 9 * l;
        }
      } else {
        this.orbit.yaw -= mx * dt * 1.9;
        this.orbit.pitch = clamp(this.orbit.pitch + my * dt * 1.1, -0.35, 1.35);
      }
    }

    // spawn
    if (this.started && !this.dayLocked && !this.modal) {
      const total = this.queue.length + (this.current ? 1 : 0) + this.leavers.length * 0;
      const served = this.save.dayServed + total;
      if (total < 4 && served < DAY_GOAL) {
        this.spawnT -= dt;
        if (this.spawnT <= 0) {
          this.spawnCustomer();
          this.spawnT = rnd(9, 18) * (1.35 - this.save.rep * 0.1);
        }
      }
    }
    if (!this.current && this.queue.length && this.started && !this.dayLocked) {
      const first = this.queue[0];
      const p = first.model.root.position;
      // wait until it has reached the porch (or is close)
      if (p.z < 4.6 || Math.abs(p.x) < 6) this.promote();
    }

    // customers
    if (this.started) {
      [...this.queue].forEach((c) => this.updateCust(c, dt));
      if (this.current) {
        this.updateCust(this.current, dt);
        if (this.current.state === 'seated' || this.current.state === 'sitting') this.current.model.hair.tick(dt);
      }
      for (let i = this.leavers.length - 1; i >= 0; i--) {
        const c = this.leavers[i];
        this.updateCust(c, dt);
        if (c.state === 'queue' && c.t === -1) {
          this.removeCust(c);
          this.leavers.splice(i, 1);
        }
      }
    }
    if (this.dayEndT > 0) {
      this.dayEndT -= dt;
      if (this.dayEndT <= 0) {
        const s = this.save;
        const avg = s.dayScores.length ? Math.round(s.dayScores.reduce((a, b) => a + b, 0) / s.dayScores.length) : 0;
        this.onEvent({ type: 'dayEnd', summary: { day: s.day, earned: s.dayEarn, served: s.dayServed, avg, rep: s.rep } });
      }
    }
    if (this.sayT > 0) this.sayT -= dt;

    // camera, tools
    this.updateCamera(dt);
    this.strokeUpdate(dt);
    this.updateHolder(dt);
    this.updateParticles(dt);

    this.promptT -= dt;
    if (this.promptT <= 0) {
      this.promptT = 0.15;
      this.computePrompt();
    }
    this.snapT -= dt;
    if (this.snapT <= 0) {
      this.snapT = 0.12;
      this.emit();
    }
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    this.ro.disconnect();
    const c = this.canvas;
    c.removeEventListener('pointerdown', this.onDown);
    c.removeEventListener('pointermove', this.onMove);
    c.removeEventListener('pointerup', this.onUp);
    c.removeEventListener('pointercancel', this.onUp);
    c.removeEventListener('wheel', this.onWheel);
    window.removeEventListener('keydown', this.onKey);
    window.removeEventListener('keyup', this.onKeyUp);
    this.clearCustomers();
    this.audio.dispose();
    this.world.dispose();
    this.renderer.dispose();
  }
}
