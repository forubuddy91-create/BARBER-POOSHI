// Fully synthesized audio – no external assets needed.

export type LoopKind = 'clipper' | 'razor' | 'duster' | 'towel' | 'comb' | 'spray' | 'powder';
export type VoiceKind = 'laugh' | 'shock' | 'angry' | 'happy' | 'sad' | 'boing' | 'hmm' | 'sneeze';

export class AudioEngine {
  ctx: AudioContext | null = null;
  master!: GainNode;
  sfx!: GainNode;
  amb!: GainNode;
  noiseBuf!: AudioBuffer;
  vol = { master: 0.8, sfx: 1, amb: 0.7 };
  voiceOn = true;
  loopNodes: { stop: () => void } | null = null;
  loopKind: LoopKind | null = null;
  ambTimer = 0;
  voiceCache: SpeechSynthesisVoice | null = null;

  init() {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') void this.ctx.resume();
      return;
    }
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC();
    const c = this.ctx;
    this.master = c.createGain();
    this.sfx = c.createGain();
    this.amb = c.createGain();
    this.sfx.connect(this.master);
    this.amb.connect(this.master);
    const comp = c.createDynamicsCompressor();
    this.master.connect(comp);
    comp.connect(c.destination);
    this.applyVolumes();
    const len = c.sampleRate * 2;
    this.noiseBuf = c.createBuffer(1, len, c.sampleRate);
    const d = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    this.startAmbience();
  }

  applyVolumes() {
    if (!this.ctx) return;
    this.master.gain.value = this.vol.master;
    this.sfx.gain.value = this.vol.sfx;
    this.amb.gain.value = this.vol.amb;
  }

  setVolumes(master: number, sfx: number, amb: number, voice: boolean) {
    this.vol = { master, sfx, amb };
    this.voiceOn = voice;
    this.applyVolumes();
    if (!voice && 'speechSynthesis' in window) window.speechSynthesis.cancel();
  }

  suspend(b: boolean) {
    if (!this.ctx) return;
    if (b) void this.ctx.suspend();
    else void this.ctx.resume();
  }

  private noise(dest: AudioNode, loop = true) {
    const c = this.ctx!;
    const s = c.createBufferSource();
    s.buffer = this.noiseBuf;
    s.loop = loop;
    s.playbackRate.value = 0.8 + Math.random() * 0.4;
    s.connect(dest);
    s.start(0, Math.random() * 1.5);
    return s;
  }

  // ---------- ambience: traffic + fan + birds ----------
  startAmbience() {
    const c = this.ctx!;
    // traffic rumble
    const g = c.createGain();
    g.gain.value = 0.16;
    const lp = c.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = 380;
    this.noise(lp);
    lp.connect(g);
    g.connect(this.amb);
    const lfo = c.createOscillator();
    lfo.frequency.value = 0.13;
    const lg = c.createGain();
    lg.gain.value = 0.07;
    lfo.connect(lg);
    lg.connect(g.gain);
    lfo.start();
    // ceiling fan whoosh
    const fg = c.createGain();
    fg.gain.value = 0.05;
    const bp = c.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = 500;
    bp.Q.value = 0.7;
    this.noise(bp);
    bp.connect(fg);
    fg.connect(this.amb);
    const fl = c.createOscillator();
    fl.frequency.value = 3.4;
    const flg = c.createGain();
    flg.gain.value = 0.035;
    fl.connect(flg);
    flg.connect(fg.gain);
    fl.start();
    const hum = c.createOscillator();
    hum.type = 'sine';
    hum.frequency.value = 52;
    const hg = c.createGain();
    hg.gain.value = 0.03;
    hum.connect(hg);
    hg.connect(this.amb);
    hum.start();
    // random one-shots
    const tick = () => {
      if (!this.ctx) return;
      const r = Math.random();
      if (r < 0.35) this.birds();
      else if (r < 0.6) this.horn();
      else if (r < 0.7) this.bicycleBell();
      this.ambTimer = window.setTimeout(tick, 2500 + Math.random() * 5000);
    };
    this.ambTimer = window.setTimeout(tick, 3000);
  }

  private tone(freq: number, dur: number, type: OscillatorType, vol: number, dest: AudioNode, when = 0, slide = 0) {
    const c = this.ctx!;
    const o = c.createOscillator();
    const g = c.createGain();
    o.type = type;
    const t = c.currentTime + when;
    o.frequency.setValueAtTime(freq, t);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, freq * slide), t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + Math.min(0.02, dur / 3));
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g);
    g.connect(dest);
    o.start(t);
    o.stop(t + dur + 0.05);
  }

  birds() {
    if (!this.ctx) return;
    const n = 2 + Math.floor(Math.random() * 4);
    const base = 2200 + Math.random() * 1500;
    for (let i = 0; i < n; i++) this.tone(base + Math.random() * 400, 0.09, 'sine', 0.05, this.amb, i * 0.13, 1.4);
  }
  horn() {
    if (!this.ctx) return;
    const f = 330 + Math.random() * 100;
    this.tone(f, 0.18, 'square', 0.035, this.amb, 0, 1);
    this.tone(f * 1.26, 0.18, 'square', 0.03, this.amb, 0, 1);
    if (Math.random() < 0.5) {
      this.tone(f, 0.22, 'square', 0.035, this.amb, 0.26, 1);
      this.tone(f * 1.26, 0.22, 'square', 0.03, this.amb, 0.26, 1);
    }
  }
  bicycleBell() {
    if (!this.ctx) return;
    this.tone(2600, 0.5, 'sine', 0.04, this.amb, 0, 1);
    this.tone(3300, 0.5, 'sine', 0.03, this.amb, 0.02, 1);
    this.tone(2600, 0.5, 'sine', 0.04, this.amb, 0.18, 1);
  }

  // ---------- one-shot SFX ----------
  snip() {
    if (!this.ctx) return;
    const c = this.ctx;
    const hp = c.createBiquadFilter();
    hp.type = 'highpass';
    hp.frequency.value = 3500;
    const g = c.createGain();
    const t = c.currentTime;
    g.gain.setValueAtTime(0.5, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.07);
    hp.connect(g);
    g.connect(this.sfx);
    const s = this.noise(hp, false);
    s.stop(t + 0.09);
    this.tone(4200, 0.05, 'triangle', 0.1, this.sfx, 0, 0.7);
  }

  doorCreak() {
    if (!this.ctx) return;
    const c = this.ctx;
    const o = c.createOscillator();
    o.type = 'sawtooth';
    const g = c.createGain();
    const f = c.createBiquadFilter();
    f.type = 'bandpass';
    f.frequency.value = 700;
    f.Q.value = 6;
    const t = c.currentTime;
    o.frequency.setValueAtTime(140, t);
    o.frequency.linearRampToValueAtTime(260, t + 0.35);
    o.frequency.linearRampToValueAtTime(180, t + 0.6);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(0.1, t + 0.1);
    g.gain.linearRampToValueAtTime(0.0001, t + 0.65);
    o.connect(f);
    f.connect(g);
    g.connect(this.sfx);
    o.start(t);
    o.stop(t + 0.7);
    // shop bell
    this.tone(3100, 0.7, 'sine', 0.06, this.sfx, 0.05, 1);
    this.tone(4100, 0.6, 'sine', 0.04, this.sfx, 0.07, 1);
    this.tone(3100, 0.6, 'sine', 0.05, this.sfx, 0.2, 1);
  }

  cash() {
    if (!this.ctx) return;
    // paper rustle
    const c = this.ctx;
    const hp = c.createBiquadFilter();
    hp.type = 'highpass';
    hp.frequency.value = 2500;
    const g = c.createGain();
    const t = c.currentTime;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(0.25, t + 0.05);
    g.gain.linearRampToValueAtTime(0.0001, t + 0.35);
    hp.connect(g);
    g.connect(this.sfx);
    this.noise(hp, false).stop(t + 0.4);
    // coins
    for (let i = 0; i < 5; i++) {
      const f = 1800 + Math.random() * 1400;
      this.tone(f, 0.25, 'triangle', 0.12, this.sfx, 0.25 + i * 0.07, 1);
      this.tone(f * 1.5, 0.2, 'sine', 0.06, this.sfx, 0.25 + i * 0.07, 1);
    }
    this.tone(1318, 0.18, 'square', 0.05, this.sfx, 0.7, 1);
    this.tone(1760, 0.35, 'square', 0.05, this.sfx, 0.85, 1);
  }

  click() {
    if (!this.ctx) return;
    this.tone(900, 0.05, 'square', 0.04, this.sfx, 0, 0.8);
  }
  pick() {
    if (!this.ctx) return;
    this.tone(500, 0.08, 'triangle', 0.12, this.sfx, 0, 1.6);
    this.tone(760, 0.08, 'triangle', 0.1, this.sfx, 0.05, 1.3);
  }
  drop() {
    if (!this.ctx) return;
    this.tone(300, 0.1, 'triangle', 0.14, this.sfx, 0, 0.6);
  }
  stinger(good: boolean) {
    if (!this.ctx) return;
    const notes = good ? [523, 659, 784, 1047] : [392, 349, 311, 262];
    notes.forEach((n, i) => this.tone(n, 0.25, good ? 'triangle' : 'sawtooth', good ? 0.12 : 0.07, this.sfx, i * 0.12, 1));
  }

  // ---------- cartoon voices ----------
  voice(kind: VoiceKind, pitch = 1) {
    if (!this.ctx) return;
    const c = this.ctx;
    const mk = (f0: number, f1: number, dur: number, when: number, vol = 0.16, form = 900) => {
      const o = c.createOscillator();
      o.type = 'sawtooth';
      const t = c.currentTime + when;
      o.frequency.setValueAtTime(f0 * pitch, t);
      o.frequency.linearRampToValueAtTime(f1 * pitch, t + dur);
      const bp = c.createBiquadFilter();
      bp.type = 'bandpass';
      bp.frequency.value = form;
      bp.Q.value = 2.5;
      const g = c.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(vol, t + dur * 0.2);
      g.gain.linearRampToValueAtTime(0.0001, t + dur);
      o.connect(bp);
      bp.connect(g);
      g.connect(this.sfx);
      o.start(t);
      o.stop(t + dur + 0.05);
    };
    switch (kind) {
      case 'laugh':
        for (let i = 0; i < 6; i++) mk(420 - i * 15, 330 - i * 15, 0.11, i * 0.17, 0.18, 1100 - i * 40);
        break;
      case 'shock':
        mk(300, 700, 0.35, 0, 0.2, 1200);
        mk(700, 650, 0.3, 0.35, 0.15, 800);
        break;
      case 'angry':
        mk(260, 160, 0.3, 0, 0.2, 600);
        mk(240, 140, 0.35, 0.32, 0.2, 500);
        break;
      case 'happy':
        mk(380, 600, 0.18, 0, 0.18, 1300);
        mk(520, 780, 0.28, 0.2, 0.18, 1400);
        break;
      case 'sad':
        mk(520, 300, 0.5, 0, 0.16, 800);
        mk(430, 230, 0.5, 0.5, 0.14, 700);
        break;
      case 'boing':
        this.tone(200, 0.35, 'sine', 0.25, this.sfx, 0, 5);
        break;
      case 'hmm':
        mk(240, 280, 0.25, 0, 0.14, 500);
        mk(280, 230, 0.25, 0.28, 0.14, 500);
        break;
      case 'sneeze':
        mk(300, 400, 0.12, 0, 0.14, 1000);
        mk(500, 520, 0.08, 0.15, 0.2, 1500);
        {
          const hp = c.createBiquadFilter();
          hp.type = 'highpass';
          hp.frequency.value = 1500;
          const g = c.createGain();
          const t = c.currentTime + 0.4;
          g.gain.setValueAtTime(0.4, t);
          g.gain.exponentialRampToValueAtTime(0.001, t + 0.2);
          hp.connect(g);
          g.connect(this.sfx);
          this.noise(hp, false).stop(t + 0.25);
        }
        break;
    }
  }

  say(text: string, pitch = 1.5) {
    if (!this.voiceOn || !('speechSynthesis' in window)) return;
    try {
      const synth = window.speechSynthesis;
      synth.cancel();
      const u = new SpeechSynthesisUtterance(text.replace(/[^\p{L}\p{N}\s.,!?'-]/gu, ''));
      if (!this.voiceCache) {
        const vs = synth.getVoices();
        this.voiceCache = vs.find((v) => /en[-_]IN/i.test(v.lang)) || vs.find((v) => /^en/i.test(v.lang)) || null;
      }
      if (this.voiceCache) u.voice = this.voiceCache;
      u.pitch = pitch;
      u.rate = 1.05;
      u.volume = Math.min(1, this.vol.master);
      synth.speak(u);
    } catch {
      /* ignore */
    }
  }

  // ---------- sustained tool loops ----------
  startLoop(kind: LoopKind) {
    if (!this.ctx || this.loopKind === kind) return;
    this.stopLoop();
    const c = this.ctx;
    const out = c.createGain();
    out.gain.value = 0.0001;
    out.connect(this.sfx);
    const nodes: AudioScheduledSourceNode[] = [];
    out.gain.linearRampToValueAtTime(1, c.currentTime + 0.05);
    const filtNoise = (type: BiquadFilterType, f: number, q: number, vol: number) => {
      const bp = c.createBiquadFilter();
      bp.type = type;
      bp.frequency.value = f;
      bp.Q.value = q;
      const g = c.createGain();
      g.gain.value = vol;
      const s = this.noise(bp);
      bp.connect(g);
      g.connect(out);
      nodes.push(s);
      return g;
    };
    if (kind === 'clipper') {
      const lp = c.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.value = 2200;
      lp.connect(out);
      const mkO = (type: OscillatorType, f: number, v: number) => {
        const o = c.createOscillator();
        o.type = type;
        o.frequency.value = f;
        const g = c.createGain();
        g.gain.value = v;
        o.connect(g);
        g.connect(lp);
        o.start();
        nodes.push(o);
        return o;
      };
      const o1 = mkO('sawtooth', 118, 0.1);
      mkO('square', 236, 0.05);
      mkO('sawtooth', 356, 0.03);
      const lfo = c.createOscillator();
      lfo.frequency.value = 7;
      const lg = c.createGain();
      lg.gain.value = 4;
      lfo.connect(lg);
      lg.connect(o1.frequency);
      lfo.start();
      nodes.push(lfo);
      filtNoise('bandpass', 3500, 1.2, 0.05);
    } else if (kind === 'razor') filtNoise('bandpass', 4200, 2, 0.28);
    else if (kind === 'duster') filtNoise('bandpass', 1800, 0.8, 0.35);
    else if (kind === 'towel') filtNoise('bandpass', 900, 0.6, 0.3);
    else if (kind === 'spray') filtNoise('highpass', 3000, 0.5, 0.35);
    else if (kind === 'powder') filtNoise('lowpass', 1400, 0.5, 0.35);
    else if (kind === 'comb') {
      const g = filtNoise('bandpass', 5500, 3, 0.4);
      const lfo = c.createOscillator();
      lfo.type = 'square';
      lfo.frequency.value = 14;
      const lg = c.createGain();
      lg.gain.value = 0.2;
      lfo.connect(lg);
      lg.connect(g.gain);
      lfo.start();
      nodes.push(lfo);
    }
    this.loopKind = kind;
    this.loopNodes = {
      stop: () => {
        const t = c.currentTime;
        out.gain.cancelScheduledValues(t);
        out.gain.setValueAtTime(out.gain.value, t);
        out.gain.linearRampToValueAtTime(0.0001, t + 0.06);
        setTimeout(() => {
          nodes.forEach((n) => {
            try {
              n.stop();
            } catch {
              /* ignore */
            }
          });
          out.disconnect();
        }, 120);
      },
    };
  }

  stopLoop() {
    if (this.loopNodes) this.loopNodes.stop();
    this.loopNodes = null;
    this.loopKind = null;
  }

  dispose() {
    this.stopLoop();
    clearTimeout(this.ambTimer);
    if (this.ctx) void this.ctx.close();
    this.ctx = null;
    if ('speechSynthesis' in window) window.speechSynthesis.cancel();
  }
}
