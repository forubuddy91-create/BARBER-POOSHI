import * as THREE from 'three';
import { Reflector } from 'three/examples/jsm/objects/Reflector.js';
import { renderDrawing, STYLES } from './hairstyles';

export const CHAIR_POS = new THREE.Vector3(0.3, 0, -1.6);
export const SEAT_Y = 0.06;
export const WAIT_SPOT = new THREE.Vector3(0.3, 0, -0.45);
export const MIRROR_SPOT = new THREE.Vector3(0.55, 0, -2.4);
export const TABLE_SLOT_X = 1.95;
export const TABLE_TOP = 0.85;

export interface Collider {
  kind: 'box' | 'circle';
  a: number; // minx / cx
  b: number; // maxx / cz
  c: number; // minz / r
  d: number; // maxz
}

export interface World {
  group: THREE.Group;
  update: (dt: number, t: number) => void;
  tableSlots: THREE.Vector3[];
  collide: (p: THREE.Vector3, radius: number) => void;
  setMirror: (on: boolean) => void;
  doorKick: () => void;
  sun: THREE.DirectionalLight;
  dispose: () => void;
}

const rnd = (a: number, b: number) => a + Math.random() * (b - a);
const pick = <T,>(a: T[]): T => a[Math.floor(Math.random() * a.length)];

function canvasTex(w: number, h: number, draw: (g: CanvasRenderingContext2D) => void, rep?: [number, number]) {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const g = c.getContext('2d')!;
  draw(g);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 4;
  if (rep) {
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.repeat.set(rep[0], rep[1]);
  }
  return t;
}

function noiseSpeckle(g: CanvasRenderingContext2D, w: number, h: number, n: number, alpha: number, dark = true) {
  for (let i = 0; i < n; i++) {
    g.fillStyle = dark ? `rgba(0,0,0,${Math.random() * alpha})` : `rgba(255,255,255,${Math.random() * alpha})`;
    const s = 1 + Math.random() * 3;
    g.fillRect(Math.random() * w, Math.random() * h, s, s);
  }
}

function signTexture(text: string, sub: string, bg: string, fg: string, w = 512, h = 112) {
  return canvasTex(w, h, (g) => {
    g.fillStyle = bg;
    g.fillRect(0, 0, w, h);
    g.strokeStyle = fg;
    g.lineWidth = 5;
    g.strokeRect(6, 6, w - 12, h - 12);
    g.fillStyle = fg;
    g.textAlign = 'center';
    g.textBaseline = 'middle';
    g.font = `bold ${sub ? 44 : 52}px Arial, sans-serif`;
    g.fillText(text, w / 2, sub ? h * 0.38 : h / 2, w - 40);
    if (sub) {
      g.font = `bold 30px "Noto Sans Malayalam", Arial, sans-serif`;
      g.fillText(sub, w / 2, h * 0.76, w - 40);
    }
    noiseSpeckle(g, w, h, 300, 0.25);
  });
}

export function buildWorld(scene: THREE.Scene, renderer: THREE.WebGLRenderer): World {
  const group = new THREE.Group();
  scene.add(group);
  const disposables: { dispose: () => void }[] = [];
  const colliders: Collider[] = [];
  const updaters: ((dt: number, t: number) => void)[] = [];

  const std = (color: THREE.ColorRepresentation, rough = 0.85, metal = 0) => {
    const m = new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal });
    disposables.push(m);
    return m;
  };
  const lam = (color: THREE.ColorRepresentation) => {
    const m = new THREE.MeshLambertMaterial({ color });
    disposables.push(m);
    return m;
  };
  const addBox = (
    parent: THREE.Object3D,
    w: number,
    h: number,
    d: number,
    m: THREE.Material,
    x: number,
    y: number,
    z: number,
    shadow = true
  ) => {
    const me = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
    me.position.set(x, y, z);
    me.castShadow = shadow;
    me.receiveShadow = true;
    parent.add(me);
    return me;
  };
  const addCyl = (
    parent: THREE.Object3D,
    r1: number,
    r2: number,
    h: number,
    m: THREE.Material,
    x: number,
    y: number,
    z: number,
    seg = 14,
    shadow = true
  ) => {
    const me = new THREE.Mesh(new THREE.CylinderGeometry(r1, r2, h, seg), m);
    me.position.set(x, y, z);
    me.castShadow = shadow;
    me.receiveShadow = true;
    parent.add(me);
    return me;
  };

  // ------------------------------------------------------------------ textures
  const floorTex = canvasTex(
    256,
    256,
    (g) => {
      for (let i = 0; i < 2; i++)
        for (let j = 0; j < 2; j++) {
          g.fillStyle = (i + j) % 2 ? '#9b4a3c' : '#b5654f';
          g.fillRect(i * 128, j * 128, 128, 128);
        }
      noiseSpeckle(g, 256, 256, 1500, 0.25);
      noiseSpeckle(g, 256, 256, 400, 0.15, false);
      g.strokeStyle = 'rgba(40,25,20,0.7)';
      g.lineWidth = 3;
      g.strokeRect(0, 0, 256, 256);
      g.beginPath();
      g.moveTo(128, 0);
      g.lineTo(128, 256);
      g.moveTo(0, 128);
      g.lineTo(256, 128);
      g.stroke();
      // flower motif
      g.fillStyle = 'rgba(240,220,170,0.35)';
      for (const [cx, cy] of [[64, 64], [192, 192]]) {
        g.beginPath();
        g.arc(cx, cy, 22, 0, 7);
        g.fill();
      }
    },
    [5, 6]
  );
  const wallTex = (rw: number) =>
    canvasTex(
      256,
      256,
      (g) => {
        g.fillStyle = '#e4d9a8';
        g.fillRect(0, 0, 256, 256);
        noiseSpeckle(g, 256, 256, 1200, 0.07);
        // stains
        for (let i = 0; i < 6; i++) {
          const gr = g.createRadialGradient(Math.random() * 256, Math.random() * 150, 2, Math.random() * 256, Math.random() * 150, 50);
          gr.addColorStop(0, 'rgba(120,90,40,0.15)');
          gr.addColorStop(1, 'rgba(120,90,40,0)');
          g.fillStyle = gr;
          g.fillRect(0, 0, 256, 256);
        }
        // dado band
        g.fillStyle = '#2f7f6b';
        g.fillRect(0, 170, 256, 86);
        g.fillStyle = '#e9e1c3';
        g.fillRect(0, 166, 256, 5);
        noiseSpeckle(g, 256, 256, 800, 0.2);
        // peeling patches
        for (let i = 0; i < 8; i++) {
          g.fillStyle = 'rgba(200,190,150,0.8)';
          g.beginPath();
          g.ellipse(Math.random() * 256, 170 + Math.random() * 80, 6 + Math.random() * 14, 3 + Math.random() * 8, Math.random() * 3, 0, 7);
          g.fill();
        }
      },
      [rw, 1]
    );
  const woodTex = canvasTex(
    128,
    128,
    (g) => {
      g.fillStyle = '#6b3f1d';
      g.fillRect(0, 0, 128, 128);
      for (let i = 0; i < 60; i++) {
        g.strokeStyle = `rgba(${20 + Math.random() * 30},${10 + Math.random() * 20},5,${Math.random() * 0.4})`;
        g.lineWidth = 1 + Math.random() * 2;
        g.beginPath();
        const y = Math.random() * 128;
        g.moveTo(0, y);
        g.bezierCurveTo(40, y + rnd(-6, 6), 80, y + rnd(-6, 6), 128, y + rnd(-4, 4));
        g.stroke();
      }
    },
    [2, 2]
  );
  const asphaltTex = canvasTex(
    256,
    256,
    (g) => {
      g.fillStyle = '#4a4a4c';
      g.fillRect(0, 0, 256, 256);
      noiseSpeckle(g, 256, 256, 4000, 0.4);
      noiseSpeckle(g, 256, 256, 1200, 0.25, false);
    },
    [14, 1.6]
  );
  const concreteTex = canvasTex(
    128,
    128,
    (g) => {
      g.fillStyle = '#b9b4a6';
      g.fillRect(0, 0, 128, 128);
      noiseSpeckle(g, 128, 128, 800, 0.25);
      g.strokeStyle = 'rgba(0,0,0,0.25)';
      g.strokeRect(0, 0, 128, 128);
    },
    [14, 1]
  );
  const groundTex = canvasTex(
    128,
    128,
    (g) => {
      g.fillStyle = '#6c9a47';
      g.fillRect(0, 0, 128, 128);
      noiseSpeckle(g, 128, 128, 1500, 0.35);
      noiseSpeckle(g, 128, 128, 500, 0.25, false);
    },
    [30, 20]
  );
  [floorTex, woodTex, asphaltTex, concreteTex, groundTex].forEach((t) => disposables.push(t));

  const floorM = std(0xffffff, 0.55);
  floorM.map = floorTex;
  const woodM = std(0xffffff, 0.6);
  woodM.map = woodTex;
  const darkWood = std(0x3d2412, 0.6);
  const ceilM = std(0xe9e0c4, 0.95);
  const wallMats = (w: number) => {
    const m = std(0xffffff, 0.95);
    m.map = wallTex(w);
    return m;
  };

  // ------------------------------------------------------------------ lights
  scene.add(new THREE.HemisphereLight(0xcfe3ff, 0x8a6a4a, 1.15));
  const sun = new THREE.DirectionalLight(0xfff0d0, 3.2);
  sun.position.set(3.5, 11, 10);
  sun.target.position.set(0, 0, 1);
  sun.castShadow = true;
  sun.shadow.mapSize.set(1024, 1024);
  const sc = sun.shadow.camera;
  sc.left = -9;
  sc.right = 9;
  sc.top = 9;
  sc.bottom = -9;
  sc.near = 1;
  sc.far = 40;
  sun.shadow.bias = -0.0006;
  sun.shadow.normalBias = 0.03;
  scene.add(sun, sun.target);
  const bulb = new THREE.PointLight(0xffd9a0, 9, 9, 1.6);
  bulb.position.set(0.3, 2.6, -1.0);
  group.add(bulb);
  const bulb2 = new THREE.PointLight(0xffe6c0, 5, 7, 1.6);
  bulb2.position.set(-1.2, 2.5, 1.5);
  group.add(bulb2);

  // ------------------------------------------------------------------ sky
  const skyTex = canvasTex(8, 256, (g) => {
    const gr = g.createLinearGradient(0, 0, 0, 256);
    gr.addColorStop(0, '#4f93d8');
    gr.addColorStop(0.55, '#9fcdf0');
    gr.addColorStop(0.8, '#f2e7c9');
    gr.addColorStop(1, '#e8d9b0');
    g.fillStyle = gr;
    g.fillRect(0, 0, 8, 256);
  });
  disposables.push(skyTex);
  const sky = new THREE.Mesh(new THREE.SphereGeometry(180, 16, 12), new THREE.MeshBasicMaterial({ map: skyTex, side: THREE.BackSide, fog: false, depthWrite: false }));
  sky.rotation.y = 0;
  scene.add(sky);
  const cloudTex = canvasTex(128, 64, (g) => {
    const gr = g.createRadialGradient(64, 32, 2, 64, 32, 60);
    gr.addColorStop(0, 'rgba(255,255,255,0.95)');
    gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr;
    g.fillRect(0, 0, 128, 64);
  });
  disposables.push(cloudTex);
  const clouds: THREE.Sprite[] = [];
  for (let i = 0; i < 7; i++) {
    const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: cloudTex, fog: false, depthWrite: false, transparent: true }));
    s.scale.set(rnd(30, 55), rnd(10, 18), 1);
    s.position.set(rnd(-90, 90), rnd(30, 55), rnd(40, 120));
    scene.add(s);
    clouds.push(s);
  }
  updaters.push((dt) => clouds.forEach((c) => {
    c.position.x += dt * 0.6;
    if (c.position.x > 100) c.position.x = -100;
  }));

  // ------------------------------------------------------------------ shop shell
  const interior = new THREE.Group();
  group.add(interior);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(5, 6), floorM);
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  interior.add(floor);
  const ceil = new THREE.Mesh(new THREE.PlaneGeometry(5, 6), ceilM);
  ceil.rotation.x = Math.PI / 2;
  ceil.position.y = 3;
  interior.add(ceil);
  for (let i = -2; i <= 2; i++) addBox(interior, 0.1, 0.12, 6, darkWood, i * 1.0, 2.93, 0, false);
  addBox(interior, 5, 0.12, 0.1, darkWood, 0, 2.93, -1.5, false);
  addBox(interior, 5, 0.12, 0.1, darkWood, 0, 2.93, 1.5, false);

  const T = 0.25;
  addBox(interior, 5.5, 3, T, wallMats(2.2), 0, 1.5, -3 - T / 2); // back
  addBox(interior, T, 3, 6.5, wallMats(2.6), -2.5 - T / 2, 1.5, 0); // left
  addBox(interior, T, 3, 6.5, wallMats(2.6), 2.5 + T / 2, 1.5, 0); // right
  addBox(interior, 1.2 + T, 3, T, wallMats(0.5), -1.9 - T / 2, 1.5, 3 + T / 2); // front-left
  addBox(interior, 1.2 + T, 3, T, wallMats(0.5), 1.9 + T / 2, 1.5, 3 + T / 2); // front-right
  addBox(interior, 2.6, 0.6, T, std(0xd9cf9f, 0.95), 0, 2.7, 3 + T / 2); // lintel
  // door frame
  addBox(interior, 0.12, 2.4, 0.3, darkWood, -1.3, 1.2, 3.12);
  addBox(interior, 0.12, 2.4, 0.3, darkWood, 1.3, 1.2, 3.12);
  addBox(interior, 2.7, 0.12, 0.3, darkWood, 0, 2.42, 3.12);
  // threshold
  addBox(interior, 2.6, 0.04, 0.35, std(0x8a8a82, 0.8), 0, 0.02, 3.12, false);

  // door leaves (open, wobble when someone passes)
  const leaves: THREE.Group[] = [];
  const leafBase: number[] = [];
  [-1, 1].forEach((s) => {
    const hinge = new THREE.Group();
    hinge.position.set(s * 1.3, 0, 2.86);
    const leaf = new THREE.Group();
    addBox(leaf, 1.28, 2.3, 0.05, woodM, -s * 0.65, 1.2, 0);
    for (let i = 0; i < 3; i++) addBox(leaf, 0.35, 0.6, 0.02, darkWood, -s * (0.2 + i * 0.4), 1.2 + (i % 2 ? 0.45 : -0.4), 0.035, false);
    addBox(leaf, 0.04, 0.2, 0.05, std(0xbfbfbf, 0.3, 0.8), -s * 1.1, 1.1, 0.05, false);
    hinge.add(leaf);
    hinge.rotation.y = s > 0 ? Math.PI * 0.97 : -Math.PI * 0.97;
    interior.add(hinge);
    leaves.push(hinge);
    leafBase.push(hinge.rotation.y);
  });
  let wobble = 0;
  updaters.push((dt, t) => {
    wobble = Math.max(0, wobble - dt * 0.8);
    leaves[0].rotation.y = leafBase[0] + Math.sin(t * 10) * wobble * 0.12;
    leaves[1].rotation.y = leafBase[1] - Math.sin(t * 10) * wobble * 0.12;
  });

  // ------------------------------------------------------------------ mirror
  const mirrorW = 2.2;
  const mirrorH = 1.3;
  const mirrorY = 1.62;
  addBox(interior, mirrorW + 0.22, mirrorH + 0.22, 0.05, darkWood, 0.3, mirrorY, -2.97);
  addBox(interior, mirrorW + 0.1, mirrorH + 0.1, 0.02, std(0xc8a24a, 0.4, 0.6), 0.3, mirrorY, -2.945, false);
  const mirrorGeo = new THREE.PlaneGeometry(mirrorW, mirrorH);
  const reflector = new Reflector(mirrorGeo, {
    textureWidth: 640,
    textureHeight: 380,
    color: 0xe0e6ea,
    clipBias: 0.003,
  });
  reflector.position.set(0.3, mirrorY, -2.93);
  interior.add(reflector);
  const mirrorFallback = new THREE.Mesh(mirrorGeo, std(0x9fb2c0, 0.08, 0.9));
  mirrorFallback.position.copy(reflector.position);
  mirrorFallback.visible = false;
  interior.add(mirrorFallback);
  disposables.push(reflector.getRenderTarget());
  // shelf under mirror
  addBox(interior, 2.5, 0.05, 0.38, woodM, 0.3, 0.9, -2.78);
  addBox(interior, 2.4, 0.85, 0.34, darkWood, 0.3, 0.45, -2.78);
  colliders.push({ kind: 'box', a: -1.0, b: 1.6, c: -3.2, d: -2.55 });
  const bottleCols = [0x2e86c1, 0xc0392b, 0x27ae60, 0xf1c40f, 0xe67e22, 0x8e44ad];
  for (let i = 0; i < 9; i++) {
    const c = pick(bottleCols);
    const h = rnd(0.12, 0.22);
    addCyl(interior, 0.032, 0.036, h, std(c, 0.2), -0.7 + i * 0.28 + rnd(-0.03, 0.03), 0.925 + h / 2, -2.8, 10);
    addCyl(interior, 0.012, 0.012, 0.04, std(0xdddddd, 0.3, 0.6), -0.7 + i * 0.28, 0.925 + h + 0.02, -2.8, 8);
  }

  // ------------------------------------------------------------------ chair
  const chair = new THREE.Group();
  chair.position.copy(CHAIR_POS);
  interior.add(chair);
  const chrome = std(0xd8dde2, 0.2, 0.9);
  const leather = std(0x7b2d26, 0.5);
  addCyl(chair, 0.3, 0.32, 0.05, std(0x222222, 0.5, 0.4), 0, 0.025, 0, 20);
  addCyl(chair, 0.07, 0.07, 0.34, chrome, 0, 0.22, 0, 14);
  addCyl(chair, 0.1, 0.1, 0.1, std(0x222222, 0.4, 0.5), 0, 0.5, 0, 14);
  addBox(chair, 0.54, 0.05, 0.52, darkWood, 0, 0.55, 0);
  addBox(chair, 0.5, 0.07, 0.48, leather, 0, 0.585, 0);
  addBox(chair, 0.56, 0.5, 0.07, darkWood, 0, 0.88, 0.24);
  addBox(chair, 0.46, 0.44, 0.07, leather, 0, 0.9, 0.2);
  addBox(chair, 0.3, 0.17, 0.08, leather, 0, 1.12, 0.22);
  addBox(chair, 0.06, 0.2, 0.06, chrome, 0, 1.0, 0.25);
  for (const s of [-1, 1]) {
    addBox(chair, 0.07, 0.05, 0.42, darkWood, s * 0.31, 0.8, -0.02);
    addBox(chair, 0.05, 0.22, 0.05, darkWood, s * 0.31, 0.68, -0.18);
    addBox(chair, 0.05, 0.3, 0.05, darkWood, s * 0.31, 0.68, 0.2);
  }
  const foot = addBox(chair, 0.42, 0.03, 0.26, chrome, 0, 0.3, -0.42);
  foot.rotation.x = 0.35;
  addBox(chair, 0.04, 0.3, 0.04, chrome, 0, 0.42, -0.3);
  colliders.push({ kind: 'circle', a: CHAIR_POS.x, b: CHAIR_POS.z, c: 0.42, d: 0 });

  // ------------------------------------------------------------------ table (right wall)
  const table = new THREE.Group();
  interior.add(table);
  addBox(table, 0.62, 0.05, 1.95, woodM, 2.15, TABLE_TOP - 0.025, -1.7);
  for (const dz of [-0.9, 0.9]) for (const dx of [-0.25, 0.25]) addBox(table, 0.06, 0.82, 0.06, darkWood, 2.15 + dx, 0.41, -1.7 + dz);
  addBox(table, 0.58, 0.04, 1.9, darkWood, 2.15, 0.25, -1.7);
  addBox(table, 0.6, 0.012, 1.9, std(0xb8322a, 0.9), 2.15, TABLE_TOP + 0.006, -1.7, false); // red cloth
  colliders.push({ kind: 'box', a: 1.8, b: 2.5, c: -2.75, d: -0.65 });
  const tableSlots: THREE.Vector3[] = [];
  for (let i = 0; i < 8; i++) tableSlots.push(new THREE.Vector3(TABLE_SLOT_X, TABLE_TOP + 0.012, -2.55 + i * 0.25));
  // wall shelf above table
  addBox(interior, 0.3, 0.04, 1.6, woodM, 2.33, 1.55, -1.7);
  for (let i = 0; i < 7; i++) {
    const c = pick(bottleCols);
    const h = rnd(0.12, 0.2);
    addCyl(interior, 0.03, 0.034, h, std(c, 0.25), 2.33, 1.57 + h / 2, -2.4 + i * 0.22, 10);
  }
  addBox(interior, 0.04, 0.3, 0.22, std(0x2b2b2b, 0.5), 2.4, 1.75, -0.9); // radio
  addBox(interior, 0.02, 0.18, 0.18, std(0xd9b44a, 0.5, 0.5), 2.37, 1.75, -0.9, false);
  // waste bin
  addCyl(interior, 0.14, 0.11, 0.35, std(0x3b6ea5, 0.6), -2.2, 0.175, -2.55, 12);
  colliders.push({ kind: 'circle', a: -2.2, b: -2.55, c: 0.2, d: 0 });

  // bench on left wall
  addBox(interior, 0.4, 0.06, 1.5, woodM, -2.25, 0.45, 1.3);
  for (const dz of [-0.65, 0.65]) addBox(interior, 0.36, 0.45, 0.06, darkWood, -2.25, 0.22, 1.3 + dz);
  addBox(interior, 0.04, 0.4, 1.5, darkWood, -2.46, 0.7, 1.3);
  colliders.push({ kind: 'box', a: -2.5, b: -2.0, c: 0.5, d: 2.1 });
  addBox(interior, 0.3, 0.015, 0.22, std(0xe9e4d4, 0.9), -2.25, 0.485, 1.0, false); // newspaper

  // ------------------------------------------------------------------ wall decor
  const posterIds = [0, 2, 4, 6, 7, 12];
  posterIds.forEach((sid, i) => {
    const cv = renderDrawing(STYLES[sid], { messy: false, seed: 1, poster: true });
    const tx = new THREE.CanvasTexture(cv);
    tx.colorSpace = THREE.SRGBColorSpace;
    disposables.push(tx);
    const pm = new THREE.MeshStandardMaterial({ map: tx, roughness: 0.8 });
    disposables.push(pm);
    const p = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.625), pm);
    const z = -2.2 + (i % 3) * 0.75 + (i >= 3 ? 0.0 : 0);
    p.position.set(-2.485, i < 3 ? 1.95 : 1.25, i < 3 ? z : z + 0.0);
    p.rotation.y = Math.PI / 2;
    p.rotation.z = (Math.random() - 0.5) * 0.08;
    interior.add(p);
    addBox(interior, 0.02, 0.66, 0.54, darkWood, -2.48, p.position.y, p.position.z, false).rotation.z = p.rotation.z;
  });
  // deity frame + calendar on back wall (left side)
  const frameTex = canvasTex(128, 160, (g) => {
    g.fillStyle = '#2a1a5e';
    g.fillRect(0, 0, 128, 160);
    const gr = g.createRadialGradient(64, 70, 5, 64, 70, 60);
    gr.addColorStop(0, '#ffd86b');
    gr.addColorStop(1, '#c0392b');
    g.fillStyle = gr;
    g.beginPath();
    g.arc(64, 70, 48, 0, 7);
    g.fill();
    g.fillStyle = '#2f6fb0';
    g.beginPath();
    g.arc(64, 60, 18, 0, 7);
    g.fill();
    g.fillRect(48, 76, 32, 50);
    g.fillStyle = '#ffd86b';
    g.fillRect(50, 130, 28, 6);
    for (let i = 0; i < 12; i++) {
      g.fillStyle = i % 2 ? '#ff7a2e' : '#ffcf40';
      g.beginPath();
      g.arc(10 + i * 10, 150, 6, 0, 7);
      g.fill();
    }
  });
  disposables.push(frameTex);
  const fr = new THREE.Mesh(new THREE.PlaneGeometry(0.42, 0.52), new THREE.MeshStandardMaterial({ map: frameTex }));
  fr.position.set(-1.7, 2.2, -2.97);
  interior.add(fr);
  addBox(interior, 0.48, 0.58, 0.03, std(0x8b5a2b, 0.4, 0.3), -1.7, 2.2, -2.98, false);
  const calTex = canvasTex(96, 128, (g) => {
    g.fillStyle = '#f4efe0';
    g.fillRect(0, 0, 96, 128);
    g.fillStyle = '#d63a3a';
    g.fillRect(0, 0, 96, 34);
    g.fillStyle = '#fff';
    g.font = 'bold 18px Arial';
    g.fillText('KERALA', 12, 24);
    g.fillStyle = '#333';
    for (let r = 0; r < 5; r++) for (let c = 0; c < 6; c++) g.fillRect(8 + c * 14, 44 + r * 15, 8, 6);
  });
  disposables.push(calTex);
  const cal = new THREE.Mesh(new THREE.PlaneGeometry(0.3, 0.4), new THREE.MeshStandardMaterial({ map: calTex }));
  cal.position.set(2.0, 2.1, -2.97);
  interior.add(cal);
  // wall clock
  const clockTex = canvasTex(128, 128, (g) => {
    g.fillStyle = '#fff';
    g.beginPath();
    g.arc(64, 64, 60, 0, 7);
    g.fill();
    g.strokeStyle = '#222';
    g.lineWidth = 6;
    g.stroke();
    g.lineWidth = 3;
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * 6.283;
      g.beginPath();
      g.moveTo(64 + Math.sin(a) * 50, 64 - Math.cos(a) * 50);
      g.lineTo(64 + Math.sin(a) * 57, 64 - Math.cos(a) * 57);
      g.stroke();
    }
    g.lineWidth = 5;
    g.beginPath();
    g.moveTo(64, 64);
    g.lineTo(64, 28);
    g.moveTo(64, 64);
    g.lineTo(88, 74);
    g.stroke();
  });
  disposables.push(clockTex);
  const clock = new THREE.Mesh(new THREE.CircleGeometry(0.15, 24), new THREE.MeshStandardMaterial({ map: clockTex }));
  clock.position.set(-0.7, 2.55, -2.97);
  interior.add(clock);
  // tube light
  const tube = addBox(interior, 0.9, 0.06, 0.08, new THREE.MeshBasicMaterial({ color: 0xfffbe8 }), 1.0, 2.72, -2.9, false);
  void tube;
  // window decal on the left wall
  const winTex = canvasTex(128, 160, (g) => {
    const gr = g.createLinearGradient(0, 0, 0, 160);
    gr.addColorStop(0, '#9bd0f5');
    gr.addColorStop(1, '#e8f3da');
    g.fillStyle = gr;
    g.fillRect(0, 0, 128, 160);
    g.fillStyle = '#4a7a3a';
    g.beginPath();
    g.arc(30, 150, 50, 0, 7);
    g.arc(100, 160, 55, 0, 7);
    g.fill();
    g.strokeStyle = '#2b2b2b';
    g.lineWidth = 4;
    for (let i = 1; i < 6; i++) {
      g.beginPath();
      g.moveTo(i * 21, 0);
      g.lineTo(i * 21, 160);
      g.stroke();
    }
  });
  disposables.push(winTex);
  const win = new THREE.Mesh(new THREE.PlaneGeometry(0.8, 1.0), new THREE.MeshBasicMaterial({ map: winTex }));
  win.position.set(-2.495, 1.7, 0.0);
  win.rotation.y = Math.PI / 2;
  interior.add(win);
  addBox(interior, 0.04, 1.1, 0.9, darkWood, -2.49, 1.7, 0, false).scale.set(0.5, 1, 1);

  // ceiling fan
  const fan = new THREE.Group();
  fan.position.set(0.3, 2.78, -0.3);
  interior.add(fan);
  addCyl(interior, 0.012, 0.012, 0.22, std(0x555555, 0.5, 0.5), 0.3, 2.89, -0.3, 8, false);
  const hub = addCyl(fan, 0.09, 0.09, 0.07, std(0x222222, 0.5, 0.5), 0, 0, 0, 14, true);
  void hub;
  const bladeM = std(0x5a3a22, 0.6);
  for (let i = 0; i < 3; i++) {
    const arm = new THREE.Group();
    arm.rotation.y = (i / 3) * Math.PI * 2;
    const b = addBox(arm, 0.55, 0.012, 0.14, bladeM, 0.4, 0, 0);
    b.rotation.x = 0.1;
    fan.add(arm);
  }
  updaters.push((dt) => {
    fan.rotation.y += dt * 11;
  });

  // ------------------------------------------------------------------ outside: porch, road, buildings
  const outside = new THREE.Group();
  group.add(outside);
  const porchM = lam(0xffffff);
  porchM.map = concreteTex;
  const porch = new THREE.Mesh(new THREE.PlaneGeometry(40, 1.5), porchM);
  porch.rotation.x = -Math.PI / 2;
  porch.position.set(0, 0.005, 3.3 + 0.75);
  porch.receiveShadow = true;
  outside.add(porch);
  const dirt = new THREE.Mesh(new THREE.PlaneGeometry(40, 0.6), lam(0xb59a6a));
  dirt.rotation.x = -Math.PI / 2;
  dirt.position.set(0, 0.002, 5.1);
  dirt.receiveShadow = true;
  outside.add(dirt);
  const roadM = lam(0xffffff);
  roadM.map = asphaltTex;
  const road = new THREE.Mesh(new THREE.PlaneGeometry(120, 4.2), roadM);
  road.rotation.x = -Math.PI / 2;
  road.position.set(0, 0.001, 7.5);
  road.receiveShadow = true;
  outside.add(road);
  // dashed centre line
  const dashM = new THREE.MeshBasicMaterial({ color: 0xeeeeee });
  for (let i = -20; i <= 20; i++) {
    const d = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 0.1), dashM);
    d.rotation.x = -Math.PI / 2;
    d.position.set(i * 2.2, 0.004, 7.5);
    outside.add(d);
  }
  const far = new THREE.Mesh(new THREE.PlaneGeometry(40, 1.2), lam(0xb59a6a));
  far.rotation.x = -Math.PI / 2;
  far.position.set(0, 0.002, 9.9);
  outside.add(far);
  const groundM = lam(0xffffff);
  groundM.map = groundTex;
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(240, 240), groundM);
  ground.rotation.x = -Math.PI / 2;
  ground.position.set(0, -0.02, 20);
  ground.receiveShadow = true;
  outside.add(ground);
  scene.fog = new THREE.Fog(0xe6dcc0, 40, 140);

  // our shop's outer front: signboard, pole, posts, roof
  const signTex = signTexture('SREE MURUGAN HAIR CUTTING SALOON', 'ശ്രീ മുരുകൻ ഹെയർ കട്ടിംഗ് സലൂൺ', '#fbe9a8', '#b3261e', 600, 120);
  disposables.push(signTex);
  const signM = new THREE.MeshStandardMaterial({ map: signTex, roughness: 0.7 });
  disposables.push(signM);
  const sign = new THREE.Mesh(new THREE.BoxGeometry(2.55, 0.46, 0.06), [darkWood, darkWood, darkWood, darkWood, signM, darkWood]);
  sign.position.set(0, 2.68, 3.32);
  outside.add(sign);
  const poleTex = canvasTex(64, 128, (g) => {
    for (let i = -2; i < 10; i++) {
      g.fillStyle = ['#c0392b', '#f4f4f4', '#2b5fb0'][((i % 3) + 3) % 3];
      g.beginPath();
      g.moveTo(0, i * 20);
      g.lineTo(64, i * 20 - 30);
      g.lineTo(64, i * 20 - 10);
      g.lineTo(0, i * 20 + 20);
      g.fill();
    }
  });
  poleTex.wrapS = poleTex.wrapT = THREE.RepeatWrapping;
  disposables.push(poleTex);
  const pole = addCyl(outside, 0.09, 0.09, 0.6, new THREE.MeshStandardMaterial({ map: poleTex, roughness: 0.4 }), -1.75, 1.5, 3.55, 16);
  addCyl(outside, 0.1, 0.1, 0.05, std(0xcccccc, 0.2, 0.9), -1.75, 1.83, 3.55, 16);
  addCyl(outside, 0.1, 0.1, 0.05, std(0xcccccc, 0.2, 0.9), -1.75, 1.17, 3.55, 16);
  updaters.push((dt) => {
    poleTex.offset.y -= dt * 0.35;
  });
  void pole;
  // posts and eave roof
  for (const s of [-1, 1]) addCyl(outside, 0.07, 0.07, 2.9, darkWood, s * 2.65, 1.45, 4.7, 8);
  const tileTex = canvasTex(
    128,
    128,
    (g) => {
      g.fillStyle = '#b4482a';
      g.fillRect(0, 0, 128, 128);
      for (let y = 0; y < 128; y += 16) {
        g.fillStyle = y % 32 ? '#a63d22' : '#c25533';
        g.fillRect(0, y, 128, 8);
        g.strokeStyle = 'rgba(0,0,0,0.35)';
        for (let x = 0; x < 128; x += 16) {
          g.beginPath();
          g.moveTo(x + (y % 32 ? 8 : 0), y);
          g.lineTo(x + (y % 32 ? 8 : 0), y + 16);
          g.stroke();
        }
      }
      noiseSpeckle(g, 128, 128, 600, 0.3);
    },
    [6, 2]
  );
  disposables.push(tileTex);
  const roofM = new THREE.MeshLambertMaterial({ map: tileTex, side: THREE.DoubleSide });
  disposables.push(roofM);
  const eave = new THREE.Mesh(new THREE.PlaneGeometry(6, 2.2), roofM);
  eave.rotation.x = -Math.PI / 2 + 0.38;
  eave.position.set(0, 3.45, 3.9);
  outside.add(eave);
  const mainRoof = new THREE.Mesh(new THREE.PlaneGeometry(6, 4.4), roofM);
  mainRoof.rotation.x = -Math.PI / 2 + 0.55;
  mainRoof.position.set(0, 3.95, 0.5);
  outside.add(mainRoof);

  // neighbouring closed shops on our side
  const neighbours = [
    { x: -5.5, c: 0x7fb7a4, name: 'NEW STAR TAILORS', fg: '#ffffff', bg: '#1f6a8a' },
    { x: 5.5, c: 0xe9b36a, name: 'KALLU & CO. HARDWARE', fg: '#222222', bg: '#f1c40f' },
  ];
  neighbours.forEach((n) => {
    addBox(outside, 5.5, 3.2, 6.5, lam(n.c), n.x, 1.6, 0, false);
    addBox(outside, 5.5, 0.12, 0.8, lam(0x8a8a82), n.x, 0.06, 3.5, false);
    addBox(outside, 4.2, 2.3, 0.06, lam(0x7d8186), n.x, 1.2, 3.3, false);
    for (let i = 0; i < 12; i++) addBox(outside, 4.2, 0.012, 0.07, lam(0x666a6e), n.x, 0.15 + i * 0.19, 3.31, false);
    const st = signTexture(n.name, '', n.bg, n.fg, 512, 100);
    disposables.push(st);
    const sm = new THREE.MeshBasicMaterial({ map: st });
    disposables.push(sm);
    const s = new THREE.Mesh(new THREE.PlaneGeometry(3.6, 0.7), sm);
    s.position.set(n.x, 2.7, 3.35);
    outside.add(s);
    const r = new THREE.Mesh(new THREE.PlaneGeometry(6, 3.4), roofM);
    r.rotation.x = -Math.PI / 2 + 0.5;
    r.position.set(n.x, 3.8, 1.7);
    outside.add(r);
  });

  // ---- opposite shops
  const person = (shirt: number, lower: number, skinC: number, seated = false) => {
    const g = new THREE.Group();
    const sk = lam(skinC);
    const top = lam(shirt);
    const bot = lam(lower);
    const legH = seated ? 0.45 : 0.85;
    const legs = new THREE.Mesh(new THREE.CylinderGeometry(0.17, 0.2, legH, 10), bot);
    legs.position.y = legH / 2;
    const torso = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.19, 0.6, 10), top);
    torso.position.y = legH + 0.3;
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.13, 12, 10), sk);
    head.position.y = legH + 0.75;
    const hair = new THREE.Mesh(new THREE.SphereGeometry(0.135, 12, 6, 0, Math.PI * 2, 0, Math.PI * 0.45), lam(0x111111));
    hair.position.y = legH + 0.77;
    g.add(legs, torso, head, hair);
    const armG = new THREE.CylinderGeometry(0.05, 0.05, 0.5, 6);
    const a1 = new THREE.Mesh(armG, top);
    a1.position.set(0.25, legH + 0.32, 0);
    const a2 = a1.clone();
    a2.position.x = -0.25;
    g.add(a1, a2);
    return { g, legs, torso };
  };

  const goodsCols = [0xe74c3c, 0xf1c40f, 0x27ae60, 0x3498db, 0xe67e22, 0x9b59b6, 0xecf0f1];
  const shops = [
    { x: -9.5, c: 0xd9786c, name: 'SREE KRISHNA STORES', sub: 'ശ്രീ കൃഷ്ണ സ്റ്റോഴ്സ്', bg: '#f4d03f', fg: '#7b241c', kind: 'stores' },
    { x: -5, c: 0x8fa7d6, name: 'FATHIMA TEXTILES', sub: 'ഫാത്തിമ ടെക്സ്റ്റൈൽസ്', bg: '#c0392b', fg: '#ffffff', kind: 'cloth' },
    { x: -0.5, c: 0xe8d9a0, name: 'CHAYAKKADA', sub: 'ചായക്കട', bg: '#1e8449', fg: '#fff7c2', kind: 'tea' },
    { x: 4, c: 0x7fb7a4, name: 'JOY BAKERY & SWEETS', sub: 'ജോയ് ബേക്കറി', bg: '#f5b7b1', fg: '#6e2c00', kind: 'bakery' },
    { x: 8.5, c: 0xe9b36a, name: 'NEW MEDICALS', sub: 'ന്യൂ മെഡിക്കൽസ്', bg: '#ffffff', fg: '#1e8449', kind: 'med' },
    { x: 13, c: 0xcfa0d9, name: 'AMMA FRUITS', sub: 'അമ്മ ഫ്രൂട്ട്സ്', bg: '#27ae60', fg: '#ffffff', kind: 'fruit' },
    { x: -14, c: 0xe7a77d, name: 'KERALA TRADERS', sub: 'കേരള ട്രേഡേഴ്സ്', bg: '#2e4053', fg: '#f9e79f', kind: 'stores' },
  ];
  const awnTexCache: Record<string, THREE.CanvasTexture> = {};
  shops.forEach((s, idx) => {
    const g = new THREE.Group();
    g.position.set(s.x, 0, 10.6);
    outside.add(g);
    const w = 4.2;
    addBox(g, w, 3.4, 3.2, lam(s.c), 0, 1.7, 1.6, false);
    addBox(g, w * 0.8, 2.2, 0.05, lam(0x2a1d14), 0, 1.15, -0.03, false);
    // display counter
    addBox(g, w * 0.78, 0.8, 0.5, lam(0x6b4a2a), 0, 0.4, -0.55, false);
    addBox(g, w * 0.78, 0.05, 0.6, lam(0x8a6a3a), 0, 0.82, -0.55, false);
    // goods
    for (let i = 0; i < 14; i++) {
      const gc = pick(goodsCols);
      if (s.kind === 'fruit' || s.kind === 'tea' || s.kind === 'bakery') {
        const sp = new THREE.Mesh(new THREE.SphereGeometry(rnd(0.07, 0.12), 8, 6), lam(s.kind === 'fruit' ? pick([0xe74c3c, 0xf1c40f, 0x27ae60, 0xe67e22]) : gc));
        sp.position.set(-1.4 + i * 0.21, 0.95, -0.55 + rnd(-0.1, 0.1));
        g.add(sp);
      } else {
        addBox(g, rnd(0.15, 0.3), rnd(0.15, 0.35), 0.15, lam(gc), -1.4 + i * 0.21, 0.95 + rnd(0, 0.1), -0.55, false);
      }
    }
    // shelves with goods at back
    for (let r = 0; r < 3; r++) {
      addBox(g, w * 0.76, 0.03, 0.3, lam(0x7a5a3a), 0, 1.1 + r * 0.45, -0.2, false);
      for (let i = 0; i < 9; i++) addBox(g, 0.18, 0.22, 0.16, lam(pick(goodsCols)), -1.5 + i * 0.37, 1.24 + r * 0.45, -0.2, false);
    }
    if (s.kind === 'tea') {
      for (let i = 0; i < 3; i++) {
        const b = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.45, 6), lam(0xf4d03f));
        b.rotation.x = Math.PI;
        b.position.set(-0.8 + i * 0.8, 2.0, -0.45);
        g.add(b);
        addCyl(g, 0.004, 0.004, 0.3, lam(0x333333), -0.8 + i * 0.8, 2.4, -0.45, 4, false);
      }
      addCyl(g, 0.22, 0.25, 0.4, std(0xc0c0c0, 0.3, 0.8), 1.4, 1.05, -0.55, 12, false);
    }
    if (s.kind === 'cloth') {
      for (let i = 0; i < 6; i++) {
        const cl = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 1.2), new THREE.MeshLambertMaterial({ color: pick([0xe74c3c, 0xf1c40f, 0x27ae60, 0x3498db, 0xe84393, 0xffffff]), side: THREE.DoubleSide }));
        cl.position.set(-1.6 + i * 0.64, 1.6, -0.2);
        g.add(cl);
        disposables.push(cl.material as THREE.Material);
      }
    }
    if (s.kind === 'med') {
      addBox(g, 0.5, 0.15, 0.04, lam(0x1e8449), 0, 2.3, -0.1, false);
      addBox(g, 0.15, 0.5, 0.04, lam(0x1e8449), 0, 2.3, -0.1, false);
    }
    // sign
    const st = signTexture(s.name, s.sub, s.bg, s.fg, 512, 112);
    disposables.push(st);
    const sm = new THREE.MeshBasicMaterial({ map: st });
    disposables.push(sm);
    const sg = new THREE.Mesh(new THREE.PlaneGeometry(w * 0.9, 0.62), sm);
    sg.position.set(0, 2.95, -0.06);
    sg.rotation.y = Math.PI;
    g.add(sg);
    // awning
    const key = idx % 3 + '';
    if (!awnTexCache[key]) {
      const cols = [['#c0392b', '#f4f4f4'], ['#1f6a8a', '#f4f4f4'], ['#e67e22', '#f9e79f']][idx % 3];
      awnTexCache[key] = canvasTex(
        64,
        32,
        (c) => {
          for (let i = 0; i < 8; i++) {
            c.fillStyle = cols[i % 2];
            c.fillRect(i * 8, 0, 8, 32);
          }
        },
        [4, 1]
      );
      disposables.push(awnTexCache[key]);
    }
    const aw = new THREE.Mesh(new THREE.PlaneGeometry(w * 0.92, 1.0), new THREE.MeshLambertMaterial({ map: awnTexCache[key], side: THREE.DoubleSide }));
    aw.position.set(0, 2.55, -0.45);
    aw.rotation.x = Math.PI / 2 - 0.45 - Math.PI;
    aw.rotation.x = -(Math.PI / 2) - 0.5 + Math.PI;
    g.add(aw);
    disposables.push(aw.material as THREE.Material);
    // roof
    const rf = new THREE.Mesh(new THREE.PlaneGeometry(w + 0.6, 3.9), roofM);
    rf.rotation.x = -Math.PI / 2 - 0.45;
    rf.position.set(0, 3.9, 1.6);
    g.add(rf);
    // shopkeeper
    if (idx % 2 === 0) {
      const p = person(pick([0xffffff, 0xeaeaea, 0x2e86c1, 0xf5cba7]), 0xf2f2f2, pick([0x8d5a3b, 0xa56b46, 0x7a4a30]), true);
      p.g.position.set(rnd(-1.2, 1.2), 0.0, -0.33);
      p.g.rotation.y = Math.PI;
      p.g.scale.setScalar(0.95);
      g.add(p.g);
    }
  });
  // porch edge along far sidewalk
  const farPorch = new THREE.Mesh(new THREE.PlaneGeometry(40, 0.9), lam(0xa8a396));
  farPorch.rotation.x = -Math.PI / 2;
  farPorch.position.set(0, 0.006, 10.2);
  outside.add(farPorch);

  // palm trees
  const trunkM = lam(0x8a6a45);
  const frondM = new THREE.MeshLambertMaterial({ color: 0x2f8a3a, side: THREE.DoubleSide });
  disposables.push(frondM);
  const palm = (x: number, z: number, h: number) => {
    const g = new THREE.Group();
    g.position.set(x, 0, z);
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.26, h, 8), trunkM);
    trunk.position.y = h / 2;
    trunk.rotation.z = rnd(-0.08, 0.08);
    g.add(trunk);
    const top = new THREE.Group();
    top.position.set(trunk.rotation.z * -h * 0.5, h, 0);
    for (let i = 0; i < 9; i++) {
      const f = new THREE.Mesh(new THREE.PlaneGeometry(0.7, 3.4, 1, 1), frondM);
      f.geometry.translate(0, 1.7, 0);
      const arm = new THREE.Group();
      arm.rotation.y = (i / 9) * Math.PI * 2;
      f.rotation.x = -1.2 - rnd(0, 0.3);
      f.rotation.y = 0;
      f.rotation.order = 'XYZ';
      arm.add(f);
      f.rotation.z = 0;
      // plane faces +z by default, rotate so frond leans outward
      f.rotation.x = -(Math.PI / 2) + 0.7 + rnd(-0.2, 0.2);
      top.add(arm);
    }
    for (let i = 0; i < 3; i++) {
      const c = new THREE.Mesh(new THREE.SphereGeometry(0.14, 8, 6), lam(0x5a8a2a));
      c.position.set(rnd(-0.2, 0.2), -0.2, rnd(-0.2, 0.2));
      top.add(c);
    }
    g.add(top);
    outside.add(g);
  };
  [[-12, 15.5, 9], [-7, 15, 11], [-2, 16, 10], [3.5, 15.2, 12], [9, 15.8, 9.5], [14, 15, 11], [-16, 14, 10], [-8, 4.5, 8], [10, 3.8, 9], [18, 14, 10]].forEach(([x, z, h]) => palm(x, z, h));
  // far houses / hills
  for (let i = 0; i < 10; i++) {
    const hill = new THREE.Mesh(new THREE.SphereGeometry(rnd(14, 26), 12, 8), lam(pick([0x4f8a4a, 0x5a9a50, 0x467a45])));
    hill.scale.y = 0.35;
    hill.position.set(-70 + i * 16, -2, rnd(55, 75));
    outside.add(hill);
  }

  // electric poles + wires
  const poleM = lam(0x7a7266);
  const wirePts: THREE.Vector3[][] = [[], [], []];
  const poleXs = [-14, -4, 6, 16];
  poleXs.forEach((x) => {
    addCyl(outside, 0.08, 0.12, 6.5, poleM, x, 3.25, 5.0, 8);
    addBox(outside, 0.08, 0.08, 1.2, poleM, x, 6.0, 5.0, false);
  });
  for (let w = 0; w < 3; w++) {
    for (let k = 0; k < poleXs.length - 1; k++) {
      for (let i = 0; i <= 12; i++) {
        const f = i / 12;
        const x = poleXs[k] + (poleXs[k + 1] - poleXs[k]) * f;
        wirePts[w].push(new THREE.Vector3(x, 6.0 - Math.sin(f * Math.PI) * 0.35, 5.0 + (w - 1) * 0.5));
      }
    }
    const geo = new THREE.BufferGeometry().setFromPoints(wirePts[w]);
    const line = new THREE.Line(geo, new THREE.LineBasicMaterial({ color: 0x1a1a1a }));
    outside.add(line);
    disposables.push(geo);
  }

  // ------------------------------------------------------------------ traffic
  interface Mover {
    g: THREE.Group;
    vx: number;
    bob: number;
    legs?: THREE.Object3D;
    kind: string;
    wheels?: THREE.Object3D[];
  }
  const movers: Mover[] = [];
  const tireM = lam(0x1a1a1a);
  const wheel = (r: number, w: number) => {
    const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, w, 12), tireM);
    m.rotation.z = Math.PI / 2;
    return m;
  };
  const buildScooter = () => {
    const g = new THREE.Group();
    const col = pick([0xc0392b, 0x2980b9, 0xf1c40f, 0x27ae60, 0xecf0f1]);
    const w1 = wheel(0.22, 0.07);
    w1.position.set(0, 0.22, 0.6);
    const w2 = wheel(0.22, 0.07);
    w2.position.set(0, 0.22, -0.6);
    g.add(w1, w2);
    addBox(g, 0.3, 0.3, 0.9, lam(col), 0, 0.45, -0.1, false);
    addBox(g, 0.25, 0.08, 0.5, lam(0x222222), 0, 0.68, -0.25, false);
    addBox(g, 0.5, 0.05, 0.05, lam(0x222222), 0, 0.95, 0.5, false);
    addBox(g, 0.05, 0.5, 0.05, lam(0x444444), 0, 0.65, 0.52, false);
    const p = person(pick([0xe74c3c, 0x3498db, 0xffffff, 0x2ecc71]), pick([0x2c3e50, 0x555555]), pick([0x8d5a3b, 0xa56b46]), true);
    p.g.position.set(0, 0.35, -0.25);
    g.add(p.g);
    g.rotation.y = Math.PI / 2; // face +x
    return { g, wheels: [w1, w2] };
  };
  const buildBicycle = () => {
    const g = new THREE.Group();
    const rim = new THREE.TorusGeometry(0.33, 0.02, 6, 16);
    const rm = lam(0x222222);
    const w1 = new THREE.Mesh(rim, rm);
    w1.position.set(0, 0.35, 0.55);
    w1.rotation.y = Math.PI / 2;
    const w2 = w1.clone();
    w2.position.z = -0.55;
    g.add(w1, w2);
    const fm = lam(pick([0x222222, 0x1f6a8a, 0xc0392b]));
    const bar = addBox(g, 0.03, 0.03, 1.1, fm, 0, 0.62, 0, false);
    void bar;
    addBox(g, 0.03, 0.5, 0.03, fm, 0, 0.6, 0.5, false);
    addBox(g, 0.4, 0.03, 0.03, fm, 0, 0.9, 0.5, false);
    const p = person(pick([0xffffff, 0xf5cba7, 0x5dade2]), pick([0xffffff, 0x2c3e50]), pick([0x8d5a3b, 0x7a4a30]), true);
    p.g.position.set(0, 0.35, -0.2);
    p.g.scale.setScalar(0.95);
    g.add(p.g);
    g.rotation.y = Math.PI / 2;
    return { g, wheels: [w1, w2] };
  };
  const buildAuto = () => {
    const g = new THREE.Group();
    const w1 = wheel(0.2, 0.08);
    w1.position.set(0, 0.2, 0.9);
    const w2 = wheel(0.2, 0.08);
    w2.position.set(-0.6, 0.2, -0.5);
    const w3 = wheel(0.2, 0.08);
    w3.position.set(0.6, 0.2, -0.5);
    g.add(w1, w2, w3);
    addBox(g, 1.3, 0.65, 1.7, lam(0x222222), 0, 0.6, -0.3, false);
    addBox(g, 1.3, 0.07, 2.0, lam(0xf1c40f), 0, 1.5, -0.2, false);
    addBox(g, 0.05, 0.9, 0.05, lam(0x222222), -0.6, 1.1, 0.5, false);
    addBox(g, 0.05, 0.9, 0.05, lam(0x222222), 0.6, 1.1, 0.5, false);
    addBox(g, 0.05, 0.9, 0.05, lam(0x222222), -0.6, 1.1, -1.0, false);
    addBox(g, 0.05, 0.9, 0.05, lam(0x222222), 0.6, 1.1, -1.0, false);
    addBox(g, 1.2, 0.6, 0.06, new THREE.MeshLambertMaterial({ color: 0x9fd3f0, transparent: true, opacity: 0.6 }), 0, 1.2, 0.55, false);
    addBox(g, 1.2, 0.3, 1.0, lam(0xf1c40f), 0, 0.85, 0.45, false).scale.set(1, 1, 0.5);
    const p = person(0xf1c40f, 0x2c3e50, 0x8d5a3b, true);
    p.g.position.set(0, 0.35, 0.25);
    g.add(p.g);
    g.rotation.y = Math.PI / 2;
    return { g, wheels: [w1, w2, w3] };
  };
  const spawnMover = () => {
    if (movers.length >= 9) return;
    const r = Math.random();
    const dirRight = Math.random() < 0.5;
    let kind = 'ped';
    if (r < 0.28) kind = 'scooter';
    else if (r < 0.42) kind = 'bicycle';
    else if (r < 0.52) kind = 'auto';
    const m: Mover = { g: new THREE.Group(), vx: 0, bob: Math.random() * 6, kind };
    if (kind === 'ped') {
      const male = Math.random() < 0.7;
      const p = person(
        pick([0xffffff, 0xf5f5dc, 0x3498db, 0xe74c3c, 0x16a085, 0xf1c40f, 0xe84393]),
        male ? pick([0xffffff, 0xf2f2f2, 0x2c3e50, 0xdcd6c0]) : pick([0x8e44ad, 0xe67e22, 0x2e86c1]),
        pick([0x8d5a3b, 0xa56b46, 0x7a4a30, 0xb87b51])
      );
      m.g = p.g;
      m.legs = p.legs;
      m.vx = rnd(0.8, 1.4);
      const lane = pick([5.15, 9.8, 9.9, 5.05, 9.7]);
      m.g.position.set(0, 0, lane);
    } else {
      const b = kind === 'scooter' ? buildScooter() : kind === 'bicycle' ? buildBicycle() : buildAuto();
      m.g = b.g;
      m.wheels = b.wheels;
      m.vx = kind === 'scooter' ? rnd(4.5, 7) : kind === 'bicycle' ? rnd(2, 3) : rnd(3.5, 5);
      m.g.position.set(0, 0, dirRight ? 6.5 : 8.5);
    }
    if (!dirRight) {
      m.vx = -m.vx;
      if (kind !== 'ped') m.g.rotation.y = -Math.PI / 2;
    }
    if (kind === 'ped' && m.vx < 0) m.g.rotation.y = 0;
    m.g.position.x = dirRight ? -26 : 26;
    group.add(m.g);
    movers.push(m);
  };
  for (let i = 0; i < 4; i++) {
    spawnMover();
    const m = movers[movers.length - 1];
    m.g.position.x = rnd(-14, 14);
  }
  let spawnT = 1;
  updaters.push((dt, t) => {
    spawnT -= dt;
    if (spawnT < 0) {
      spawnMover();
      spawnT = rnd(2, 5);
    }
    for (let i = movers.length - 1; i >= 0; i--) {
      const m = movers[i];
      m.g.position.x += m.vx * dt;
      if (m.kind === 'ped') {
        m.g.position.y = Math.abs(Math.sin(t * 6 + m.bob)) * 0.03;
        if (m.legs) m.legs.rotation.z = Math.sin(t * 6 + m.bob) * 0.06;
      } else {
        m.wheels?.forEach((w) => (w.rotation.x += dt * m.vx * 2));
      }
      if (Math.abs(m.g.position.x) > 28) {
        group.remove(m.g);
        m.g.traverse((o) => {
          if ((o as THREE.Mesh).isMesh) (o as THREE.Mesh).geometry.dispose();
        });
        movers.splice(i, 1);
      }
    }
  });

  // ------------------------------------------------------------------ collision
  const collide = (p: THREE.Vector3, radius: number) => {
    // bounds: inside shop, doorway, porch
    const inPorchZone = p.z > 2.7;
    if (inPorchZone) {
      p.z = Math.min(p.z, 4.4);
      if (p.z > 3.35) p.x = Math.max(-2.2, Math.min(2.2, p.x));
      else p.x = Math.max(-1.25 + radius, Math.min(1.25 - radius, p.x)); // doorway
    } else {
      p.x = Math.max(-2.5 + radius, Math.min(2.5 - radius, p.x));
      p.z = Math.max(-3 + radius, p.z);
    }
    if (p.z <= 2.7 && p.z > 2.45) p.x = Math.max(-2.5 + radius, Math.min(2.5 - radius, p.x));
    for (const c of colliders) {
      if (c.kind === 'box') {
        const cx = Math.max(c.a, Math.min(p.x, c.b));
        const cz = Math.max(c.c, Math.min(p.z, c.d));
        const dx = p.x - cx;
        const dz = p.z - cz;
        const d2 = dx * dx + dz * dz;
        if (d2 < radius * radius) {
          if (d2 > 1e-8) {
            const d = Math.sqrt(d2);
            p.x = cx + (dx / d) * radius;
            p.z = cz + (dz / d) * radius;
          } else {
            p.x = c.a - radius;
          }
        }
      } else {
        const dx = p.x - c.a;
        const dz = p.z - c.b;
        const d = Math.hypot(dx, dz);
        const r = c.c + radius;
        if (d < r && d > 1e-6) {
          p.x = c.a + (dx / d) * r;
          p.z = c.b + (dz / d) * r;
        }
      }
    }
  };

  // ------------------------------------------------------------------ misc setup
  group.traverse((o) => {
    if ((o as THREE.Mesh).isMesh) {
      const mm = o as THREE.Mesh;
      if (mm.geometry && mm !== reflector) disposables.push(mm.geometry);
    }
  });
  void renderer;

  return {
    group,
    update: (dt, t) => updaters.forEach((u) => u(dt, t)),
    tableSlots,
    collide,
    setMirror: (on) => {
      reflector.visible = on;
      mirrorFallback.visible = !on;
    },
    doorKick: () => {
      wobble = 1;
    },
    sun,
    dispose: () => {
      disposables.forEach((d) => {
        try {
          d.dispose();
        } catch {
          /* ignore */
        }
      });
      scene.remove(group, sun, sun.target, sky);
      clouds.forEach((c) => scene.remove(c));
    },
  };
}
