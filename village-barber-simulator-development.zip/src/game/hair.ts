import * as THREE from 'three';
import { Region, REGIONS, HairStyle, targetLength, clamp, sstep } from './hairstyles';

export const HEAD_R = 0.12;
export const HAIR_MAX = 0.075;
const BASE_R = 0.116;
export const SURF = 0.13; // virtual surface radius used for tool contact

export type CutTool = 'clipper' | 'scissors' | 'razor' | 'comb' | 'spray';

export interface Evaluation {
  score: number;
  lenScore: number;
  symScore: number;
  topScore: number;
  backScore: number;
  resScore: number;
  worst: Region;
  worstDir: 'long' | 'short';
  patchy: number;
  avg: Record<Region, number>;
  tgt: Record<Region, number>;
}

const regionIndex = (r: Region) => REGIONS.indexOf(r);

export class HairSystem {
  mesh: THREE.InstancedMesh;
  n = 0;
  dir: Float32Array;
  region: Uint8Array;
  h: Float32Array;
  len: Float32Array;
  tiltX: Float32Array;
  tiltZ: Float32Array;
  wet: Float32Array;
  jit: Float32Array;
  vary: Float32Array;
  hairColor: THREE.Color;
  skinColor: THREE.Color;
  curly: boolean;
  dirty = true;
  anyWet = false;
  private tmpM = new THREE.Matrix4();
  private tmpQ = new THREE.Quaternion();
  private tmpV = new THREE.Vector3();
  private tmpP = new THREE.Vector3();
  private tmpS = new THREE.Vector3();
  private tmpC = new THREE.Color();
  private up = new THREE.Vector3(0, 1, 0);

  constructor(hair: string, skin: string, curly: boolean, startTop: number, startSide: number) {
    this.hairColor = new THREE.Color(hair);
    this.skinColor = new THREE.Color(skin);
    this.curly = curly;
    // sample sphere points (fibonacci)
    const M = 2100;
    const pts: number[] = [];
    const regs: number[] = [];
    const hs: number[] = [];
    const ga = Math.PI * (3 - Math.sqrt(5));
    for (let i = 0; i < M; i++) {
      const y = 1 - (2 * (i + 0.5)) / M;
      const rr = Math.sqrt(1 - y * y);
      const th = ga * i;
      const v = new THREE.Vector3(Math.cos(th) * rr, y, Math.sin(th) * rr);
      // jitter
      v.x += (Math.random() - 0.5) * 0.05;
      v.y += (Math.random() - 0.5) * 0.05;
      v.z += (Math.random() - 0.5) * 0.05;
      v.normalize();
      const ok =
        v.y >= 0.5 ||
        (v.z < 0.5 && v.y > -0.55 && !(Math.abs(v.x) > 0.8 && v.y < 0.3 && v.y > -0.3));
      if (!ok) continue;
      let reg: Region;
      if (v.y > 0.78 && v.z < 0.5) reg = 'top';
      else if (v.z > 0.35 && v.y > 0.45) reg = 'front';
      else if (v.y < 0 && v.z < -0.2 && Math.abs(v.x) < 0.8) reg = 'neck';
      else if (v.z < -0.45) reg = 'back';
      else reg = v.x > 0 ? 'left' : 'right';
      pts.push(v.x, v.y, v.z);
      regs.push(regionIndex(reg));
      hs.push(clamp((v.y + 0.15) / 0.95));
    }
    this.n = regs.length;
    const n = this.n;
    this.dir = new Float32Array(pts);
    this.region = new Uint8Array(regs);
    this.h = new Float32Array(hs);
    this.len = new Float32Array(n);
    this.tiltX = new Float32Array(n);
    this.tiltZ = new Float32Array(n);
    this.wet = new Float32Array(n);
    this.jit = new Float32Array(n * 3);
    this.vary = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      const r = REGIONS[this.region[i]];
      const base = r === 'top' || r === 'front' ? startTop : startSide;
      this.len[i] = clamp(base + (Math.random() - 0.5) * 0.12, 0.2, 1);
      this.tiltX[i] = (Math.random() - 0.5) * 0.3;
      this.tiltZ[i] = (Math.random() - 0.5) * 0.3;
      this.jit[i * 3] = Math.random() - 0.5;
      this.jit[i * 3 + 1] = Math.random() - 0.5;
      this.jit[i * 3 + 2] = Math.random() - 0.5;
      this.vary[i] = 0.82 + Math.random() * 0.3;
    }
    const geo = new THREE.CylinderGeometry(0.4, 1, 1, 6, 1, false);
    geo.translate(0, 0.5, 0);
    const mat = new THREE.MeshLambertMaterial({ color: 0xffffff });
    this.mesh = new THREE.InstancedMesh(geo, mat, n);
    this.mesh.frustumCulled = false;
    this.mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.rebuild();
  }

  rebuild() {
    const n = this.n;
    const jitAmp = this.curly ? 0.85 : 0.38;
    const tmpD = this.tmpV;
    for (let i = 0; i < n; i++) {
      const l = this.len[i];
      const nx = this.dir[i * 3];
      const ny = this.dir[i * 3 + 1];
      const nz = this.dir[i * 3 + 2];
      const w = this.wet[i];
      const droop = (0.55 + 0.7 * w) * l * l;
      const top = Math.max(0, ny);
      tmpD.set(
        nx + this.jit[i * 3] * jitAmp * (0.4 + l) + this.tiltX[i] * 0.95 * top,
        ny + this.jit[i * 3 + 1] * jitAmp * 0.5 - droop,
        nz + this.jit[i * 3 + 2] * jitAmp * (0.4 + l) + this.tiltZ[i] * 0.95 * top
      ).normalize();
      this.tmpQ.setFromUnitVectors(this.up, tmpD);
      const height = l * HAIR_MAX * (1 - 0.2 * w) + 0.0025;
      const width = 0.0108 * (this.curly ? 1.5 : 1) * (0.75 + 0.5 * l);
      this.tmpP.set(nx * BASE_R, ny * BASE_R, nz * BASE_R);
      this.tmpS.set(width, height, width);
      this.tmpM.compose(this.tmpP, this.tmpQ, this.tmpS);
      this.mesh.setMatrixAt(i, this.tmpM);
      // colour: skin-ish stubble -> hair colour
      const m = sstep(0.0, 0.22, l);
      this.tmpC.copy(this.skinColor).multiplyScalar(0.62);
      const hc = this.hairColor.clone().multiplyScalar(this.vary[i] * (1 - 0.3 * w));
      this.tmpC.lerp(hc, m);
      this.mesh.setColorAt(i, this.tmpC);
    }
    this.mesh.instanceMatrix.needsUpdate = true;
    if (this.mesh.instanceColor) this.mesh.instanceColor.needsUpdate = true;
    this.dirty = false;
  }

  /** apply a tool at head-local point p. Returns hair removed + touched count */
  apply(
    tool: CutTool,
    p: THREE.Vector3,
    radius: number,
    dt: number,
    guard: number,
    dx: number,
    dz: number
  ): { removed: number; touched: number } {
    const rr = radius * radius;
    let removed = 0;
    let touched = 0;
    for (let i = 0; i < this.n; i++) {
      const ex = this.dir[i * 3] * SURF - p.x;
      const ey = this.dir[i * 3 + 1] * SURF - p.y;
      const ez = this.dir[i * 3 + 2] * SURF - p.z;
      const d2 = ex * ex + ey * ey + ez * ez;
      if (d2 > rr) continue;
      touched++;
      const fall = 1 - (Math.sqrt(d2) / radius) * 0.35;
      const l = this.len[i];
      switch (tool) {
        case 'clipper':
          if (l > guard) {
            const dl = Math.min(l - guard, 2.6 * dt * fall);
            this.len[i] = l - dl;
            removed += dl;
          }
          break;
        case 'scissors':
          if (l > 0.1) {
            const dl = Math.min(l - 0.1, 0.9 * dt * fall);
            this.len[i] = l - dl;
            removed += dl;
          }
          break;
        case 'razor':
          if (l > 0) {
            const dl = Math.min(l, 5 * dt * fall);
            this.len[i] = l - dl;
            removed += dl;
          }
          break;
        case 'comb':
          this.tiltX[i] = clamp(this.tiltX[i] + clamp(dx * 20, -0.4, 0.4) * fall, -1, 1);
          this.tiltZ[i] = clamp(this.tiltZ[i] + clamp(dz * 20, -0.4, 0.4) * fall, -1, 1);
          break;
        case 'spray':
          this.wet[i] = Math.min(1, this.wet[i] + 3.5 * dt);
          this.anyWet = true;
          break;
      }
    }
    if (touched) this.dirty = true;
    return { removed, touched };
  }

  tick(dt: number) {
    if (this.anyWet) {
      let any = false;
      for (let i = 0; i < this.n; i++) {
        if (this.wet[i] > 0) {
          this.wet[i] = Math.max(0, this.wet[i] - 0.025 * dt);
          if (this.wet[i] > 0) any = true;
        }
      }
      this.anyWet = any;
      this.dirty = true;
    }
    if (this.dirty) this.rebuild();
  }

  setStyleTiltReset() {
    /* kept for API completeness */
  }

  averages(): Record<Region, number> {
    const sum: number[] = [0, 0, 0, 0, 0, 0];
    const cnt: number[] = [0, 0, 0, 0, 0, 0];
    for (let i = 0; i < this.n; i++) {
      sum[this.region[i]] += this.len[i];
      cnt[this.region[i]]++;
    }
    const out = {} as Record<Region, number>;
    REGIONS.forEach((r, k) => (out[r] = cnt[k] ? sum[k] / cnt[k] : 0));
    return out;
  }

  targets(style: HairStyle): Record<Region, number> {
    const sum: number[] = [0, 0, 0, 0, 0, 0];
    const cnt: number[] = [0, 0, 0, 0, 0, 0];
    for (let i = 0; i < this.n; i++) {
      const r = REGIONS[this.region[i]];
      sum[this.region[i]] += targetLength(style, r, this.h[i]);
      cnt[this.region[i]]++;
    }
    const out = {} as Record<Region, number>;
    REGIONS.forEach((r, k) => (out[r] = cnt[k] ? sum[k] / cnt[k] : 0));
    return out;
  }

  evaluate(style: HairStyle, bonus: { powder: number; loose: number; accidents: number; razorNeck: boolean }): Evaluation {
    const eSum: number[] = [0, 0, 0, 0, 0, 0];
    const sSum: number[] = [0, 0, 0, 0, 0, 0]; // signed
    const cnt: number[] = [0, 0, 0, 0, 0, 0];
    let tot = 0;
    let sq = 0;
    let patchy = 0;
    let tiltSum = 0;
    let tiltN = 0;
    for (let i = 0; i < this.n; i++) {
      const k = this.region[i];
      const r = REGIONS[k];
      const t = targetLength(style, r, this.h[i]);
      const d = this.len[i] - t;
      eSum[k] += Math.abs(d);
      sSum[k] += d;
      cnt[k]++;
      tot += Math.abs(d);
      sq += d * d;
      if (this.len[i] < 0.025 && t > 0.15) patchy++;
      if (r === 'top' || r === 'front') {
        tiltSum += this.tiltX[i];
        tiltN++;
      }
    }
    const err = {} as Record<Region, number>;
    const signed = {} as Record<Region, number>;
    REGIONS.forEach((r, k) => {
      err[r] = cnt[k] ? eSum[k] / cnt[k] : 0;
      signed[r] = cnt[k] ? sSum[k] / cnt[k] : 0;
    });
    const avg = this.averages();
    const tgt = this.targets(style);
    const meanErr = tot / this.n;
    const rms = Math.sqrt(sq / this.n);
    const lenScore = 1 - clamp(meanErr / 0.3);
    const symScore = 1 - clamp(Math.abs(avg.left - avg.right) / 0.2) * 0.7 - clamp(Math.abs(err.left - err.right) / 0.2) * 0.3;
    const tiltAvg = tiltN ? tiltSum / tiltN : 0;
    let tiltScore = 1;
    if (style.sweep === 'left') tiltScore = clamp((tiltAvg + 0.05) / 0.4);
    else if (style.sweep === 'right') tiltScore = clamp((-tiltAvg + 0.05) / 0.4);
    else if (style.sweep === 'up') tiltScore = 1 - clamp(Math.abs(tiltAvg) / 0.5);
    const topShape = 1 - clamp((err.top * 0.55 + err.front * 0.45) / 0.28);
    const topScore = topShape * (style.sweep === 'none' ? 1 : 0.78) + tiltScore * (style.sweep === 'none' ? 0 : 0.22);
    const backScore = 1 - clamp((err.back * 0.6 + err.neck * 0.4) / 0.25);
    const resScore = 1 - clamp(rms / 0.32);
    const patchy01 = patchy / this.n;
    let score =
      100 * (0.3 * lenScore + 0.15 * clamp(symScore) + 0.2 * topScore + 0.15 * backScore + 0.2 * resScore);
    score -= Math.min(30, patchy01 * 120);
    score += Math.min(3, bonus.powder * 3);
    score += bonus.loose < 0.25 ? 3 : bonus.loose < 0.5 ? 1 : 0;
    score += bonus.razorNeck ? 2 : 0;
    score -= Math.min(15, bonus.accidents * 5);
    score = clamp(score, 0, 100);
    let worst: Region = 'top';
    let w = -1;
    REGIONS.forEach((r) => {
      if (err[r] > w) {
        w = err[r];
        worst = r;
      }
    });
    return {
      score: Math.round(score),
      lenScore,
      symScore: clamp(symScore),
      topScore,
      backScore,
      resScore,
      worst,
      worstDir: signed[worst] > 0 ? 'long' : 'short',
      patchy: patchy01,
      avg,
      tgt,
    };
  }

  dispose() {
    this.mesh.geometry.dispose();
    (this.mesh.material as THREE.Material).dispose();
    this.mesh.dispose();
  }
}
